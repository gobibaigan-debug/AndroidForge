package com.icse.studytracker.notifications

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.AppState
import com.icse.studytracker.data.objects
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Checks the server every ~20 seconds for new community / DM messages and for classmates who just studied,
 * and shows a notification for each. It keeps a tiny silent notification so Android does not stop it.
 */
class LiveNotifyService : Service() {
    companion object {
        private const val NOTIFICATION_ID = 8

        @Volatile
        var inForeground = false

        fun start(context: Context) {
            try {
                val i = Intent(context, LiveNotifyService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
            } catch (e: Exception) {
                // not allowed right now (for example the app is in the background); it starts next time the app opens
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, LiveNotifyService::class.java))
            } catch (e: Exception) {
                // ignore
            }
        }

        private fun isoNow(): String {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            return f.format(java.util.Date())
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.channels(this)
        val notification = NotificationCompat.Builder(this, NotificationHelper.LIVE_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("ICSE Study Tracker")
            .setContentText("Listening for new messages and classmates studying")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        val ctx = applicationContext
        val state = AppState(ctx)
        Api.init(ctx)
        var tick = 0
        while (true) {
            if (!state.notificationsEnabled || state.cookie == null) {
                stopSelf()
                return
            }
            try {
                pollMessages(ctx, state)
            } catch (e: Exception) {
                // try again next round
            }
            if (tick % 3 == 0) {
                try {
                    pollStudy(ctx, state)
                } catch (e: Exception) {
                    // try again next round
                }
            }
            tick++
            delay(20_000L)
        }
    }

    private fun pollMessages(ctx: Context, state: AppState) {
        if (state.lastNotificationAt.isBlank()) {
            // first run: start from now so old messages do not pop up
            state.lastNotificationAt = isoNow()
            return
        }
        val data = Api.trackerObj("notifications", JSONObject().put("since", state.lastNotificationAt))
        val items = data.optJSONArray("items")?.objects() ?: emptyList()
        var newest = state.lastNotificationAt
        for (item in items) {
            val created = item.optString("createdAt")
            if (created > newest) newest = created
            if (inForeground) continue
            val who = item.optString("displayName", "Student")
            val title = if (item.optString("type") == "dm") "New message from $who" else "$who in Community"
            val id = 1200 + Math.abs(item.optString("id").hashCode() % 700000)
            NotificationHelper.chat(ctx, id, title, item.optString("body"))
        }
        if (newest.isNotBlank()) state.lastNotificationAt = newest
    }

    private fun pollStudy(ctx: Context, state: AppState) {
        val tz = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
        val arr = Api.trackerArr("leaderboard", JSONObject().put("period", "day").put("tzOffsetMinutes", tz))
        val prevRaw = state.str("study_snapshot")
        val prev = try { JSONObject(if (prevRaw.isBlank()) "{}" else prevRaw) } catch (e: Exception) { JSONObject() }
        val next = JSONObject()
        val me = state.userName
        for (row in arr.objects()) {
            val name = row.optString("displayName", "Student")
            val minutes = row.optDouble("totalMinutes", 0.0)
            next.put(name, minutes)
            if (name != me && prev.has(name) && !inForeground) {
                val gained = minutes - prev.optDouble(name, 0.0)
                if (gained >= 0.5) {
                    val mins = Math.max(1, Math.round(gained).toInt())
                    NotificationHelper.friendStudy(
                        ctx, 3000 + Math.abs(name.hashCode() % 1000),
                        "\uD83D\uDCDA $name is studying",
                        "$name just studied $mins more minute${if (mins == 1) "" else "s"}. Keep up!"
                    )
                }
            }
        }
        state.put("study_snapshot", next.toString())
    }

    override fun onDestroy() {
        job?.cancel()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }
}
