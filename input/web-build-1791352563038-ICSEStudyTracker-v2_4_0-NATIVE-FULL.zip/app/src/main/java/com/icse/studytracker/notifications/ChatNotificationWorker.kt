package com.icse.studytracker.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.AppState
import com.icse.studytracker.data.objects
import org.json.JSONObject

/** Polls the backend for new community / DM messages and shows notifications. */
class ChatNotificationWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val state = AppState(applicationContext)
        if (!state.notificationsEnabled || state.cookie == null) return Result.success()
        Api.init(applicationContext)
        return try {
            val data = Api.trackerObj("notifications", JSONObject().put("since", state.lastNotificationAt))
            val items = data.optJSONArray("items")?.objects() ?: emptyList()
            var newest = state.lastNotificationAt
            for (item in items) {
                val id = item.optString("id").hashCode()
                val who = item.optString("displayName", "Student")
                val title = if (item.optString("type") == "dm") "New message from $who" else "$who in Community"
                NotificationHelper.chat(applicationContext, 1200 + Math.abs(id % 700000), title, item.optString("body"))
                val created = item.optString("createdAt")
                if (created > newest) newest = created
            }
            if (newest.isNotBlank()) state.lastNotificationAt = newest
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
