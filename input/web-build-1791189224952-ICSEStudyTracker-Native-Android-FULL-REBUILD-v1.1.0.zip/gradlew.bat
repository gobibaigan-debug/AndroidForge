@echo off
set "GRADLE_VERSION=8.9"
set "CACHE_DIR=%USERPROFILE%\.gradle\floot-bootstrap\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%CACHE_DIR%\bin\gradle.bat"
if exist "%GRADLE_BIN%" goto run
where curl >nul 2>nul || (echo curl is required to bootstrap Gradle & exit /b 2)
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
set "TMP=%TEMP%\gradle-%GRADLE_VERSION%.zip"
if not exist "%TMP%" curl -fL --retry 3 -o "%TMP%" "https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"
powershell -NoProfile -Command "Expand-Archive -Force '%TMP%' '%CACHE_DIR%\..\bootstrap-tmp'"
xcopy /E /I /Y "%CACHE_DIR%\..\bootstrap-tmp\gradle-%GRADLE_VERSION%\*" "%CACHE_DIR%\" >nul
rmdir /S /Q "%CACHE_DIR%\..\bootstrap-tmp"
:run
call "%GRADLE_BIN%" %*
