# ICSE Class 9 Study Tracker — Cloud Build Package

Real native Android Kotlin + Jetpack Compose project; NOT a WebView wrapper.

## Build
On a Linux cloud Android builder with JDK 17+ and Android SDK Platform 35:

```bash
chmod +x gradlew
./gradlew clean assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

Gradle 8.9 / Android Gradle Plugin 8.7.3 are pinned.

## Identity
- Name: ICSE Class 9 Study Tracker
- Application ID: com.icse.class9studytracker
- Version: 1.0.1 (2)

## Native functionality
Camera, microphone/voice notes, notifications, foreground focus timer, Accessibility Service for user-selected distracting apps, Community/DM foundation, media/document sharing, polls, study tracking, statistics, planner, and Sunday tests.

Focus Accessibility Service is not enabled automatically. The user enables it in Android Settings; only selected apps are intercepted while Focus Mode is active.
