package com.icse.studytracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.fmtClock
import com.icse.studytracker.notifications.ChatNotificationWorker
import com.icse.studytracker.notifications.LiveNotifyService
import com.icse.studytracker.notifications.NotificationHelper
import com.icse.studytracker.notifications.StudyReminderWorker
import com.icse.studytracker.ui.AuthScreen
import com.icse.studytracker.ui.Avatar
import com.icse.studytracker.ui.BG
import com.icse.studytracker.ui.BoardScreen
import com.icse.studytracker.ui.ChatScreen
import com.icse.studytracker.ui.Cyan
import com.icse.studytracker.ui.FocusScreen
import com.icse.studytracker.ui.HomeScreen
import com.icse.studytracker.ui.Kicker
import com.icse.studytracker.ui.Line
import com.icse.studytracker.ui.Muted
import com.icse.studytracker.ui.NeonButton
import com.icse.studytracker.ui.Panel
import com.icse.studytracker.ui.PlannerScreen
import com.icse.studytracker.ui.ProgressBar
import com.icse.studytracker.ui.StatsScreen
import com.icse.studytracker.ui.StudyScreen
import com.icse.studytracker.ui.TestsScreen
import com.icse.studytracker.ui.TimerScreen
import com.icse.studytracker.ui.Txt
import com.icse.studytracker.ui.Violet
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(applicationContext)
        NotificationHelper.channels(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 700)
        }
        scheduleWorkers()
        Repo.applyNotificationSetting()
        askBatteryExemptionOnce()
        val open = intent?.getStringExtra("openTab")
        if (open != null && Repo.loggedIn) Repo.tab = open
        val chatKind = intent?.getStringExtra("openChat")
        if (chatKind != null && Repo.loggedIn) {
            Repo.pendingChat = Pair(chatKind, intent?.getStringExtra("openName") ?: "")
        }
        setContent { TrackerApp() }
    }

    override fun onResume() {
        super.onResume()
        LiveNotifyService.inForeground = true
        Repo.applyNotificationSetting()
    }

    override fun onPause() {
        LiveNotifyService.inForeground = false
        super.onPause()
    }

    /** Lets the message listener keep running with the app closed (asked once, only after sign-in). */
    private fun askBatteryExemptionOnce() {
        try {
            if (!Repo.loggedIn || Repo.state.bool("batteryAsked")) return
            val pm = getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
            if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(packageName)) {
                Repo.state.putBool("batteryAsked", true)
                startActivity(
                    android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(android.net.Uri.parse("package:$packageName"))
                )
            }
        } catch (e: Exception) {
            // not available on this phone; the menu entry "Keep notifications running" still works
        }
    }

    private fun scheduleWorkers() {
        val wm = WorkManager.getInstance(applicationContext)
        val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        wm.enqueueUniquePeriodicWork(
            "chat-notifications",
            ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<ChatNotificationWorker>(15, TimeUnit.MINUTES).setConstraints(net).build()
        )
        wm.enqueueUniquePeriodicWork(
            "study-reminder",
            ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<StudyReminderWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(StudyReminderWorker.initialDelayMs(), TimeUnit.MILLISECONDS)
                .build()
        )
    }
}

@Composable
fun TrackerApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = BG, surface = Panel,
            onBackground = Txt, onSurface = Txt, onPrimary = BG
        )
    ) {
        Box(Modifier.fillMaxSize().background(BG)) {
            if (Repo.loggedIn) MainShell() else Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) { AuthScreen() }
        }
    }
}

private val tabs = listOf(
    Triple("Home", "\uD83C\uDFE0", "Home"),
    Triple("Timer", "\u23F1\uFE0F", "Timer"),
    Triple("Study", "\uD83D\uDCDA", "Study"),
    Triple("Stats", "\uD83D\uDCCA", "Stats"),
    Triple("Board", "\uD83C\uDFC6", "Board"),
    Triple("Tests", "\uD83E\uDDE0", "Tests"),
    Triple("Planner", "\uD83D\uDCC5", "Planner"),
    Triple("Chat", "\uD83D\uDCAC", "Chat"),
    Triple("Focus", "\uD83C\uDFAF", "Focus")
)

@Composable
fun MainShell() {
    val tab = Repo.tab
    BackHandler(enabled = tab != "Home") { Repo.tab = "Home" }
    val full = tab == "Chat" && Repo.chatFullScreen
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        if (!full) Header()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                "Home" -> HomeScreen()
                "Timer" -> TimerScreen()
                "Study" -> StudyScreen()
                "Stats" -> StatsScreen()
                "Board" -> BoardScreen()
                "Tests" -> TestsScreen()
                "Planner" -> PlannerScreen()
                "Chat" -> ChatScreen()
                "Focus" -> FocusScreen()
                else -> HomeScreen()
            }
        }
        if (!full) {
            FocusPill()
            NavBar(tab)
        }
    }
}

@Composable
private fun Header() {
    var menu by remember { mutableStateOf(false) }
    val ctxForMenu = androidx.compose.ui.platform.LocalContext.current
    val pct = Repo.overallPercent()
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Kicker("ICSE \u00B7 CLASS IX \u00B7 2026\u201327")
                Text("Study Tracker", color = Txt, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text(
                Repo.stream.uppercase(),
                color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, Line, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
            Box {
                Box(Modifier.clip(CircleShape).clickable { menu = true }) {
                    Avatar(Repo.userName, 38, Cyan)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Signed in as ${Repo.userName}", color = Muted) },
                        onClick = { menu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Switch to ${if (Repo.stream == "Science") "Commerce" else "Science"} stream") },
                        onClick = {
                            menu = false
                            Repo.changeStream(if (Repo.stream == "Science") "Commerce" else "Science")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(if (Repo.state.notificationsEnabled) "Turn notifications off" else "Turn notifications on") },
                        onClick = {
                            menu = false
                            Repo.state.notificationsEnabled = !Repo.state.notificationsEnabled
                            Repo.applyNotificationSetting()
                            Repo.toast(if (Repo.state.notificationsEnabled) "Notifications on" else "Notifications off")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Keep notifications running (battery)") },
                        onClick = {
                            menu = false
                            try {
                                ctxForMenu.startActivity(
                                    android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e: Exception) {
                                Repo.toast("Open Settings > Battery and set this app to No restrictions")
                            }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Refresh data") },
                        onClick = {
                            menu = false
                            Repo.refreshAll()
                            Repo.toast("Refreshing\u2026")
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Sign out", color = com.icse.studytracker.ui.Bad) },
                        onClick = {
                            menu = false
                            Repo.signOut()
                        }
                    )
                }
            }
        }
        ProgressBar(pct / 100f, Modifier.padding(horizontal = 14.dp), height = 5)
        Text(
            "Syllabus progress $pct%  \u00B7  ${Repo.finishedChapters()}/${Repo.totalChapters()} chapters",
            color = Muted, fontSize = 10.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun FocusPill() {
    if (!Repo.focusActive) return
    val left = (Repo.focusEnd - Repo.now) / 1000
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Panel)
            .border(1.dp, Cyan, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("\uD83C\uDFAF FOCUS ON \u00B7 ${fmtClock(left)} left", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
        NeonButton("End", { Repo.endFocus() }, secondary = true)
    }
}

@Composable
private fun NavBar(current: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color0C121B)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for ((key, icon, label) in tabs) {
            val on = key == current
            Column(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (on) Violet.copy(alpha = 0.28f) else Color0C121B)
                    .clickable { Repo.tab = key }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box {
                    Text(icon, fontSize = 18.sp)
                    if (key == "Chat" && Repo.totalUnread > 0) {
                        Text(
                            if (Repo.totalUnread > 9) "9+" else "${Repo.totalUnread}",
                            color = androidx.compose.ui.graphics.Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .clip(CircleShape)
                                .background(androidx.compose.ui.graphics.Color(0xFFFF3B30))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                Text(label, color = if (on) Txt else Muted, fontSize = 10.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

private val Color0C121B = androidx.compose.ui.graphics.Color(0xFF0C121B)
