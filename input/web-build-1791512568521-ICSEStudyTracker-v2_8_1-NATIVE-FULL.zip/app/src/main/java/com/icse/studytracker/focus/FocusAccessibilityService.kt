package com.icse.studytracker.focus

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Sends the user back to the home screen whenever a blocked app comes to the foreground
 * while a Focus Mode session is running.
 */
class FocusAccessibilityService : AccessibilityService() {
    private var lastToast = 0L
    private var lastHome = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOWS_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            info.notificationTimeout = 50
            serviceInfo = info
        } catch (e: Exception) {
            // the values from accessibility_config.xml stay in effect
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val type = event.eventType
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOWS_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        val prefs = FocusPrefs(this)
        if (!prefs.isActive()) return
        if (!prefs.packages().contains(pkg)) return
        val now = System.currentTimeMillis()
        if (now - lastHome < 400L) return
        lastHome = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        if (now - lastToast > 2500L) {
            lastToast = now
            Toast.makeText(this, "Focus Mode is on \u2014 back to studying!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInterrupt() {
        // nothing to clean up
    }
}
