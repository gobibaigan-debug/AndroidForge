package com.icse.studytracker.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.Member
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.addDays
import com.icse.studytracker.data.dayKey
import com.icse.studytracker.data.lastSeenText
import com.icse.studytracker.data.objects
import com.icse.studytracker.data.parseIso
import com.icse.studytracker.data.prettyDate
import com.icse.studytracker.data.stampOf
import com.icse.studytracker.data.strings
import com.icse.studytracker.data.timeOfDay
import com.icse.studytracker.data.todayKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Pick(val uri: Uri, val name: String, val mime: String)

private fun toPick(ctx: Context, uri: Uri, forcedMime: String?): Pick {
    var name = "file"
    try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i) ?: name
            }
        }
    } catch (e: Exception) {
        // keep default name
    }
    val mime = forcedMime ?: ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    return Pick(uri, name, mime)
}

private fun openUrl(ctx: Context, url: String, mime: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
        if (mime.isNotBlank()) i.setDataAndType(Uri.parse(url), mime) else i.data = Uri.parse(url)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Repo.toast("No app can open this file")
    }
}


private val WaBg = Color(0xFF0B141A)
private val WaHeader = Color(0xFF202C33)
private val WaOut = Color(0xFF005C4B)
private val WaIn = Color(0xFF202C33)
private val WaGreen = Color(0xFF00A884)
private val WaTick = Color(0xFF53BDEB)
private val WaMuted = Color(0xFF8696A0)

private fun dayLabel(ms: Long): String {
    val k = dayKey(ms)
    return when (k) {
        todayKey() -> "Today"
        addDays(todayKey(), -1) -> "Yesterday"
        else -> prettyDate(k)
    }
}

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var inRoom by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("community") }
    var peer by remember { mutableStateOf<Member?>(null) }
    var community by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var dm by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var picks by remember { mutableStateOf<List<Pick>>(emptyList()) }
    var sending by remember { mutableStateOf(false) }
    var pollOpen by remember { mutableStateOf(false) }
    var tray by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordFile by remember { mutableStateOf<File?>(null) }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    var pendingKind by remember { mutableStateOf("photo") }
    var menuMsg by remember { mutableStateOf<JSONObject?>(null) }
    var infoMsg by remember { mutableStateOf<JSONObject?>(null) }
    var infoSeen by remember { mutableStateOf<List<Pair<String, Long>>>(emptyList()) }
    var infoLoading by remember { mutableStateOf(false) }
    val seen = remember { mutableStateMapOf<String, List<String>>() }
    val marked = remember { HashSet<String>() }
    val listState = rememberLazyListState()
    val prefix = if (mode == "dm") "d" else "c"

    suspend fun loadOnce() {
        try {
            if (mode == "community") {
                val arr = withContext(Dispatchers.IO) { Api.trackerArr("community_list") }
                val list = arr.objects().reversed()
                community = list
                val seenNow = withContext(Dispatchers.IO) {
                    var n = 0
                    for (m in list) {
                        val id = m.optString("id")
                        if (m.optString("userId") != Repo.userId && n < 25 && marked.add("c$id")) {
                            n++
                            try {
                                Api.tracker("community_read", JSONObject().put("messageId", id))
                            } catch (e: Exception) {
                                marked.remove("c$id")
                            }
                        }
                    }
                    val out = HashMap<String, List<String>>()
                    for (m in list.filter { it.optString("userId") == Repo.userId }.takeLast(4)) {
                        val id = m.optString("id")
                        try {
                            val names = Api.trackerArr("seen_by", JSONObject().put("messageId", id)).objects()
                                .map { it.optString("displayName", "Student") }
                            out[id] = names
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    out
                }
                for ((k, v) in seenNow) seen[k] = v
            } else {
                val p = peer ?: return
                val arr = withContext(Dispatchers.IO) { Api.trackerArr("dm_list", JSONObject().put("peerId", p.id)) }
                val list = arr.objects()
                dm = list
                withContext(Dispatchers.IO) {
                    for (m in list) {
                        val id = m.optString("id")
                        if (m.optString("senderId") != Repo.userId && m.isNull("readAt") && marked.add("d$id")) {
                            try {
                                Api.tracker("dm_read", JSONObject().put("messageId", id))
                            } catch (e: Exception) {
                                marked.remove("d$id")
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Repo.handleError(e)
        }
    }

    LaunchedEffect(inRoom, mode, peer?.id) {
        if (inRoom) {
            while (true) {
                loadOnce()
                delay(3000)
            }
        } else {
            while (true) {
                Repo.loadMembers()
                delay(15000)
            }
        }
    }

    val shown = (if (mode == "community") community else dm).filter { !Repo.isHidden(prefix + it.optString("id")) }
    LaunchedEffect(shown.size, mode, peer?.id, inRoom) {
        if (inRoom && shown.isNotEmpty()) listState.scrollToItem(shown.size - 1)
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                recorder?.release()
            } catch (e: Exception) {
                // already released
            }
        }
    }
    BackHandler(enabled = inRoom) {
        inRoom = false
        tray = false
    }

    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        picks = picks + uris.map { toPick(ctx, it, null) }
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        picks = picks + uris.map { toPick(ctx, it, null) }
    }
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = captureUri
        if (ok && u != null) picks = picks + Pick(u, "photo-${System.currentTimeMillis()}.jpg", "image/jpeg")
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        val u = captureUri
        if (ok && u != null) picks = picks + Pick(u, "video-${System.currentTimeMillis()}.mp4", "video/mp4")
    }

    fun startCapture(kind: String) {
        try {
            val dir = File(ctx.cacheDir, "capture")
            dir.mkdirs()
            val f = File(dir, if (kind == "video") "video-${System.currentTimeMillis()}.mp4" else "photo-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            captureUri = uri
            if (kind == "video") videoLauncher.launch(uri) else photoLauncher.launch(uri)
        } catch (e: Exception) {
            Repo.toast("Could not open the camera")
        }
    }

    fun startRecording() {
        try {
            val dir = File(ctx.cacheDir, "capture")
            dir.mkdirs()
            val f = File(dir, "voice-${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recordFile = f
            recording = true
        } catch (e: Exception) {
            recording = false
            Repo.toast("Could not start recording")
        }
    }

    fun stopRecording() {
        val r = recorder
        val f = recordFile
        try {
            r?.stop()
        } catch (e: Exception) {
            // too short to record
        }
        try {
            r?.release()
        } catch (e: Exception) {
            // ignore
        }
        recorder = null
        recording = false
        if (f != null && f.exists() && f.length() > 0L) {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            picks = picks + Pick(uri, f.name, "audio/mp4")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCapture(pendingKind) else Repo.toast("Camera permission is needed")
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else Repo.toast("Microphone permission is needed")
    }

    fun needsPermission(perm: String): Boolean =
        Build.VERSION.SDK_INT >= 23 && ctx.checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED

    fun capture(kind: String) {
        pendingKind = kind
        tray = false
        if (needsPermission(android.Manifest.permission.CAMERA)) {
            cameraPermission.launch(android.Manifest.permission.CAMERA)
        } else {
            startCapture(kind)
        }
    }

    fun toggleRecording() {
        if (recording) {
            stopRecording()
        } else if (needsPermission(android.Manifest.permission.RECORD_AUDIO)) {
            micPermission.launch(android.Manifest.permission.RECORD_AUDIO)
        } else {
            startRecording()
        }
    }

    fun send(poll: JSONObject?) {
        val body = text.trim()
        if (body.isEmpty() && picks.isEmpty() && poll == null) return
        if (mode == "dm" && peer == null) return
        val toUpload = picks
        val isDm = mode == "dm"
        val peerId = peer?.id ?: ""
        scope.launch {
            sending = true
            try {
                val atts = JSONArray()
                for (p in toUpload) {
                    val a = withContext(Dispatchers.IO) { Api.upload(ctx, p.uri, p.name, p.mime) }
                    atts.put(a)
                }
                val kind = if (poll != null) "poll" else if (atts.length() > 0) "attachment" else "text"
                val payload = JSONObject()
                    .put("kind", kind)
                    .put("body", body)
                    .put("attachments", atts)
                    .put("poll", poll ?: JSONObject.NULL)
                if (isDm) payload.put("peerId", peerId)
                withContext(Dispatchers.IO) { Api.tracker(if (isDm) "dm_send" else "community_post", payload) }
                text = ""
                picks = emptyList()
                tray = false
                loadOnce()
            } catch (e: Exception) {
                Repo.toast(Repo.handleError(e))
            }
            sending = false
        }
    }

    fun vote(id: String, choice: Int) {
        val isDm = mode == "dm"
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    Api.tracker("poll_vote", JSONObject().put("messageId", id).put("choice", choice).put("isDm", isDm))
                }
                loadOnce()
            } catch (e: Exception) {
                Repo.toast(Repo.handleError(e))
            }
        }
    }

    fun deleteForEveryone(m: JSONObject) {
        val id = m.optString("id")
        val isDm = mode == "dm"
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    Api.tracker("msg_delete", JSONObject().put("messageId", id).put("isDm", isDm))
                }
                loadOnce()
                Repo.toast("Message deleted for everyone")
            } catch (e: Exception) {
                val msg = Repo.handleError(e)
                if (msg.contains("msg_delete") || msg.contains("enum", true) || msg.contains("invalid", true)) {
                    Repo.hideMessage((if (isDm) "d" else "c") + id)
                    Repo.toast("Server update not live yet — deleted for you only")
                } else {
                    Repo.toast(msg)
                }
            }
        }
    }

    LaunchedEffect(infoMsg) {
        val m = infoMsg
        infoSeen = emptyList()
        if (m != null && mode == "community" && m.optString("userId") == Repo.userId) {
            infoLoading = true
            try {
                val arr = withContext(Dispatchers.IO) {
                    Api.trackerArr("seen_by", JSONObject().put("messageId", m.optString("id")))
                }
                infoSeen = arr.objects().map { Pair(it.optString("displayName", "Student"), parseIso(it.optString("seenAt"))) }
            } catch (e: Exception) {
                Repo.handleError(e)
            }
            infoLoading = false
        }
    }

    // ------------------------------------------------------------ UI
    Column(Modifier.fillMaxSize().background(WaBg)) {
        if (!inRoom) {
            Row(
                Modifier.fillMaxWidth().background(WaHeader).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Chats", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                ChatRow("Class IX Community", "Everyone in your class", "\uD83D\uDC65", WaGreen, true) {
                    mode = "community"
                    peer = null
                    inRoom = true
                }
                for (m in Repo.members) {
                    ChatRow(m.name, lastSeenText(m.lastSeen).ifBlank { "\uD83D\uDD25 ${m.streak} day streak" }, m.name, colorForName(m.name), false) {
                        dm = emptyList()
                        mode = "dm"
                        peer = m
                        inRoom = true
                    }
                }
                if (Repo.members.isEmpty()) {
                    Text("No other students have joined yet.", color = WaMuted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
                }
            }
        } else {
            val p = peer
            val title = if (mode == "dm" && p != null) p.name else "Class IX Community"
            // last-seen: server value, or the latest sign of activity we can see in this chat
            var lastActive = p?.lastSeen ?: 0L
            if (mode == "dm" && p != null) {
                for (m in dm) {
                    val created = parseIso(m.optString("createdAt"))
                    if (m.optString("senderId") != Repo.userId && created > lastActive) lastActive = created
                    val readAt = if (m.isNull("readAt")) 0L else parseIso(m.optString("readAt"))
                    if (m.optString("senderId") == Repo.userId && readAt > lastActive) lastActive = readAt
                }
            }
            val subtitle = if (mode == "dm") lastSeenText(lastActive) else "tap and hold a message for options"
            Row(
                Modifier.fillMaxWidth().background(WaHeader).padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "\u2039", color = Txt, fontSize = 32.sp,
                    modifier = Modifier.clickable { inRoom = false; tray = false }.padding(horizontal = 8.dp)
                )
                if (mode == "dm" && p != null) Avatar(p.name, 38, colorForName(p.name)) else GroupAvatar(38)
                Column(Modifier.weight(1f)) {
                    Text(title, color = Txt, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                    if (subtitle.isNotBlank()) Text(subtitle, color = WaMuted, fontSize = 12.sp, maxLines = 1)
                }
            }

            if (shown.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        if (mode == "community") "No messages yet \u2014 say hello to the class!" else "No messages yet. Say hi \uD83D\uDC4B",
                        color = WaMuted, fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp)
                ) {
                    itemsIndexed(shown, key = { _, m -> prefix + m.optString("id") }) { i, m ->
                        val t = parseIso(m.optString("createdAt"))
                        val prevT = if (i > 0) parseIso(shown[i - 1].optString("createdAt")) else 0L
                        if (i == 0 || dayKey(t) != dayKey(prevT)) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    dayLabel(t), color = WaMuted, fontSize = 12.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(WaHeader).padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }
                        val mine = if (mode == "dm") m.optString("senderId") == Repo.userId else m.optString("userId") == Repo.userId
                        Bubble(m, mine, mode == "dm", seen[m.optString("id")], { menuMsg = m }) { id, choice -> vote(id, choice) }
                    }
                }
            }

            if (tray) {
                Row(
                    Modifier.fillMaxWidth().background(WaHeader).padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TrayItem("\uD83D\uDDBC", "Gallery", Color(0xFF7F66FF)) { tray = false; galleryPicker.launch(arrayOf("image/*", "video/*")) }
                    TrayItem("\uD83C\uDFA5", "Video", Color(0xFFD3396D)) { capture("video") }
                    TrayItem("\uD83D\uDCC4", "Document", Color(0xFF5157AE)) {
                        tray = false
                        docPicker.launch(arrayOf("application/pdf", "text/plain", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"))
                    }
                    TrayItem("\uD83D\uDCCA", "Poll", Color(0xFF02A698)) { tray = false; pollOpen = true }
                }
            }

            Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (picks.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (pk in picks) {
                            val icon = if (pk.mime.startsWith("image/")) "\uD83D\uDDBC" else if (pk.mime.startsWith("video/")) "\uD83C\uDFA5" else if (pk.mime.startsWith("audio/")) "\uD83C\uDFA4" else "\uD83D\uDCCE"
                            Text(
                                "$icon ${pk.name.take(16)}  \u2715", color = Txt, fontSize = 12.sp,
                                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(WaHeader)
                                    .clickable { picks = picks - pk }.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
                if (recording) Text("\uD83D\uDD34 Recording\u2026 tap \u23F9 when you are done", color = Bad, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(WaHeader).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(Modifier.weight(1f)) {
                            BasicTextField(
                                value = text,
                                onValueChange = { text = it },
                                textStyle = TextStyle(color = Txt, fontSize = 16.sp),
                                cursorBrush = SolidColor(WaGreen),
                                maxLines = 5,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            )
                            if (text.isEmpty()) Text("Message", color = WaMuted, fontSize = 16.sp, modifier = Modifier.padding(vertical = 4.dp))
                        }
                        Text("\uD83D\uDCCE", fontSize = 20.sp, modifier = Modifier.clickable { tray = !tray })
                        Text("\uD83D\uDCF7", fontSize = 20.sp, modifier = Modifier.clickable { capture("photo") })
                    }
                    val hasContent = text.isNotBlank() || picks.isNotEmpty()
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(if (recording) Bad else WaGreen).clickable {
                            if (hasContent && !sending) send(null) else if (!hasContent) toggleRecording()
                        },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (sending) "\u2026" else if (hasContent) "\u27A4" else if (recording) "\u23F9" else "\uD83C\uDFA4", color = Color.White, fontSize = 20.sp)
                    }
                }
            }
        }
    }

    if (pollOpen) {
        PollDialog(
            onDismiss = { pollOpen = false },
            onCreate = { poll ->
                pollOpen = false
                send(poll)
            }
        )
    }

    val mm = menuMsg
    if (mm != null) {
        val mineMsg = if (mode == "dm") mm.optString("senderId") == Repo.userId else mm.optString("userId") == Repo.userId
        val deleted = mm.optString("kind") == "deleted"
        AlertDialog(
            onDismissRequest = { menuMsg = null },
            containerColor = WaHeader,
            title = { Text("Message options", color = Txt) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    OptionRow("\u2139\uFE0F  Message info", Txt) { infoMsg = mm; menuMsg = null }
                    OptionRow("\uD83D\uDDD1  Delete for me", Txt) {
                        Repo.hideMessage(prefix + mm.optString("id"))
                        menuMsg = null
                    }
                    if (mineMsg && !deleted) {
                        OptionRow("\uD83D\uDDD1  Delete for everyone", Bad) {
                            menuMsg = null
                            deleteForEveryone(mm)
                        }
                    }
                }
            },
            confirmButton = { NeonButton("Close", { menuMsg = null }, secondary = true) }
        )
    }

    val im = infoMsg
    if (im != null) {
        val mineMsg = if (mode == "dm") im.optString("senderId") == Repo.userId else im.optString("userId") == Repo.userId
        AlertDialog(
            onDismissRequest = { infoMsg = null },
            containerColor = WaHeader,
            title = { Text("Message info", color = Txt) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sent: " + stampOf(parseIso(im.optString("createdAt"))), color = Txt, fontSize = 14.sp)
                    if (mode == "dm" && mineMsg) {
                        val delivered = if (im.isNull("deliveredAt")) 0L else parseIso(im.optString("deliveredAt"))
                        val read = if (im.isNull("readAt")) 0L else parseIso(im.optString("readAt"))
                        Text("Delivered: " + (if (delivered > 0L) stampOf(delivered) else "\u2014"), color = Txt, fontSize = 14.sp)
                        Text(
                            "Seen: " + (if (read > 0L) stampOf(read) else "not seen yet"),
                            color = if (read > 0L) WaTick else WaMuted, fontSize = 14.sp
                        )
                    }
                    if (mode == "community" && mineMsg) {
                        Text("Seen by", color = Txt, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (infoLoading) Text("Loading\u2026", color = WaMuted, fontSize = 13.sp)
                        if (!infoLoading && infoSeen.isEmpty()) Text("No one has seen it yet", color = WaMuted, fontSize = 13.sp)
                        for ((name, at) in infoSeen) {
                            Text("\u2713\u2713 $name \u2014 ${stampOf(at)}", color = WaTick, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = { NeonButton("Close", { infoMsg = null }, secondary = true) }
        )
    }
}

@Composable
private fun OptionRow(label: String, color: Color, onClick: () -> Unit) {
    Text(
        label, color = color, fontSize = 16.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp)
    )
}

@Composable
private fun GroupAvatar(dia: Int) {
    Box(Modifier.size(dia.dp).clip(CircleShape).background(WaGreen), contentAlignment = Alignment.Center) {
        Text("\uD83D\uDC65", fontSize = (dia / 2.1f).sp)
    }
}

@Composable
private fun ChatRow(title: String, subtitle: String, avatarName: String, tint: Color, group: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (group) GroupAvatar(50) else Avatar(avatarName, 50, tint)
        Column(Modifier.weight(1f)) {
            Text(title, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(subtitle, color = WaMuted, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
private fun TrayItem(icon: String, label: String, tint: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(tint), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 22.sp)
        }
        Text(label, color = WaMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun Bubble(
    m: JSONObject,
    mine: Boolean,
    dmMode: Boolean,
    seenNames: List<String>?,
    onLong: () -> Unit,
    onVote: (String, Int) -> Unit
) {
    val name = if (dmMode) "" else m.optString("displayName", "Student")
    val tint = colorForName(name)
    val shape = RoundedCornerShape(
        topStart = if (mine) 12.dp else 2.dp, topEnd = if (mine) 2.dp else 12.dp,
        bottomStart = 12.dp, bottomEnd = 12.dp
    )
    val deleted = m.optString("kind") == "deleted"
    val body = if (m.isNull("body")) "" else m.optString("body", "")
    val atts = if (deleted) null else m.optJSONArray("attachments")
    val poll = if (deleted) null else m.optJSONObject("poll")
    val id = m.optString("id")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .clip(shape)
                .background(if (mine) WaOut else WaIn)
                .pointerInput(id) { detectTapGestures(onLongPress = { onLong() }) }
                .padding(horizontal = 9.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (!mine && !dmMode) Text(name, color = tint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (deleted) {
                Text(
                    "\uD83D\uDEAB This message was deleted", color = WaMuted, fontSize = 14.sp,
                    fontStyle = FontStyle.Italic
                )
            } else if (body.isNotBlank()) {
                Text(body, color = Txt, fontSize = 15.sp)
            }
            if (atts != null) {
                for (a in atts.objects()) AttachmentView(a)
            }
            if (poll != null) PollView(poll) { choice -> onVote(id, choice) }
            Row(Modifier.align(Alignment.End), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(timeOfDay(parseIso(m.optString("createdAt"))), color = WaMuted, fontSize = 11.sp)
                if (mine && !deleted) {
                    if (dmMode) {
                        val read = !m.isNull("readAt")
                        Text(if (read) "\u2713\u2713" else "\u2713\u2713", color = if (read) WaTick else WaMuted, fontSize = 12.sp)
                    } else {
                        val n = seenNames?.size ?: 0
                        Text("\u2713\u2713", color = if (n > 0) WaTick else WaMuted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun PollDialog(onDismiss: () -> Unit, onCreate: (JSONObject) -> Unit) {
    var question by remember { mutableStateOf("") }
    val options = remember { mutableStateListOf("", "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF101722),
        title = { Text("Create a poll", color = Txt) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(question, { question = it }, "Question", Modifier.fillMaxWidth())
                for (i in options.indices) {
                    Field(options[i], { options[i] = it }, "Option ${i + 1}", Modifier.fillMaxWidth())
                }
                if (options.size < 6) {
                    Text(
                        "+ Add option", color = Cyan, fontSize = 14.sp,
                        modifier = Modifier.clickable { options.add("") }.padding(6.dp)
                    )
                }
            }
        },
        confirmButton = {
            NeonButton("Post poll", {
                val opts = options.map { it.trim() }.filter { it.isNotEmpty() }
                if (question.isBlank() || opts.size < 2) {
                    Repo.toast("Add a question and at least 2 options")
                } else {
                    val counts = JSONArray()
                    for (o in opts) counts.put(0)
                    onCreate(
                        JSONObject().put("question", question.trim()).put("options", JSONArray(opts))
                            .put("voters", JSONObject()).put("counts", counts)
                    )
                }
            })
        },
        dismissButton = { NeonButton("Cancel", onDismiss, secondary = true) }
    )
}

@Composable
private fun AttachmentView(a: JSONObject) {
    val ctx = LocalContext.current
    val url = a.optString("url")
    val type = a.optString("type")
    val name = a.optString("name", "file")
    if (url.isBlank()) return
    when {
        type.startsWith("image/") -> RemoteImage(
            url,
            Modifier
                .fillMaxWidth()
                .heightIn(max = 260.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable { openUrl(ctx, url, type) }
        )
        type.startsWith("audio/") -> AudioChip(url)
        else -> {
            val icon = if (type.startsWith("video/")) "\u25B6  " else "\uD83D\uDCCE  "
            Text(
                icon + name,
                color = Cyan, fontSize = 14.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Panel)
                    .clickable { openUrl(ctx, url, type) }
                    .padding(12.dp)
            )
        }
    }
}

@Composable
private fun AudioChip(url: String) {
    var playing by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(url) {
        onDispose {
            try {
                player?.release()
            } catch (e: Exception) {
                // ignore
            }
            player = null
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Panel)
            .clickable {
                val cur = player
                if (cur != null && playing) {
                    cur.pause()
                    playing = false
                } else if (cur != null) {
                    cur.start()
                    playing = true
                } else {
                    try {
                        val mp = MediaPlayer()
                        mp.setDataSource(url)
                        mp.setOnPreparedListener { it.start(); playing = true }
                        mp.setOnCompletionListener { playing = false; it.seekTo(0) }
                        mp.prepareAsync()
                        player = mp
                    } catch (e: Exception) {
                        Repo.toast("Could not play this voice message")
                    }
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(if (playing) "\u23F8" else "\u25B6", color = Cyan, fontSize = 20.sp)
        Text("Voice message", color = Txt, fontSize = 14.sp)
    }
}

@Composable
private fun PollView(poll: JSONObject, onVote: (Int) -> Unit) {
    val question = poll.optString("question")
    val options = poll.optJSONArray("options")?.strings() ?: emptyList()
    val counts = poll.optJSONArray("counts")
    val voters = poll.optJSONObject("voters")
    val mine = if (voters != null && voters.has(Repo.userId)) voters.optInt(Repo.userId, -1) else -1
    val c = options.indices.map { counts?.optInt(it, 0) ?: 0 }
    val total = c.sum()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("\uD83D\uDCCA $question", color = Txt, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        for ((i, o) in options.withIndex()) {
            val frac = if (total == 0) 0f else c[i] / total.toFloat()
            val shape = RoundedCornerShape(10.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Panel)
                    .border(1.dp, if (mine == i) Cyan else Line, shape)
                    .clickable { onVote(i) }
            ) {
                if (frac > 0f) {
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .heightIn(min = 40.dp)
                            .background(Violet.copy(alpha = 0.35f))
                    )
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text((if (mine == i) "\u2713 " else "") + o, color = Txt, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("${c[i]}", color = Muted, fontSize = 13.sp)
                }
            }
        }
        Text("$total vote${if (total == 1) "" else "s"}", color = Muted, fontSize = 11.sp)
    }
}
