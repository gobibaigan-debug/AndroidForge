package com.icse.studytracker.notifications

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Instant "something happened" pings through Supabase Realtime (Broadcast).
 * The ping carries no message text: the receiving phone wakes up and fetches the real data from the Floot server.
 */
object Supabase {
    const val BASE = "https://gmsiuepyvbxhaodqkryi.supabase.co"
    const val WS = "wss://gmsiuepyvbxhaodqkryi.supabase.co/realtime/v1/websocket"
    const val ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imdtc2l1ZXB5dmJ4aGFvZHFrcnlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA5NzIxNzYsImV4cCI6MjEwNjU0ODE3Nn0.D8RVYh-rbiZ4BMS7-w-tEE92mngzVM-WJpYXN0cKkJU"
    const val TOPIC = "icse-pings"

    /** Blocking call: run it off the main thread. Failures are ignored (the 20-second check still catches the message). */
    fun sendPing(payload: JSONObject) {
        try {
            val conn = URL("$BASE/realtime/v1/api/broadcast").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("apikey", ANON)
                conn.setRequestProperty("Authorization", "Bearer $ANON")
                val msg = JSONObject()
                    .put("topic", TOPIC)
                    .put("event", "ping")
                    .put("payload", payload)
                    .put("private", false)
                val body = JSONObject().put("messages", JSONArray().put(msg)).toString().toByteArray(Charsets.UTF_8)
                conn.outputStream.use { it.write(body) }
                conn.responseCode
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}
