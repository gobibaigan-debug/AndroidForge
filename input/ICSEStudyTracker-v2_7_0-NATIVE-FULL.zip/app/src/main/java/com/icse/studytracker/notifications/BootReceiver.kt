package com.icse.studytracker.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.icse.studytracker.data.AppState

/** Restarts the instant-notification service after the phone restarts or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val state = AppState(context)
        if (state.cookie != null && state.notificationsEnabled) LiveNotifyService.start(context)
    }
}
