package com.icse.studytracker.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.addDays
import com.icse.studytracker.data.addMonths
import com.icse.studytracker.data.daysBetween
import com.icse.studytracker.data.prettyDate
import com.icse.studytracker.data.todayKey
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private fun pickDate(ctx: Context, initial: String, onPick: (String) -> Unit) {
    val cal = Calendar.getInstance()
    try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(initial)
        if (d != null) cal.time = d
    } catch (e: Exception) {
        // use today
    }
    android.app.DatePickerDialog(
        ctx,
        { _, y, m, d -> onPick(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)) },
        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}

@Composable
fun PlannerScreen() {
    val ctx = LocalContext.current
    var exam by remember { mutableStateOf(Repo.examDate()) }
    var finishBy by remember { mutableStateOf(Repo.finishBy()) }
    val today = todayKey()
    val tasks = Repo.todaysTasks()
    val doneTasks = tasks.count { Repo.isFinished(it) }
    val remaining = Repo.totalChapters() - Repo.finishedChapters()
    val planFinish = Repo.finishBy()
    val daysLeft = if (planFinish.isBlank()) 0 else Math.max(0, daysBetween(today, planFinish))

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("EXAM PLANNER")
            H1("Plan your annual exam")
            MutedText("Choose your exam date and the date by which you want to finish the whole syllabus. The app splits the unfinished chapters into daily tasks, and keeps the last two months for revision.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    MutedText("Exam date")
                    NeonButton(if (exam.isBlank()) "Pick date" else prettyDate(exam), {
                        pickDate(ctx, if (exam.isBlank()) addMonths(today, 4) else exam) { picked ->
                            exam = picked
                            if (finishBy.isBlank() || finishBy > picked) {
                                val auto = addMonths(picked, -2)
                                finishBy = if (auto > today) auto else addDays(today, 1)
                            }
                        }
                    }, Modifier.fillMaxWidth(), secondary = true)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    MutedText("Finish syllabus by")
                    NeonButton(if (finishBy.isBlank()) "Pick date" else prettyDate(finishBy), {
                        pickDate(ctx, if (finishBy.isBlank()) addMonths(today, 2) else finishBy) { picked -> finishBy = picked }
                    }, Modifier.fillMaxWidth(), secondary = true)
                }
            }
            NeonButton("Build my plan", {
                when {
                    exam.isBlank() -> Repo.toast("Pick your exam date first")
                    exam <= today -> Repo.toast("The exam date must be in the future")
                    finishBy.isBlank() -> Repo.toast("Pick the date you want to finish the syllabus")
                    finishBy < today -> Repo.toast("Finish date cannot be in the past")
                    finishBy > exam -> Repo.toast("Finish the syllabus before the exam date")
                    else -> {
                        Repo.buildPlan(exam, finishBy)
                        Repo.toast("Plan saved \u2014 your daily tasks are ready")
                    }
                }
            }, Modifier.fillMaxWidth())
            if (Repo.plan != null) {
                NeonButton("Clear plan", { Repo.clearPlan(); exam = ""; finishBy = "" }, Modifier.fillMaxWidth(), secondary = true)
            }
        }

        if (Repo.plan != null) {
            NeonCard {
                Kicker("YOUR PLAN")
                Row(Modifier.fillMaxWidth()) {
                    Stat("EXAM", prettyDate(Repo.examDate()), Modifier.weight(1f))
                    Stat("FINISH BY", prettyDate(planFinish), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("DAYS LEFT", "$daysLeft", Modifier.weight(1f))
                    Stat("CHAPTERS LEFT", "$remaining", Modifier.weight(1f))
                }
                if (daysLeft > 0 && remaining > 0) {
                    val pace = Math.ceil(remaining / (daysLeft + 1.0)).toInt()
                    MutedText("Keep a pace of about $pace chapter${if (pace == 1) "" else "s"} a day.")
                }
                MutedText("Revision starts on ${prettyDate(addMonths(Repo.examDate(), -2))}.")
            }
        }

        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Kicker("TODAY'S TASKS")
                Text("  $doneTasks/${tasks.size}", color = Txt, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            if (tasks.isEmpty()) {
                MutedText(if (Repo.plan == null) "Build a plan above to get a daily checklist." else "Nothing scheduled today \u2014 great job staying ahead!")
            } else {
                ProgressBar(doneTasks / tasks.size.toFloat())
                for (k in tasks) TaskRow(k)
                MutedText("Ticking a task marks Read, Notes and Practice for that chapter.")
            }
        }

        val upcoming = Repo.upcoming(7)
        if (upcoming.isNotEmpty()) {
            NeonCard {
                Kicker("COMING UP")
                for ((d, keys) in upcoming) {
                    Column(Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(prettyDate(d), color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        for (k in keys) {
                            val s = k.substringBefore("::")
                            Text("\u2022 ${k.substringAfter("::")}  (${s})", color = Txt, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
