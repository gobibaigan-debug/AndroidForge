package com.icse.studytracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.StudyRow
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.fmtDur
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private class Buckets(val stacks: List<Map<String, Float>>, val labels: List<String>)

private fun stackFor(rows: List<StudyRow>): Map<String, Float> {
    val m = LinkedHashMap<String, Float>()
    for (r in rows) m[r.subject] = (m[r.subject] ?: 0f) + r.seconds / 60f
    return m
}

private fun buildBuckets(period: String, rows: List<StudyRow>): Buckets {
    val now = System.currentTimeMillis()
    val stacks = ArrayList<Map<String, Float>>()
    val labels = ArrayList<String>()
    when (period) {
        "Day" -> {
            val cal = Calendar.getInstance()
            val today = com.icse.studytracker.data.todayKey()
            val todays = rows.filter { com.icse.studytracker.data.dayKey(it.at) == today }
            for (h in 0 until 24) {
                stacks.add(stackFor(todays.filter { r ->
                    cal.timeInMillis = r.at
                    cal.get(Calendar.HOUR_OF_DAY) == h
                }))
                labels.add(if (h % 6 == 0) (if (h == 0) "12a" else if (h == 12) "12p" else if (h < 12) "${h}a" else "${h - 12}p") else "")
            }
        }
        "Week", "Month" -> {
            val n = if (period == "Week") 7 else 30
            val fmtDay = SimpleDateFormat("EEE", Locale.getDefault())
            for (i in n - 1 downTo 0) {
                val dayMs = now - i * 86400000L
                val key = com.icse.studytracker.data.dayKey(dayMs)
                stacks.add(stackFor(rows.filter { com.icse.studytracker.data.dayKey(it.at) == key }))
                if (period == "Week") labels.add(fmtDay.format(java.util.Date(dayMs)))
                else labels.add(if (i % 5 == 0) key.substring(8) else "")
            }
        }
        else -> {
            val fmtMonth = SimpleDateFormat("MMM", Locale.getDefault())
            val cal = Calendar.getInstance()
            cal.set(Calendar.DAY_OF_MONTH, 1)
            for (i in 11 downTo 0) {
                val c = cal.clone() as Calendar
                c.add(Calendar.MONTH, -i)
                val ym = SimpleDateFormat("yyyy-MM", Locale.US).format(c.time)
                stacks.add(stackFor(rows.filter { com.icse.studytracker.data.dayKey(it.at).startsWith(ym) }))
                labels.add(fmtMonth.format(c.time).take(3))
            }
        }
    }
    return Buckets(stacks, labels)
}

private fun inPeriod(period: String, r: StudyRow): Boolean {
    val now = System.currentTimeMillis()
    return when (period) {
        "Day" -> com.icse.studytracker.data.dayKey(r.at) == com.icse.studytracker.data.todayKey()
        "Week" -> r.at >= now - 7 * 86400000L
        "Month" -> r.at >= now - 30 * 86400000L
        else -> r.at >= now - 365 * 86400000L
    }
}

@Composable
fun StatsScreen() {
    var period by remember { mutableStateOf("Week") }
    val rows = Repo.rows
    val filtered = rows.filter { inPeriod(period, it) }
    val buckets = buildBuckets(period, rows)
    val totalSecs = filtered.sumOf { it.seconds.toLong() }

    val bySubject = filtered.groupBy { it.subject }.mapValues { e -> e.value.sumOf { it.seconds.toLong() } }
        .entries.sortedByDescending { it.value }
    val byTopic = filtered.filter { it.chapter.isNotBlank() }.groupBy { it.subject + " \u2022 " + it.chapter }
        .mapValues { e -> e.value.sumOf { it.seconds.toLong() } }.entries.sortedByDescending { it.value }.take(8)

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("STUDY STATS")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (p in listOf("Day", "Week", "Month", "Year")) Chip(p, p == period, { period = p })
            }
            Row(Modifier.fillMaxWidth()) {
                Stat("TIME STUDIED", fmtDur(totalSecs), Modifier.weight(1f))
                Stat("SESSIONS", "${filtered.size}", Modifier.weight(1f))
                Stat("AVERAGE", if (filtered.isEmpty()) "0m" else fmtDur(totalSecs / filtered.size), Modifier.weight(1f))
            }
        }

        NeonCard {
            Kicker("TIME STUDIED (MINUTES) \u00B7 COLOURED BY SUBJECT")
            StackedBars(buckets.stacks, buckets.labels, 130)
            if (totalSecs == 0L) MutedText("No study time in this period yet.")
            for (e in bySubject) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Syllabus.colorOf(e.key))
                    )
                    Text(e.key, color = Muted, fontSize = 11.sp)
                }
            }
        }

        NeonCard {
            Kicker("BY SUBJECT")
            if (bySubject.isEmpty()) {
                MutedText("Study something and the pie chart appears here.")
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Donut(bySubject.map { Pair(it.value.toFloat(), Syllabus.colorOf(it.key)) }, 170, fmtDur(totalSecs))
                }
                for (e in bySubject) {
                    val pct = if (totalSecs == 0L) 0 else Math.round(e.value * 100f / totalSecs)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(Syllabus.colorOf(e.key))
                        )
                        Text(e.key, color = Txt, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        MutedText("${fmtDur(e.value)} \u00B7 $pct%", size = 13)
                    }
                }
            }
        }

        NeonCard {
            Kicker("BY TOPIC")
            if (byTopic.isEmpty()) {
                MutedText("Add a topic when you save a session to see topic-wise time.")
            } else {
                val top = byTopic.first().value.toFloat()
                for (e in byTopic) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(top = 4.dp)) {
                        Row(Modifier.fillMaxWidth()) {
                            Text(e.key, color = Txt, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 2)
                            MutedText(fmtDur(e.value), size = 13)
                        }
                        ProgressBar(e.value / top, tint = Syllabus.colorOf(e.key.substringBefore(" \u2022 ")))
                    }
                }
            }
        }
    }
}
