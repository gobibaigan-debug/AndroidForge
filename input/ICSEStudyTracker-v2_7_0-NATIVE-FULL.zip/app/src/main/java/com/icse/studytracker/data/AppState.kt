package com.icse.studytracker.data

import android.content.Context

/** Small SharedPreferences wrapper used by the UI, the API client and the background workers. */
class AppState(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("tracker", Context.MODE_PRIVATE)

    fun str(key: String, def: String = ""): String = p.getString(key, def) ?: def
    fun put(key: String, value: String) { p.edit().putString(key, value).apply() }
    fun bool(key: String, def: Boolean = false): Boolean = p.getBoolean(key, def)
    fun putBool(key: String, value: Boolean) { p.edit().putBoolean(key, value).apply() }
    fun remove(key: String) { p.edit().remove(key).apply() }
    fun long(key: String, def: Long = 0L): Long = p.getLong(key, def)
    fun putLong(key: String, value: Long) { p.edit().putLong(key, value).apply() }

    var cookie: String?
        get() = p.getString("cookie", null)
        set(v) {
            if (v == null) p.edit().remove("cookie").apply() else p.edit().putString("cookie", v).apply()
        }

    var userId: String
        get() = str("userId")
        set(v) { put("userId", v) }

    var userName: String
        get() = str("userName")
        set(v) { put("userName", v) }

    var email: String
        get() = str("email")
        set(v) { put("email", v) }

    var lastNotificationAt: String
        get() = str("lastNotificationAt")
        set(v) { put("lastNotificationAt", v) }

    var notificationsEnabled: Boolean
        get() = bool("notificationsEnabled", true)
        set(v) { putBool("notificationsEnabled", v) }

    /** Signs the user out but keeps the e-mail and every "keep_" value (such as the exam plan). */
    fun logout() {
        val lastEmail = email
        val keep = HashMap<String, String>()
        for ((k, v) in p.all) {
            if (k.startsWith("keep_") && v is String) keep[k] = v
        }
        val ed = p.edit()
        ed.clear()
        for ((k, v) in keep) ed.putString(k, v)
        ed.putString("lastEmail", lastEmail)
        ed.apply()
    }
}
