package com.icse.studytracker.focus

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Sends the user back to the home screen whenever a blocked app comes to the foreground
 * while a Focus Mode session is running.
 */
class FocusAccessibilityService : AccessibilityService() {
    private var lastToast = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        val prefs = FocusPrefs(this)
        if (!prefs.isActive()) return
        if (!prefs.packages().contains(pkg)) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        val now = System.currentTimeMillis()
        if (now - lastToast > 2500L) {
            lastToast = now
            Toast.makeText(this, "Focus Mode is on \u2014 back to studying!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInterrupt() {
        // nothing to clean up
    }
}
