package com.icse.studytracker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.fmtDur

@Composable
fun BoardScreen() {
    LaunchedEffect(Unit) { Repo.loadBoard(Repo.boardPeriod) }
    val periods = listOf("day" to "Today", "week" to "Week", "month" to "Month", "all" to "All time")
    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("LEADERBOARD")
            H1("Who studied the most?")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((key, label) in periods) Chip(label, key == Repo.boardPeriod, { Repo.loadBoard(key) })
            }
        }
        NeonCard {
            if (Repo.boardLoading && Repo.board.isEmpty()) MutedText("Loading\u2026")
            if (!Repo.boardLoading && Repo.board.isEmpty()) MutedText("Nobody has studied in this period yet. Be the first!")
            for ((i, r) in Repo.board.withIndex()) {
                val mine = r.name == Repo.userName
                val medal = when (i) { 0 -> "\uD83E\uDD47"; 1 -> "\uD83E\uDD48"; 2 -> "\uD83E\uDD49"; else -> "${i + 1}." }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(medal, color = Txt, fontSize = 18.sp, modifier = Modifier.padding(end = 2.dp))
                    Avatar(r.name, 32, if (mine) Cyan else Violet)
                    Column(Modifier.weight(1f)) {
                        Text(
                            r.name + if (mine) " (you)" else "",
                            color = if (mine) Cyan else Txt, fontWeight = FontWeight.SemiBold, fontSize = 15.sp
                        )
                        if (Repo.boardPeriod == "all") MutedText("\uD83D\uDD25 ${r.streak} day streak", size = 11)
                    }
                    Text(if (r.seconds <= 0L) "<1m" else fmtDur(r.seconds), color = Txt, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
