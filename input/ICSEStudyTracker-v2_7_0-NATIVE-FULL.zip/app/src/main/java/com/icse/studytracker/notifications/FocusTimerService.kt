package com.icse.studytracker.notifications

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.icse.studytracker.MainActivity
import com.icse.studytracker.focus.FocusPrefs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps a persistent notification while Focus Mode is active and ends the session on time. */
class FocusTimerService : Service() {
    companion object {
        const val ACTION_START = "com.icse.studytracker.FOCUS_START"
        const val ACTION_STOP = "com.icse.studytracker.FOCUS_STOP"
        private const val NOTIFICATION_ID = 7

        fun start(context: Context) {
            val i = Intent(context, FocusTimerService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, FocusTimerService::class.java).setAction(ACTION_STOP))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val finishRunnable = Runnable { finishSession() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.channels(this)
        val prefs = FocusPrefs(this)
        if (intent?.action == ACTION_STOP) {
            prefs.stop()
            shutDown()
            return START_NOT_STICKY
        }
        val endAt = prefs.endAt()
        if (endAt <= System.currentTimeMillis()) {
            shutDown()
            return START_NOT_STICKY
        }
        val ends = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(endAt))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, NotificationHelper.FOCUS_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Focus Mode is on")
            .setContentText("Distracting apps are blocked until $ends")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        handler.removeCallbacks(finishRunnable)
        handler.postDelayed(finishRunnable, endAt - System.currentTimeMillis())
        return START_NOT_STICKY
    }

    private fun finishSession() {
        FocusPrefs(this).stop()
        shutDown()
    }

    private fun shutDown() {
        handler.removeCallbacks(finishRunnable)
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(finishRunnable)
        super.onDestroy()
    }
}
