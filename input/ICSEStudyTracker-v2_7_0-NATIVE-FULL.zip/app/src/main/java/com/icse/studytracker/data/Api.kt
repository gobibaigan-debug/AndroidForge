package com.icse.studytracker.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Client for the Floot backend.
 *
 * The Floot server speaks "SuperJSON": every request body must be wrapped as {"json": ...}
 * and every response is wrapped the same way. This class hides that wrapping.
 */
object Api {
    const val BASE = "https://icse-study-tracker-neon.floot.app"
    private const val COOKIE_NAME = "floot_built_app_session"

    class ApiException(message: String, val status: Int) : Exception(message)

    private lateinit var state: AppState

    fun init(context: Context) {
        if (!::state.isInitialized) state = AppState(context.applicationContext)
    }

    private class Resp(val status: Int, val body: String, val cookie: String?)

    private fun post(path: String, payload: JSONObject): Resp {
        val conn = URL(BASE + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.doInput = true
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "application/json")
            val ck = state.cookie
            if (!ck.isNullOrBlank()) conn.setRequestProperty("Cookie", ck)
            val bytes = JSONObject().put("json", payload).toString().toByteArray(Charsets.UTF_8)
            conn.outputStream.use { it.write(bytes) }
            val status = conn.responseCode
            val stream = if (status in 200..399) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            var newCookie: String? = null
            for ((k, values) in conn.headerFields) {
                if (k != null && k.equals("Set-Cookie", ignoreCase = true)) {
                    for (h in values) {
                        val pair = h.substringBefore(';').trim()
                        if (pair.startsWith("$COOKIE_NAME=") && pair.length > COOKIE_NAME.length + 1) newCookie = pair
                    }
                }
            }
            return Resp(status, text, newCookie)
        } catch (e: IOException) {
            throw ApiException("Cannot reach the server. Check your internet connection.", 0)
        } finally {
            conn.disconnect()
        }
    }

    /** Removes the SuperJSON wrapper. Returns a JSONObject, a JSONArray or null. */
    private fun unwrap(text: String): Any? {
        val t = text.trim()
        if (t.isEmpty()) return null
        return try {
            val root = JSONObject(t)
            if (root.has("json")) {
                val inner = root.opt("json")
                if (inner == JSONObject.NULL) null else inner
            } else {
                root
            }
        } catch (e: Exception) {
            try { JSONArray(t) } catch (e2: Exception) { null }
        }
    }

    private fun errorText(resp: Resp, fallback: String): String {
        val u = unwrap(resp.body)
        if (u is JSONObject) {
            val m = u.optString("message", "")
            if (m.isNotBlank()) return m
            val e = u.optString("error", "")
            if (e.isNotBlank()) return e
        }
        val raw = resp.body.trim()
        return if (raw.isNotEmpty() && !raw.startsWith("<")) "$fallback: ${raw.take(140)}" else "$fallback (HTTP ${resp.status})"
    }

    private fun saveSession(resp: Resp) {
        val c = resp.cookie
        if (c != null) state.cookie = c
    }

    /** Returns the user object. */
    fun login(email: String, password: String): JSONObject {
        val body = JSONObject().put("email", email.trim().lowercase()).put("password", password)
        val resp = post("/_api/auth/login_with_password", body)
        if (resp.status !in 200..299) throw ApiException(errorText(resp, "Login failed"), resp.status)
        saveSession(resp)
        if (state.cookie.isNullOrBlank()) throw ApiException("The server did not start a session. Please try again.", resp.status)
        val u = unwrap(resp.body) as? JSONObject
        return u?.optJSONObject("user") ?: JSONObject()
    }

    fun register(name: String, email: String, password: String): JSONObject {
        val body = JSONObject()
            .put("email", email.trim().lowercase())
            .put("password", password)
            .put("displayName", name.trim())
        val resp = post("/_api/auth/register_with_password", body)
        if (resp.status !in 200..299) throw ApiException(errorText(resp, "Registration failed"), resp.status)
        saveSession(resp)
        if (state.cookie.isNullOrBlank()) return login(email, password)
        val u = unwrap(resp.body) as? JSONObject
        return u?.optJSONObject("user") ?: JSONObject()
    }

    /** Calls /_api/tracker and returns the "data" field (JSONObject, JSONArray or null). */
    fun tracker(action: String, payload: JSONObject = JSONObject()): Any? {
        val body = JSONObject().put("action", action).put("payload", payload)
        val resp = post("/_api/tracker", body)
        if (resp.status !in 200..299) {
            val msg = errorText(resp, "Request failed")
            val status = if (msg.contains("Not authenticated", true) || msg.contains("Sign in required", true)) 401 else resp.status
            throw ApiException(msg, status)
        }
        val u = unwrap(resp.body)
        if (u is JSONObject) {
            val d = u.opt("data")
            return if (d == null || d == JSONObject.NULL) null else d
        }
        return u
    }

    fun trackerObj(action: String, payload: JSONObject = JSONObject()): JSONObject =
        (tracker(action, payload) as? JSONObject) ?: JSONObject()

    fun trackerArr(action: String, payload: JSONObject = JSONObject()): JSONArray =
        (tracker(action, payload) as? JSONArray) ?: JSONArray()

    /** Uploads a file to Floot storage and returns {url, name, type, size}. */
    fun upload(context: Context, uri: Uri, name: String, mime: String): JSONObject {
        val resolver = context.contentResolver
        var size = -1L
        try {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.SIZE)
                    if (idx >= 0 && !c.isNull(idx)) size = c.getLong(idx)
                }
            }
        } catch (e: Exception) {
            size = -1L
        }
        var bytes: ByteArray? = null
        if (size <= 0L) {
            bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
            size = bytes.size.toLong()
        }
        if (size <= 0L) throw ApiException("The selected file is empty.", 0)
        if (size > 100L * 1024 * 1024) throw ApiException("Files must be 100 MB or smaller.", 0)

        val body = JSONObject()
            .put("filename", name.take(150))
            .put("contentType", mime)
            .put("sizeBytes", size)
            .put("visibility", "private")
        val resp = post("/_api/upload", body)
        if (resp.status !in 200..299) throw ApiException(errorText(resp, "Upload failed"), resp.status)
        val root = unwrap(resp.body) as? JSONObject ?: throw ApiException("Upload failed", resp.status)
        val data = root.optJSONObject("data") ?: throw ApiException("Upload failed", resp.status)
        val presigned = data.optString("presignedUrl")
        val fileUrl = data.optString("url")
        if (presigned.isBlank() || fileUrl.isBlank()) throw ApiException("Upload failed", resp.status)

        val put = URL(presigned).openConnection() as HttpURLConnection
        try {
            put.requestMethod = "PUT"
            put.doOutput = true
            put.connectTimeout = 20000
            put.readTimeout = 120000
            put.setFixedLengthStreamingMode(size)
            val headers = data.optJSONObject("headers")
            if (headers != null) {
                val keys = headers.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    put.setRequestProperty(k, headers.optString(k))
                }
            }
            if (bytes != null) {
                put.outputStream.use { it.write(bytes) }
            } else {
                resolver.openInputStream(uri)?.use { input -> put.outputStream.use { out -> input.copyTo(out) } }
            }
            val code = put.responseCode
            if (code !in 200..299) throw ApiException("Media upload failed (HTTP $code)", code)
        } catch (e: IOException) {
            throw ApiException("Media upload failed. Check your connection.", 0)
        } finally {
            put.disconnect()
        }
        return JSONObject().put("url", fileUrl).put("name", name).put("type", mime).put("size", size)
    }
}
