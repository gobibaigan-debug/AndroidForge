package com.icse.studytracker.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Syllabus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

val BG = Color(0xFF080B12)
val CardTop = Color(0xFF121A25)
val CardBottom = Color(0xFF0E141E)
val Line = Color(0xFF24344A)
val Cyan = Color(0xFF55E6EF)
val Violet = Color(0xFF8F8FFF)
val Txt = Color(0xFFEEF4FF)
val Muted = Color(0xFF91A0B9)
val Good = Color(0xFF36D67C)
val Bad = Color(0xFFFF6B6B)
val Hot = Color(0xFFFF3B81)
val FieldBg = Color(0xFF0A1018)
val Track = Color(0xFF1D2939)
val Panel = Color(0xFF101722)

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(CardTop, CardBottom)))
            .border(1.dp, Line, shape)
            .padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun Kicker(text: String) {
    Text(text, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
}

@Composable
fun H1(text: String) {
    Text(text, color = Txt, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
}

@Composable
fun H2(text: String) {
    Text(text, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun Body(text: String, modifier: Modifier = Modifier, color: Color = Txt, size: Int = 14) {
    Text(text, color = color, fontSize = size.sp, modifier = modifier)
}

@Composable
fun MutedText(text: String, modifier: Modifier = Modifier, size: Int = 12) {
    Text(text, color = Muted, fontSize = size.sp, modifier = modifier)
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    secondary: Boolean = false
) {
    val shape = RoundedCornerShape(11.dp)
    val look = if (secondary) {
        Modifier.background(Panel, shape).border(1.dp, Line, shape)
    } else {
        Modifier.background(Brush.horizontalGradient(listOf(Cyan, Violet)), shape)
    }
    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.45f)
            .then(look)
            .clip(shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (secondary) Txt else Color(0xFF061016),
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, tint: Color = Violet) {
    val shape = RoundedCornerShape(9.dp)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) tint else Panel)
            .border(1.dp, if (selected) tint else Line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (selected) Color.White else Muted, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun TickBox(checked: Boolean, onClick: () -> Unit, label: String = "") {
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier
            .size(34.dp)
            .clip(shape)
            .background(if (checked) Good else Panel)
            .border(1.dp, if (checked) Good else Line, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (checked) "\u2713" else label,
            color = if (checked) Color(0xFF04170C) else Muted,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun ProgressBar(fraction: Float, modifier: Modifier = Modifier, height: Int = 8, tint: Color? = null) {
    val f = fraction.coerceIn(0f, 1f)
    Box(
        modifier
            .fillMaxWidth()
            .height(height.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Track)
    ) {
        if (f > 0f) {
            val fill = if (tint == null) Brush.horizontalGradient(listOf(Cyan, Violet)) else SolidColor(tint)
            Box(
                Modifier
                    .fillMaxWidth(f)
                    .fillMaxHeight()
                    .background(fill)
            )
        }
    }
}

@Composable
fun Ring(pct: Int, dia: Int = 96, caption: String = "OVERALL") {
    Box(Modifier.size(dia.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 11.dp.toPx()
            val inset = stroke / 2f
            val area = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(Track, 0f, 360f, false, topLeft = Offset(inset, inset), size = area, style = Stroke(stroke))
            drawArc(
                Cyan, -90f, 360f * pct.coerceIn(0, 100) / 100f, false,
                topLeft = Offset(inset, inset), size = area, style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$pct%", color = Txt, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(caption, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun BarChartView(values: List<Float>, labels: List<String> = emptyList(), height: Int = 120) {
    val mx = (values.maxOrNull() ?: 0f).coerceAtLeast(1f)
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(height.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (v in values) {
                val f = if (v <= 0f) 0.02f else (v / mx).coerceIn(0.04f, 1f)
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(f)
                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                        .background(Brush.verticalGradient(listOf(Cyan, Violet)))
                )
            }
        }
        if (labels.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (l in labels) {
                    Text(
                        l,
                        modifier = Modifier.weight(1f),
                        color = Muted,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun Donut(slices: List<Pair<Float, Color>>, dia: Int = 150, center: String = "") {
    var total = 0f
    for (s in slices) total += s.first
    Box(Modifier.size(dia.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 26.dp.toPx()
            val inset = stroke / 2f
            val area = Size(this.size.width - stroke, this.size.height - stroke)
            if (total <= 0f) {
                drawArc(Track, 0f, 360f, false, topLeft = Offset(inset, inset), size = area, style = Stroke(stroke))
            } else {
                var start = -90f
                for (s in slices) {
                    val sweep = 360f * s.first / total
                    drawArc(
                        s.second, start, Math.max(sweep - 2f, 0.5f), false,
                        topLeft = Offset(inset, inset), size = area, style = Stroke(stroke)
                    )
                    start += sweep
                }
            }
        }
        Text(center, color = Txt, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
    }
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    password: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text,
    minLines: Int = 1
) {
    val shape = RoundedCornerShape(10.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = singleLine,
        minLines = minLines,
        textStyle = TextStyle(color = Txt, fontSize = 15.sp),
        cursorBrush = SolidColor(Cyan),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = modifier,
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(FieldBg)
                    .border(1.dp, Line, shape)
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            ) {
                if (value.isEmpty()) Text(hint, color = Muted, fontSize = 15.sp)
                inner()
            }
        }
    )
}

@Composable
fun Avatar(name: String, dia: Int = 34, tint: Color = Violet) {
    val letter = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    Box(
        Modifier
            .size(dia.dp)
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.25f))
            .border(1.dp, tint, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = Txt, fontWeight = FontWeight.Bold, fontSize = (dia / 2.2f).sp)
    }
}

private val nameColors = listOf(
    Color(0xFF55E6EF), Color(0xFFFFB454), Color(0xFFFF7AB6), Color(0xFF9BE564),
    Color(0xFFB69CFF), Color(0xFFFF8E72), Color(0xFF5CC8FF)
)

fun colorForName(name: String): Color = nameColors[Math.abs(name.hashCode()) % nameColors.size]

/** Downloads and decodes an image, scaled down so very large photos do not run out of memory. */
fun loadRemoteBitmap(url: String, maxWidth: Int): ImageBitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        URL(url).openStream().use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > maxWidth) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        URL(url).openStream().use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    } catch (e: Exception) {
        null
    }
}

@Composable
fun RemoteImage(url: String, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, url) {
        value = withContext(Dispatchers.IO) { loadRemoteBitmap(url, 1400) }
    }
    val b = bmp
    if (b != null) {
        Image(b, contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit)
    } else {
        Box(modifier.height(120.dp).background(Panel), contentAlignment = Alignment.Center) {
            Text("Loading image\u2026", color = Muted, fontSize = 12.sp)
        }
    }
}

fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.clickable(onClick = onClick)

@Composable
fun StackedBars(stacks: List<Map<String, Float>>, labels: List<String> = emptyList(), height: Int = 130) {
    var mx = 1f
    for (st in stacks) {
        var t = 0f
        for (v in st.values) t += v
        if (t > mx) mx = t
    }
    Column(Modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(height.dp)
        ) {
            val n = stacks.size
            if (n > 0) {
                val gap = 4.dp.toPx()
                val bw = (this.size.width - gap * (n - 1)) / n
                for (i in 0 until n) {
                    val x = i * (bw + gap)
                    var y = this.size.height
                    val segs = stacks[i]
                    if (segs.isEmpty()) {
                        drawRect(Track, Offset(x, y - 2.dp.toPx()), Size(bw, 2.dp.toPx()))
                    } else {
                        for ((subject, v) in segs) {
                            val h = this.size.height * (v / mx)
                            if (h > 0f) {
                                drawRect(Syllabus.colorOf(subject), Offset(x, y - h), Size(bw, h))
                                y -= h
                            }
                        }
                    }
                }
            }
        }
        if (labels.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (l in labels) {
                    Text(
                        l,
                        modifier = Modifier.weight(1f),
                        color = Muted,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

val WaGreenColor = Color(0xFF00A884)
