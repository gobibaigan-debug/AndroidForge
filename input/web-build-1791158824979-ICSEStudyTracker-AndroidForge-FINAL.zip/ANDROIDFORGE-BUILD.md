# AndroidForge build instructions — ICSE Class 9 Study Tracker

This archive is the native Android project for **ICSE Class 9 Study Tracker**.

Expected application ID: `com.icse.studytracker`
Expected application name: `ICSE Class 9 Study Tracker`

## AndroidForge

Use AndroidForge with the existing connected GitHub repository/token.

1. Upload this ZIP as the source project.
2. Choose **debug** for the first install/test build.
3. Start the build.
4. Download the generated APK artifact.
5. Before installing, verify that the APK is named as an AndroidForge app artifact and that the installed application is **ICSE Class 9 Study Tracker**.


## Important

The project is native Kotlin + Jetpack Compose. It is not a WebView wrapper.

The Gradle wrapper properties are pinned to Gradle 8.9, compatible with the AGP 8.7.3 configuration in this project. AndroidForge can regenerate the wrapper JAR if it is absent.
