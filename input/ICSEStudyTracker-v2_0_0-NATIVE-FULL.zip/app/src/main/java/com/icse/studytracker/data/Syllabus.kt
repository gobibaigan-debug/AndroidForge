package com.icse.studytracker.data

import androidx.compose.ui.graphics.Color

/** Class IX 2026-27 annual-exam syllabus (same chapters as the web app). */
object Syllabus {
    val chapters: Map<String, List<String>> = linkedMapOf(
        "Physics" to listOf(
            "Laws of Motion",
            "Pressure in Fluids and Atmospheric Pressure",
            "Upthrust in Fluids, Archimedes' Principle and Floatation",
            "Reflection of Light",
            "Propagation of Sound Waves"
        ),
        "Chemistry" to listOf(
            "The Periodic Table",
            "Study of the First Element \u2014 Hydrogen",
            "Study of Gas Laws",
            "Periodic Table, Periodic Properties and Variation of Properties",
            "Chemical Bonding"
        ),
        "Biology" to listOf(
            "Economic Importance of Bacteria and Fungi",
            "Nutrition",
            "Skeleton: Movement and Locomotion",
            "Structure and Functions of Skin",
            "The Respiratory System",
            "Health and Hygiene",
            "Aids to Health",
            "Water Generation and Management"
        ),
        "Mathematics" to listOf(
            "Compound Interest",
            "Simultaneous Linear Equations",
            "Problems on Simultaneous Linear Equations",
            "Indices",
            "Midpoint Theorem",
            "Rectilinear Figures",
            "Theorems on Area",
            "Mensuration",
            "Co-ordinate Geometry",
            "Statistics"
        ),
        "History & Civics" to listOf(
            "History: South India and the Cholas",
            "History: The Delhi Sultanate",
            "History: The Mughal Empire",
            "History: The Composite Culture",
            "History: The Renaissance",
            "History: The Reformation",
            "History: Industrial Revolution, Capitalism and Socialism",
            "History Revision: Harappan Civilization",
            "History Revision: The Mauryan Empire",
            "History Revision: The Sangam Age",
            "History Revision: The Age of the Guptas",
            "Civics: Our Constitution and its Salient Features",
            "Civics: Elections and the Election Commission",
            "Civics: The State Legislatures"
        ),
        "Geography" to listOf(
            "Hydrosphere",
            "The Atmosphere",
            "Insolation",
            "Atmospheric Pressure and Winds",
            "Humidity",
            "Types of Pollution",
            "Sources of Pollution",
            "Effects and Preventive Measures of Pollution",
            "Major Natural Regions of the World",
            "Map Work"
        ),
        "Computer" to listOf(
            "Introduction to Object Oriented Programming Concepts",
            "Elementary Concept of Objects and Classes",
            "Values and Data Types",
            "Operators in Java",
            "Input in Java",
            "Mathematical Library Methods",
            "Conditional Statements in Java",
            "Iterative Constructs in Java",
            "Nested Loops"
        ),
        "English" to listOf(
            "English I: Unseen Composition",
            "English I: Letter Writing (Formal and Informal)",
            "English I: Notice and E-mail Writing",
            "English I: Unseen Comprehension",
            "English I: Grammar (Verbs, Prepositions, Joining Sentences)",
            "English I: Do as Directed (Transformation, Voice, Narration)",
            "Julius Caesar: Act II, Scenes I\u2013IV",
            "Julius Caesar: Act I, Scenes I\u2013III (Revision)",
            "Poem: I Remember, I Remember",
            "Poem: Skimbleshanks: The Railway Cat",
            "Poem: A Work of Artifice",
            "Prose: The Home Coming",
            "Prose: The Boy Who Broke the Bank",
            "Prose: The Model Millionaire",
            "Prose: Oliver Asks for More"
        ),
        "Commercial Studies" to listOf(
            "Finance and Accounts",
            "Human Resources",
            "Production",
            "Communication in Commercial Organisation",
            "Different Methods of Communication",
            "Meaning, Objectives and Terminology of Accounting",
            "Basic Accounting Principles and Concepts",
            "Banking",
            "Trade",
            "Social Responsibility towards the Environment",
            "Revision: Partnership",
            "Revision: Joint Stock Company",
            "Revision: Accounting Books and Statements"
        ),
        "Physical Education" to listOf(
            "Section A: Respiratory System",
            "Section A: Games and Sports",
            "Section A: Circulatory System",
            "Section B: Cricket",
            "Section B: Badminton"
        )
    )

    val allSubjects: List<String> = chapters.keys.toList()

    private val science = listOf(
        "Physics", "Chemistry", "Biology", "Mathematics", "History & Civics", "Geography", "Computer", "English"
    )
    private val commerce = listOf(
        "Commercial Studies", "Physical Education", "Mathematics", "History & Civics", "Geography", "Computer", "English"
    )

    fun subjectsFor(stream: String): List<String> =
        if (stream.contains("commerce", ignoreCase = true)) commerce else science

    fun chaptersOf(subject: String): List<String> = chapters[subject] ?: emptyList()

    fun key(subject: String, chapter: String): String = "$subject::$chapter"

    fun allKeys(stream: String): List<String> =
        subjectsFor(stream).flatMap { s -> chaptersOf(s).map { c -> key(s, c) } }

    fun colorOf(subject: String): Color = when (subject) {
        "Physics" -> Color(0xFFE8590C)
        "Chemistry" -> Color(0xFF7048E8)
        "Biology" -> Color(0xFF2F9E44)
        "Mathematics" -> Color(0xFF1C7ED6)
        "History & Civics" -> Color(0xFFC2255C)
        "Geography" -> Color(0xFF1098AD)
        "Computer" -> Color(0xFF8F8FFF)
        "English" -> Color(0xFFD6336C)
        "Commercial Studies" -> Color(0xFF087F5B)
        "Physical Education" -> Color(0xFFF08C00)
        else -> Color(0xFF55E6EF)
    }
}
