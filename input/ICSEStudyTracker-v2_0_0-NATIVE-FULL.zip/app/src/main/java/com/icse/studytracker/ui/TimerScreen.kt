package com.icse.studytracker.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.FAIL_PHRASE
import com.icse.studytracker.data.GradeResult
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.fmtClock
import com.icse.studytracker.data.fmtDur
import com.icse.studytracker.data.timeOfDay
import kotlinx.coroutines.launch

@Composable
fun TimerScreen() {
    val scope = rememberCoroutineScope()
    val subjects = Syllabus.subjectsFor(Repo.stream)
    val subject = if (subjects.contains(Repo.timerSubject)) Repo.timerSubject else subjects.first()
    var showChapters by remember { mutableStateOf(false) }

    var minutes by remember { mutableStateOf("30") }
    var step by remember { mutableStateOf(0) }
    var questions by remember { mutableStateOf<List<String>>(emptyList()) }
    val answers = remember { mutableStateListOf("", "", "", "", "") }
    var result by remember { mutableStateOf<GradeResult?>(null) }
    var message by remember { mutableStateOf("") }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("STUDY TIMER")
            Text(
                fmtClock(Repo.timerSeconds()),
                color = Txt, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            MutedText(
                if (Repo.timerRunning) "Running \u2014 you can leave the app, the timer keeps counting." else "Pick what you are studying, then press Start.",
                Modifier.fillMaxWidth()
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (s in subjects) Chip(s, s == subject, { Repo.timerSetSubject(s) }, Syllabus.colorOf(s))
            }
            Field(Repo.timerTopic, { Repo.timerSetTopic(it) }, "Topic / chapter (optional)", Modifier.fillMaxWidth())
            Chip(if (showChapters) "Hide chapters" else "Choose from ${subject} chapters", false, { showChapters = !showChapters })
            if (showChapters) {
                for (c in Syllabus.chaptersOf(subject)) {
                    Text(
                        c,
                        color = if (Repo.timerTopic == c) Cyan else Txt,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickableNoRipple { Repo.timerSetTopic(c); showChapters = false }
                            .padding(vertical = 7.dp)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton(if (Repo.timerRunning) "Pause" else if (Repo.timerSeconds() > 0) "Resume" else "Start", { Repo.timerToggle() }, Modifier.weight(1f))
                NeonButton("Save", {
                    if (!Repo.timerSave()) Repo.toast("Study for at least 5 seconds first")
                }, Modifier.weight(1f), secondary = true)
                NeonButton("Reset", { Repo.timerReset() }, Modifier.weight(1f), secondary = true)
            }
        }

        NeonCard {
            Kicker("ADD TIME MANUALLY")
            MutedText("Forgot to start the timer? Add the minutes, then answer 5 questions to prove you studied.")
            if (step == 0 || step == 1 || step == 4) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Field(minutes, { minutes = it.filter { ch -> ch.isDigit() }.take(3) }, "Minutes", Modifier.weight(1f), keyboard = KeyboardType.Number)
                    NeonButton(
                        if (step == 1) "Loading\u2026" else "Verify & add",
                        onClick = {
                            val m = minutes.toIntOrNull() ?: 0
                            if (m < 1 || m > 600) {
                                message = "Enter between 1 and 600 minutes."
                            } else if (Repo.timerTopic.isBlank()) {
                                message = "Type the topic you studied in the box above first."
                            } else {
                                message = ""
                                result = null
                                step = 1
                                scope.launch {
                                    questions = Repo.manualQuestions(subject, Repo.timerTopic.trim())
                                    for (i in 0 until 5) answers[i] = ""
                                    step = 2
                                }
                            }
                        },
                        enabled = step != 1
                    )
                }
            }
            if (message.isNotBlank()) Body(message, color = Bad, size = 13)
            if (step == 2 || step == 3) {
                for ((i, q) in questions.withIndex()) {
                    Body("${i + 1}. $q", size = 14)
                    Field(
                        answers[i], { answers[i] = it }, "Your answer",
                        Modifier.fillMaxWidth(), singleLine = false, minLines = 2
                    )
                }
                NeonButton(
                    if (step == 3) "Checking\u2026" else "Submit answers",
                    onClick = {
                        step = 3
                        val qa = questions.zip(answers.toList())
                        scope.launch {
                            val r = Repo.manualGrade(subject, Repo.timerTopic.trim(), qa)
                            result = r
                            if (r.passed) {
                                val m = minutes.toIntOrNull() ?: 0
                                Repo.recordSession(subject, Repo.timerTopic.trim(), m * 60, true)
                                Repo.toast("Verified! Added $m minutes")
                            }
                            step = 4
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = step == 2
                )
            }
            val r = result
            if (step == 4 && r != null) {
                if (r.passed) {
                    Body("\u2705 Verified (${r.correct}/5 correct). ${minutes} minutes were added to your study time.", color = Good, size = 14)
                } else {
                    Body("${r.correct}/5 correct. $FAIL_PHRASE", color = Bad, size = 15)
                    MutedText("Study the topic properly and try again \u2014 no time was added.")
                }
                for (f in r.feedback.take(5)) MutedText("\u2022 $f")
            }
        }

        NeonCard {
            Kicker("RECENT SESSIONS")
            if (Repo.rows.isEmpty()) {
                MutedText("No sessions yet \u2014 start the timer above.")
            } else {
                for (row in Repo.rows.take(10)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(row.subject, color = Syllabus.colorOf(row.subject), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            val sub = (if (row.chapter.isBlank()) "" else row.chapter + " \u00B7 ") + timeOfDay(row.at)
                            MutedText(sub + if (row.verified) " \u00B7 verified" else "" + if (row.pending) " \u00B7 syncing" else "")
                        }
                        Text(fmtDur(row.seconds.toLong()), color = Txt, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
