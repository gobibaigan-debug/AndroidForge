package com.icse.studytracker.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.Member
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.objects
import com.icse.studytracker.data.parseIso
import com.icse.studytracker.data.strings
import com.icse.studytracker.data.timeOfDay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Pick(val uri: Uri, val name: String, val mime: String)

private fun toPick(ctx: Context, uri: Uri, forcedMime: String?): Pick {
    var name = "file"
    try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i) ?: name
            }
        }
    } catch (e: Exception) {
        // keep default name
    }
    val mime = forcedMime ?: ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    return Pick(uri, name, mime)
}

private fun openUrl(ctx: Context, url: String, mime: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
        if (mime.isNotBlank()) i.setDataAndType(Uri.parse(url), mime) else i.data = Uri.parse(url)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Repo.toast("No app can open this file")
    }
}

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("community") }
    var peer by remember { mutableStateOf<Member?>(null) }
    var community by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var dm by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var picks by remember { mutableStateOf<List<Pick>>(emptyList()) }
    var sending by remember { mutableStateOf(false) }
    var pollOpen by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordFile by remember { mutableStateOf<File?>(null) }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    var pendingKind by remember { mutableStateOf("photo") }
    val seen = remember { mutableStateMapOf<String, List<String>>() }
    val marked = remember { HashSet<String>() }
    val listState = rememberLazyListState()

    suspend fun loadOnce() {
        try {
            if (mode == "community") {
                val arr = withContext(Dispatchers.IO) { Api.trackerArr("community_list") }
                val list = arr.objects().reversed()
                community = list
                val seenNow = withContext(Dispatchers.IO) {
                    var n = 0
                    for (m in list) {
                        val id = m.optString("id")
                        if (m.optString("userId") != Repo.userId && n < 25 && marked.add("c$id")) {
                            n++
                            try {
                                Api.tracker("community_read", JSONObject().put("messageId", id))
                            } catch (e: Exception) {
                                marked.remove("c$id")
                            }
                        }
                    }
                    val out = HashMap<String, List<String>>()
                    for (m in list.filter { it.optString("userId") == Repo.userId }.takeLast(4)) {
                        val id = m.optString("id")
                        try {
                            val names = Api.trackerArr("seen_by", JSONObject().put("messageId", id)).objects()
                                .map { it.optString("displayName", "Student") }
                            out[id] = names
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    out
                }
                for ((k, v) in seenNow) seen[k] = v
            } else {
                val p = peer ?: return
                val arr = withContext(Dispatchers.IO) { Api.trackerArr("dm_list", JSONObject().put("peerId", p.id)) }
                val list = arr.objects()
                dm = list
                withContext(Dispatchers.IO) {
                    for (m in list) {
                        val id = m.optString("id")
                        if (m.optString("senderId") != Repo.userId && m.isNull("readAt") && marked.add("d$id")) {
                            try {
                                Api.tracker("dm_read", JSONObject().put("messageId", id))
                            } catch (e: Exception) {
                                marked.remove("d$id")
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Repo.handleError(e)
        }
    }

    LaunchedEffect(mode, peer?.id) {
        while (true) {
            loadOnce()
            delay(4000)
        }
    }

    val shown = if (mode == "community") community else dm
    LaunchedEffect(shown.size, mode, peer?.id) {
        if (shown.isNotEmpty()) listState.scrollToItem(shown.size - 1)
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                recorder?.release()
            } catch (e: Exception) {
                // already released
            }
        }
    }
    BackHandler(enabled = mode == "dm" && peer != null) { peer = null }

    // ---------- pickers
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        picks = picks + uris.map { toPick(ctx, it, null) }
    }
    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        picks = picks + uris.map { toPick(ctx, it, null) }
    }
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = captureUri
        if (ok && u != null) picks = picks + Pick(u, "photo-${System.currentTimeMillis()}.jpg", "image/jpeg")
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        val u = captureUri
        if (ok && u != null) picks = picks + Pick(u, "video-${System.currentTimeMillis()}.mp4", "video/mp4")
    }

    fun startCapture(kind: String) {
        try {
            val dir = File(ctx.cacheDir, "capture")
            dir.mkdirs()
            val f = File(dir, if (kind == "video") "video-${System.currentTimeMillis()}.mp4" else "photo-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            captureUri = uri
            if (kind == "video") videoLauncher.launch(uri) else photoLauncher.launch(uri)
        } catch (e: Exception) {
            Repo.toast("Could not open the camera")
        }
    }

    fun startRecording() {
        try {
            val dir = File(ctx.cacheDir, "capture")
            dir.mkdirs()
            val f = File(dir, "voice-${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recordFile = f
            recording = true
        } catch (e: Exception) {
            recording = false
            Repo.toast("Could not start recording")
        }
    }

    fun stopRecording() {
        val r = recorder
        val f = recordFile
        try {
            r?.stop()
        } catch (e: Exception) {
            // too short to record
        }
        try {
            r?.release()
        } catch (e: Exception) {
            // ignore
        }
        recorder = null
        recording = false
        if (f != null && f.exists() && f.length() > 0L) {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            picks = picks + Pick(uri, f.name, "audio/mp4")
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCapture(pendingKind) else Repo.toast("Camera permission is needed")
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else Repo.toast("Microphone permission is needed")
    }

    fun needsPermission(perm: String): Boolean =
        Build.VERSION.SDK_INT >= 23 && ctx.checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED

    fun capture(kind: String) {
        pendingKind = kind
        if (needsPermission(android.Manifest.permission.CAMERA)) {
            cameraPermission.launch(android.Manifest.permission.CAMERA)
        } else {
            startCapture(kind)
        }
    }

    fun toggleRecording() {
        if (recording) {
            stopRecording()
        } else if (needsPermission(android.Manifest.permission.RECORD_AUDIO)) {
            micPermission.launch(android.Manifest.permission.RECORD_AUDIO)
        } else {
            startRecording()
        }
    }

    fun send(poll: JSONObject?) {
        val body = text.trim()
        if (body.isEmpty() && picks.isEmpty() && poll == null) return
        if (mode == "dm" && peer == null) return
        val toUpload = picks
        val isDm = mode == "dm"
        val peerId = peer?.id ?: ""
        scope.launch {
            sending = true
            try {
                val atts = JSONArray()
                for (p in toUpload) {
                    val a = withContext(Dispatchers.IO) { Api.upload(ctx, p.uri, p.name, p.mime) }
                    atts.put(a)
                }
                val kind = if (poll != null) "poll" else if (atts.length() > 0) "attachment" else "text"
                val payload = JSONObject()
                    .put("kind", kind)
                    .put("body", body)
                    .put("attachments", atts)
                    .put("poll", poll ?: JSONObject.NULL)
                if (isDm) payload.put("peerId", peerId)
                withContext(Dispatchers.IO) { Api.tracker(if (isDm) "dm_send" else "community_post", payload) }
                text = ""
                picks = emptyList()
                loadOnce()
            } catch (e: Exception) {
                Repo.toast(Repo.handleError(e))
            }
            sending = false
        }
    }

    fun vote(id: String, choice: Int) {
        val isDm = mode == "dm"
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    Api.tracker("poll_vote", JSONObject().put("messageId", id).put("choice", choice).put("isDm", isDm))
                }
                loadOnce()
            } catch (e: Exception) {
                Repo.toast(Repo.handleError(e))
            }
        }
    }

    // ---------- UI
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Chip("\uD83C\uDF10 Community", mode == "community", { mode = "community"; peer = null })
            Chip("\u2709\uFE0F Direct messages", mode == "dm", { mode = "dm" })
        }

        if (mode == "dm" && peer == null) {
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MutedText("Choose a classmate to message privately", size = 13)
                if (Repo.members.isEmpty()) MutedText("No other students have joined yet.")
                for (m in Repo.members) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Panel)
                            .border(1.dp, Line, RoundedCornerShape(14.dp))
                            .clickable {
                                dm = emptyList()
                                peer = m
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Avatar(m.name, 40, colorForName(m.name))
                        Column(Modifier.weight(1f)) {
                            Text(m.name, color = Txt, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            MutedText("\uD83D\uDD25 ${m.streak} day streak", size = 12)
                        }
                        Text("\u203A", color = Muted, fontSize = 22.sp)
                    }
                }
            }
        } else {
            val p = peer
            if (mode == "dm" && p != null) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("\u2039", color = Cyan, fontSize = 30.sp, modifier = Modifier.clickable { peer = null }.padding(horizontal = 8.dp))
                    Avatar(p.name, 34, colorForName(p.name))
                    Text(p.name, color = Txt, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            }
            if (shown.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    MutedText(if (mode == "community") "No messages yet \u2014 say hello to the class!" else "No messages yet. Say hi \uD83D\uDC4B")
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                ) {
                    items(shown, key = { it.optString("id") }) { m ->
                        val mine = if (mode == "dm") m.optString("senderId") == Repo.userId else m.optString("userId") == Repo.userId
                        Bubble(m, mine, mode == "dm", seen[m.optString("id")]) { id, choice -> vote(id, choice) }
                    }
                }
            }

            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0C121B))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (picks.isNotEmpty()) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (pk in picks) {
                            val icon = if (pk.mime.startsWith("image/")) "\uD83D\uDDBC" else if (pk.mime.startsWith("video/")) "\uD83C\uDFA5" else if (pk.mime.startsWith("audio/")) "\uD83C\uDFA4" else "\uD83D\uDCCE"
                            Chip("$icon ${pk.name.take(16)}  \u2715", false, { picks = picks - pk })
                        }
                    }
                }
                if (recording) Body("\uD83D\uDD34 Recording\u2026 tap \u23F9 to finish", color = Bad, size = 13)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToolButton("\uD83D\uDDBC") { galleryPicker.launch(arrayOf("image/*", "video/*")) }
                    ToolButton("\uD83D\uDCF7") { capture("photo") }
                    ToolButton("\uD83C\uDFA5") { capture("video") }
                    ToolButton("\uD83D\uDCCE") {
                        docPicker.launch(arrayOf("application/pdf", "text/plain", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation"))
                    }
                    ToolButton(if (recording) "\u23F9" else "\uD83C\uDFA4") { toggleRecording() }
                    ToolButton("\uD83D\uDCCA") { pollOpen = true }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(text, { text = it }, "Message", Modifier.weight(1f), singleLine = false)
                    NeonButton(if (sending) "\u2026" else "\u27A4", { send(null) }, enabled = !sending)
                }
            }
        }
    }

    if (pollOpen) {
        PollDialog(
            onDismiss = { pollOpen = false },
            onCreate = { poll ->
                pollOpen = false
                send(poll)
            }
        )
    }
}

@Composable
private fun ToolButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Panel)
            .border(1.dp, Line, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 18.sp)
    }
}

@Composable
private fun PollDialog(onDismiss: () -> Unit, onCreate: (JSONObject) -> Unit) {
    var question by remember { mutableStateOf("") }
    val options = remember { mutableStateListOf("", "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF101722),
        title = { Text("Create a poll", color = Txt) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(question, { question = it }, "Question", Modifier.fillMaxWidth())
                for (i in options.indices) {
                    Field(options[i], { options[i] = it }, "Option ${i + 1}", Modifier.fillMaxWidth())
                }
                if (options.size < 6) {
                    Text(
                        "+ Add option", color = Cyan, fontSize = 14.sp,
                        modifier = Modifier.clickable { options.add("") }.padding(6.dp)
                    )
                }
            }
        },
        confirmButton = {
            NeonButton("Post poll", {
                val opts = options.map { it.trim() }.filter { it.isNotEmpty() }
                if (question.isBlank() || opts.size < 2) {
                    Repo.toast("Add a question and at least 2 options")
                } else {
                    val counts = JSONArray()
                    for (o in opts) counts.put(0)
                    onCreate(
                        JSONObject().put("question", question.trim()).put("options", JSONArray(opts))
                            .put("voters", JSONObject()).put("counts", counts)
                    )
                }
            })
        },
        dismissButton = { NeonButton("Cancel", onDismiss, secondary = true) }
    )
}

@Composable
private fun Bubble(m: JSONObject, mine: Boolean, dmMode: Boolean, seenNames: List<String>?, onVote: (String, Int) -> Unit) {
    val name = if (dmMode) "" else m.optString("displayName", "Student")
    val tint = colorForName(name)
    val shape = RoundedCornerShape(
        topStart = 16.dp, topEnd = 16.dp,
        bottomStart = if (mine) 16.dp else 4.dp, bottomEnd = if (mine) 4.dp else 16.dp
    )
    val body = if (m.isNull("body")) "" else m.optString("body", "")
    val atts = m.optJSONArray("attachments")
    val poll = m.optJSONObject("poll")
    val id = m.optString("id")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!mine && !dmMode) {
            Avatar(name, 28, tint)
            Spacer(Modifier.width(6.dp))
        }
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .clip(shape)
                .background(if (mine) Color(0xFF1F2A52) else Color(0xFF151F2E))
                .border(1.dp, if (mine) Violet.copy(alpha = 0.5f) else Line, shape)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (!mine && !dmMode) Text(name, color = tint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (body.isNotBlank()) Text(body, color = Txt, fontSize = 15.sp)
            if (atts != null) {
                for (a in atts.objects()) AttachmentView(a)
            }
            if (poll != null) PollView(poll) { choice -> onVote(id, choice) }
            Row(Modifier.align(Alignment.End), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(timeOfDay(parseIso(m.optString("createdAt"))), color = Muted, fontSize = 10.sp)
                if (mine && dmMode) {
                    val read = !m.isNull("readAt")
                    Text(if (read) "\u2713\u2713" else "\u2713", color = if (read) Cyan else Muted, fontSize = 11.sp)
                }
            }
            if (mine && !dmMode && seenNames != null && seenNames.isNotEmpty()) {
                Text("Seen by ${seenNames.joinToString(", ")}", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun AttachmentView(a: JSONObject) {
    val ctx = LocalContext.current
    val url = a.optString("url")
    val type = a.optString("type")
    val name = a.optString("name", "file")
    if (url.isBlank()) return
    when {
        type.startsWith("image/") -> RemoteImage(
            url,
            Modifier
                .fillMaxWidth()
                .heightIn(max = 260.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable { openUrl(ctx, url, type) }
        )
        type.startsWith("audio/") -> AudioChip(url)
        else -> {
            val icon = if (type.startsWith("video/")) "\u25B6  " else "\uD83D\uDCCE  "
            Text(
                icon + name,
                color = Cyan, fontSize = 14.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Panel)
                    .clickable { openUrl(ctx, url, type) }
                    .padding(12.dp)
            )
        }
    }
}

@Composable
private fun AudioChip(url: String) {
    var playing by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(url) {
        onDispose {
            try {
                player?.release()
            } catch (e: Exception) {
                // ignore
            }
            player = null
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Panel)
            .clickable {
                val cur = player
                if (cur != null && playing) {
                    cur.pause()
                    playing = false
                } else if (cur != null) {
                    cur.start()
                    playing = true
                } else {
                    try {
                        val mp = MediaPlayer()
                        mp.setDataSource(url)
                        mp.setOnPreparedListener { it.start(); playing = true }
                        mp.setOnCompletionListener { playing = false; it.seekTo(0) }
                        mp.prepareAsync()
                        player = mp
                    } catch (e: Exception) {
                        Repo.toast("Could not play this voice message")
                    }
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(if (playing) "\u23F8" else "\u25B6", color = Cyan, fontSize = 20.sp)
        Text("Voice message", color = Txt, fontSize = 14.sp)
    }
}

@Composable
private fun PollView(poll: JSONObject, onVote: (Int) -> Unit) {
    val question = poll.optString("question")
    val options = poll.optJSONArray("options")?.strings() ?: emptyList()
    val counts = poll.optJSONArray("counts")
    val voters = poll.optJSONObject("voters")
    val mine = if (voters != null && voters.has(Repo.userId)) voters.optInt(Repo.userId, -1) else -1
    val c = options.indices.map { counts?.optInt(it, 0) ?: 0 }
    val total = c.sum()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("\uD83D\uDCCA $question", color = Txt, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        for ((i, o) in options.withIndex()) {
            val frac = if (total == 0) 0f else c[i] / total.toFloat()
            val shape = RoundedCornerShape(10.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Panel)
                    .border(1.dp, if (mine == i) Cyan else Line, shape)
                    .clickable { onVote(i) }
            ) {
                if (frac > 0f) {
                    Box(
                        Modifier
                            .fillMaxWidth(frac)
                            .heightIn(min = 40.dp)
                            .background(Violet.copy(alpha = 0.35f))
                    )
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text((if (mine == i) "\u2713 " else "") + o, color = Txt, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("${c[i]}", color = Muted, fontSize = 13.sp)
                }
            }
        }
        Text("$total vote${if (total == 1) "" else "s"}", color = Muted, fontSize = 11.sp)
    }
}
