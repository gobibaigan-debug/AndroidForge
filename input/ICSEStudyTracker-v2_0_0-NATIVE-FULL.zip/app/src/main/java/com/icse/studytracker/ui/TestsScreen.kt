package com.icse.studytracker.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.TestDef
import com.icse.studytracker.data.fmtClock

@Composable
fun TestsScreen() {
    var activeSlot by remember { mutableStateOf(-1) }
    val active = Repo.tests.firstOrNull { it.slot == activeSlot }
    if (active != null) {
        TestRunner(active) { activeSlot = -1 }
        return
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("SUNDAY TESTS")
            H1("3 full-length syllabus tests")
            MutedText("Each test is multiple-choice and marked by difficulty. Your best scores appear on the test leaderboard.")
        }
        if (Repo.testsLoading && Repo.tests.isEmpty()) {
            NeonCard { MutedText("Loading tests\u2026") }
        }
        if (Repo.tests.isEmpty() && !Repo.testsLoading) {
            NeonCard {
                Body(if (Repo.testsError.isBlank()) "Tests could not be loaded." else Repo.testsError, color = Bad, size = 13)
                NeonButton("Try again", { Repo.loadTests() }, Modifier.fillMaxWidth())
            }
        }
        for (t in Repo.tests) {
            val mine = Repo.attempts.filter { it.test == t.slot + 1 }
            val best = mine.maxByOrNull { it.score }
            val hard = t.questions.count { it.difficulty.equals("hard", true) }
            NeonCard {
                Kicker("TEST ${t.slot + 1}")
                H2("${t.questions.size} questions \u00B7 ${t.totalMarks} marks")
                MutedText("$hard hard questions \u00B7 covers ${t.questions.map { it.subject }.distinct().size} subjects")
                if (best != null) {
                    MutedText("Best: ${best.score.toInt()}/${best.total.toInt()} \u00B7 ${mine.size} attempt${if (mine.size == 1) "" else "s"}")
                } else {
                    MutedText("Not attempted yet")
                }
                NeonButton(if (best == null) "Start test" else "Try again", { activeSlot = t.slot }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun TestRunner(test: TestDef, onExit: () -> Unit) {
    var idx by remember { mutableStateOf(0) }
    val answers = remember { mutableStateMapOf<Int, Int>() }
    var finished by remember { mutableStateOf(false) }
    val startedAt = remember { System.currentTimeMillis() }
    var board by remember { mutableStateOf<List<Triple<String, Double, Double>>>(emptyList()) }
    val qs = test.questions
    BackHandler(enabled = true) { onExit() }

    var score = 0
    for ((i, q) in qs.withIndex()) if (answers[i] == q.answer) score += q.marks
    val total = test.totalMarks

    LaunchedEffect(finished) {
        if (finished) {
            Repo.submitAttempt(test.slot + 1, score, total, HashMap(answers))
            board = Repo.testLeaderboard(test.slot + 1)
        }
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!finished) {
            val q = qs[idx]
            NeonCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Kicker("TEST ${test.slot + 1} \u00B7 QUESTION ${idx + 1}/${qs.size}")
                    Text(
                        "   " + fmtClock((Repo.now - startedAt) / 1000),
                        color = Muted, fontSize = 12.sp
                    )
                }
                ProgressBar((idx + 1) / qs.size.toFloat())
                MutedText("${q.subject} \u00B7 ${q.chapter} \u00B7 ${q.difficulty} \u00B7 ${q.marks} mark${if (q.marks == 1) "" else "s"}")
                Text(q.q, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                for ((oi, opt) in q.options.withIndex()) {
                    val picked = answers[idx] == oi
                    val shape = RoundedCornerShape(11.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(if (picked) Violet.copy(alpha = 0.25f) else Panel)
                            .border(1.dp, if (picked) Violet else Line, shape)
                            .clickable { answers[idx] = oi }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("${'A' + oi}", color = if (picked) Cyan else Muted, fontWeight = FontWeight.Bold)
                        Text(opt, color = Txt, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Back", { if (idx > 0) idx-- }, Modifier.weight(1f), enabled = idx > 0, secondary = true)
                    if (idx < qs.size - 1) {
                        NeonButton("Next", { idx++ }, Modifier.weight(1f))
                    } else {
                        NeonButton("Finish", { finished = true }, Modifier.weight(1f))
                    }
                }
                val unanswered = qs.size - answers.size
                Text(
                    "Submit now ($unanswered unanswered)",
                    color = Cyan, fontSize = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { finished = true }
                        .padding(8.dp)
                )
                Text(
                    "Leave test",
                    color = Muted, fontSize = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onExit() }
                        .padding(8.dp)
                )
            }
        } else {
            val pct = if (total == 0) 0 else Math.round(score * 100f / total)
            NeonCard {
                Kicker("TEST ${test.slot + 1} RESULT")
                Text("$score / $total", color = Txt, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                Body(
                    when {
                        pct >= 85 -> "Outstanding! \uD83C\uDF1F ($pct%)"
                        pct >= 60 -> "Good work \u2014 keep revising. ($pct%)"
                        else -> "Needs more revision \u2014 review the answers below. ($pct%)"
                    },
                    size = 15
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Retry", { answers.clear(); idx = 0; finished = false }, Modifier.weight(1f))
                    NeonButton("All tests", { onExit() }, Modifier.weight(1f), secondary = true)
                }
            }
            NeonCard {
                Kicker("TEST ${test.slot + 1} LEADERBOARD")
                if (board.isEmpty()) MutedText("Loading\u2026")
                for ((i, r) in board.withIndex()) {
                    Row(Modifier.fillMaxWidth()) {
                        Text("${i + 1}. ${r.first}", color = Txt, modifier = Modifier.weight(1f))
                        MutedText("${r.second.toInt()}/${r.third.toInt()}", size = 13)
                    }
                }
            }
            NeonCard {
                Kicker("REVIEW")
                for ((i, q) in qs.withIndex()) {
                    val mine = answers[i]
                    val ok = mine == q.answer
                    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${i + 1}. ${q.q}", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        val yours = if (mine == null) "not answered" else q.options.getOrElse(mine) { "?" }
                        Text(
                            (if (ok) "\u2713 " else "\u2717 ") + "Your answer: $yours",
                            color = if (ok) Good else Bad, fontSize = 13.sp
                        )
                        if (!ok) Text("Correct: ${q.options.getOrElse(q.answer) { "?" }}", color = Good, fontSize = 13.sp)
                        if (q.explanation.isNotBlank()) MutedText(q.explanation)
                    }
                }
            }
        }
    }
}
