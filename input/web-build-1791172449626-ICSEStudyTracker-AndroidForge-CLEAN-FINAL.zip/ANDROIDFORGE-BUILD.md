# AndroidForge build contract

This is a native Kotlin + Jetpack Compose Android Gradle project.

Expected application ID: `com.icse.class9studytracker`
Expected app label: `ICSE Class 9 Study Tracker`
Expected module: `:app`
Recommended AndroidForge variant: `debug`

The archive intentionally has no Gradle wrapper. AndroidForge documentation states that wrapperless projects are supported and that it can choose/install a compatible Gradle/JDK toolchain and regenerate a missing wrapper when required.

Do not substitute an AndroidForge sample project or any other input archive.
