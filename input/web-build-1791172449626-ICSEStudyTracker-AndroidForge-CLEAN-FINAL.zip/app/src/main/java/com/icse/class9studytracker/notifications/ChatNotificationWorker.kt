package com.icse.class9studytracker.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.icse.class9studytracker.data.ApiClient
import com.icse.class9studytracker.data.AppState
import org.json.JSONObject

class ChatNotificationWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val state = AppState(applicationContext)
        val cookie = state.cookie ?: return Result.success()
        if (!state.notificationsEnabled) return Result.success()
        return runCatching {
            val since = state.lastNotificationAt
            val data = ApiClient.tracker("notifications", JSONObject().put("since", since), cookie)
            val items = data.optJSONArray("items") ?: return@runCatching Result.success()
            var newest = since
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val created = item.optString("createdAt")
                if (created.isNotBlank() && (newest.isBlank() || created > newest)) newest = created
                val id = item.optString("id").hashCode()
                val type = item.optString("type")
                val title = if (type == "dm") "Private chat • ${item.optString("displayName", "Student")}" else "Community • ${item.optString("displayName", "Student")}"
                NotificationHelper.chat(applicationContext, 1200 + kotlin.math.abs(id % 700000), title, item.optString("body"))
            }
            if (newest.isNotBlank()) state.lastNotificationAt = newest
            Result.success()
        }.getOrElse { Result.retry() }
    }
}
