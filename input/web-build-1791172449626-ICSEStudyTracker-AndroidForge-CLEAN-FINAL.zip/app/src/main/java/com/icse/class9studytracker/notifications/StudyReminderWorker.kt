package com.icse.class9studytracker.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.icse.class9studytracker.data.AppState
import java.util.Calendar

class StudyReminderWorker(appContext: Context, params: WorkerParameters): CoroutineWorker(appContext,params){
 override suspend fun doWork(): Result {
  if (AppState(applicationContext).notificationsEnabled) NotificationHelper.studyReminder(applicationContext)
  return Result.success()
 }
 companion object { fun initialDelayMs():Long { val now=Calendar.getInstance(); val next=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,19);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=now.timeInMillis)add(Calendar.DAY_OF_YEAR,1)};return next.timeInMillis-now.timeInMillis } }
}
