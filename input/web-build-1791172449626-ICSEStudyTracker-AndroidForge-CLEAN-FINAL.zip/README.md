# ICSE Class 9 Study Tracker — AndroidForge build package

Native Kotlin/Jetpack Compose Android application.

- Application ID: `com.icse.class9studytracker`
- App label: `ICSE Class 9 Study Tracker`
- Module: `app`
- Compile/target SDK: 35
- Minimum SDK: 21
- Recommended AndroidForge build variant: `debug`

This ZIP contains only the Study Tracker source project. It contains no prebuilt APK, no Quick Launch source, and no AndroidForge Sample App source.

The Gradle wrapper is intentionally omitted so AndroidForge can select/regenerate the compatible Gradle toolchain according to its project-detection rules.
