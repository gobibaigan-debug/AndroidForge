package com.icse.studytracker.data

import java.util.Calendar
import java.util.Random

/**
 * Builds the three Sunday tests (35-40 questions each).
 *
 * Multiple-choice questions come from the server's question bank, dealt randomly across the tests with the
 * hard questions spread evenly. Each test then ends with 5-8 "master" written questions taken from random
 * chapters of random subjects; the student writes the answer on paper and uploads a photo.
 * The seed changes every week, so the tests are fresh each Sunday but identical for every student.
 */
object TestBuilder {
    fun weekSeed(): Long {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 100L + c.get(Calendar.WEEK_OF_YEAR)
    }

    fun build(pool: List<Question>, stream: String): List<TestDef> {
        val allowed = Syllabus.subjectsFor(stream).toSet()
        val known = Syllabus.allSubjects.toSet()
        val usable = pool.filter { !it.written && (!known.contains(it.subject) || allowed.contains(it.subject)) }
        val seed = weekSeed()
        val out = ArrayList<TestDef>()
        val buckets = deal(usable, seed)
        for (slot in 0 until 3) {
            val rnd = Random(seed * 1000L + slot * 37L)
            val writtenCount = 5 + rnd.nextInt(4)
            val mcqTarget = 35 + rnd.nextInt(6) - writtenCount
            val mcqs = ArrayList(buckets[slot])
            // top up from the rest of the bank when a bucket is short
            if (mcqs.size < mcqTarget) {
                val extra = ArrayList(usable.filter { !mcqs.contains(it) })
                extra.shuffle(rnd)
                for (q in extra) {
                    if (mcqs.size >= mcqTarget) break
                    mcqs.add(q)
                }
            }
            while (mcqs.size > mcqTarget) mcqs.removeAt(rnd.nextInt(mcqs.size))
            mcqs.shuffle(rnd)
            val written = writtenQuestions(stream, writtenCount, rnd)
            out.add(TestDef(slot, mcqs + written))
        }
        return out
    }

    private fun deal(pool: List<Question>, seed: Long): List<List<Question>> {
        val rnd = Random(seed)
        val hard = pool.filter { it.difficulty.equals("hard", true) }.shuffled(rnd)
        val rest = pool.filter { !it.difficulty.equals("hard", true) }.shuffled(rnd)
        val buckets = listOf(ArrayList<Question>(), ArrayList<Question>(), ArrayList<Question>())
        var i = 0
        for (q in hard + rest) {
            buckets[i % 3].add(q)
            i++
        }
        return buckets
    }

    private fun writtenQuestions(stream: String, count: Int, rnd: Random): List<Question> {
        val subjects = ArrayList(Syllabus.subjectsFor(stream))
        subjects.shuffle(rnd)
        val out = ArrayList<Question>()
        for (n in 0 until count) {
            val subject = subjects[n % subjects.size]
            val chapters = Syllabus.chaptersOf(subject)
            val chapter = chapters[rnd.nextInt(chapters.size)]
            out.add(prompt(subject, chapter, rnd))
        }
        return out
    }

    private fun prompt(subject: String, chapter: String, rnd: Random): Question {
        val photo: Boolean
        val text: String
        when (subject) {
            "Mathematics" -> {
                photo = true
                text = if (rnd.nextBoolean())
                    "PROOF / DERIVATION \u2014 \"$chapter\": Prove or derive the central result of this chapter step by step, then use it to solve one new problem of your own. If you can do this without help, you can handle any question from this chapter. Write it on paper and upload a photo."
                else
                    "MASTER QUESTION \u2014 \"$chapter\": Create a hard, multi-step problem from this chapter, solve it completely showing every line of working, and explain why each step is valid. Upload a photo of your solution."
            }
            "Physics" -> {
                photo = true
                text = "DERIVATION \u2014 \"$chapter\": Derive the key relation(s) of this chapter, draw a neat labelled diagram, and solve one numerical that needs it. Explain what would change if one condition were altered. Upload a photo of your answer."
            }
            "Chemistry" -> {
                photo = true
                text = "MASTER QUESTION \u2014 \"$chapter\": Explain the core idea using balanced equations or diagrams, apply it to a new example, and justify the trend or rule behind it. Upload a photo of your written answer."
            }
            "Biology" -> {
                photo = true
                text = "DIAGRAM + REASONING \u2014 \"$chapter\": Draw a neat, fully labelled diagram for this chapter and explain how each part works. Then predict what happens if the main process fails. Upload a photo."
            }
            "Computer" -> {
                photo = true
                text = "PROGRAM + DRY RUN \u2014 \"$chapter\": Write a complete Java program that uses the key concept of this chapter, show a dry-run table with the output, and explain the logic line by line. Upload a photo."
            }
            "Geography" -> {
                photo = true
                text = "ANALYSE \u2014 \"$chapter\": Draw a clear diagram or map sketch for this chapter and explain causes, effects and one real example. Link it to another geography chapter. Upload a photo."
            }
            "History & Civics" -> {
                photo = false
                text = "ANALYSE \u2014 \"$chapter\": Write a structured answer covering causes, key features and consequences, and compare it with a related chapter. If you can do this you can answer any question from the chapter. (Photo optional.)"
            }
            "English Literature" -> {
                photo = false
                text = "CRITICAL RESPONSE \u2014 \"$chapter\": Write a short analysis of theme, character or poetic device with evidence from the text, in your own words. (Photo optional.)"
            }
            "English Grammar" -> {
                photo = false
                text = "APPLY \u2014 \"$chapter\": Write 5 original examples that follow the rules of this topic, then write 3 common mistakes with their corrections. (Photo optional.)"
            }
            "Hindi" -> {
                photo = false
                text = "\u0935\u093F\u0936\u094D\u0932\u0947\u0937\u0923 \u2014 \"$chapter\": \u0907\u0938 \u092A\u093E\u0920 / \u0935\u093F\u0937\u092F \u0915\u094B \u0905\u092A\u0928\u0947 \u0936\u092C\u094D\u0926\u094B\u0902 \u092E\u0947\u0902 \u0935\u093F\u0938\u094D\u0924\u093E\u0930 \u0938\u0947 \u0932\u093F\u0916\u093F\u090F \u0914\u0930 \u090F\u0915 \u0909\u0926\u093E\u0939\u0930\u0923 \u0926\u0940\u091C\u093F\u090F\u0964 (\u092B\u093C\u094B\u091F\u094B \u0935\u0948\u0915\u0932\u094D\u092A\u093F\u0915)"
            }
            "Commercial Studies" -> {
                photo = true
                text = "APPLY \u2014 \"$chapter\": Explain the topic with a suitable format (journal, ledger, diagram or document) filled with your own figures, and justify each entry. Upload a photo."
            }
            else -> {
                photo = true
                text = "MASTER QUESTION \u2014 \"$chapter\": Explain the topic with a labelled diagram and a worked example, then give one reasoning-based application. Upload a photo."
            }
        }
        return Question(
            q = text, options = emptyList(), answer = -1, explanation = "",
            marks = 5, difficulty = "high-thinking", subject = subject, chapter = chapter,
            written = true, photoRequired = photo
        )
    }
}
