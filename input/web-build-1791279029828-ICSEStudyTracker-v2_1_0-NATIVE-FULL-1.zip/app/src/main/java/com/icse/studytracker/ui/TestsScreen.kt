package com.icse.studytracker.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.TestDef
import com.icse.studytracker.data.fmtClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

@Composable
fun TestsScreen() {
    var activeSlot by remember { mutableStateOf(-1) }
    val active = Repo.sundayTests.firstOrNull { it.slot == activeSlot }
    if (active != null) {
        TestRunner(active) { activeSlot = -1 }
        return
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("SUNDAY TESTS")
            H1("3 new tests every week")
            MutedText("Each test has 35\u201340 questions drawn from random chapters of random subjects: mostly multiple-choice, plus 5\u20138 high-thinking written questions. If you can answer those, you know the chapter. Write them on paper and upload a photo of your answer.")
        }
        if (Repo.testsLoading && Repo.sundayTests.isEmpty()) {
            NeonCard { MutedText("Loading tests\u2026") }
        }
        if (Repo.sundayTests.isEmpty() && !Repo.testsLoading) {
            NeonCard {
                Body(if (Repo.testsError.isBlank()) "Tests could not be loaded." else Repo.testsError, color = Bad, size = 13)
                NeonButton("Try again", { Repo.loadTests() }, Modifier.fillMaxWidth())
            }
        }
        for (t in Repo.sundayTests) {
            val mine = Repo.attempts.filter { it.test == t.slot + 1 }
            val best = mine.maxByOrNull { it.score }
            val hard = t.questions.count { !it.written && it.difficulty.equals("hard", true) }
            val subjects = t.questions.map { it.subject }.distinct()
            val chapters = t.questions.map { it.subject + "::" + it.chapter }.distinct().size
            NeonCard {
                Kicker("TEST ${t.slot + 1}")
                H2("${t.questions.size} questions \u00B7 ${t.totalMarks} marks (MCQ)")
                MutedText("${t.mcqCount} MCQs ($hard hard) + ${t.writtenCount} written high-thinking questions")
                MutedText("${subjects.size} subjects \u00B7 $chapters chapters")
                if (best != null) {
                    MutedText("Best: ${best.score.toInt()}/${best.total.toInt()} \u00B7 ${mine.size} attempt${if (mine.size == 1) "" else "s"}")
                } else {
                    MutedText("Not attempted yet")
                }
                NeonButton(if (best == null) "Start test" else "Try again", { activeSlot = t.slot }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun TestRunner(test: TestDef, onExit: () -> Unit) {
    val ctx = LocalContext.current
    var idx by remember { mutableStateOf(0) }
    val answers = remember { mutableStateMapOf<Int, Int>() }
    val photos = remember { mutableStateMapOf<Int, Uri>() }
    var finished by remember { mutableStateOf(false) }
    val startedAt = remember { System.currentTimeMillis() }
    var board by remember { mutableStateOf<List<Triple<String, Double, Double>>>(emptyList()) }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    var captureIdx by remember { mutableStateOf(0) }
    val qs = test.questions
    BackHandler(enabled = true) { onExit() }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) photos[idx] = uri
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = captureUri
        if (ok && u != null) photos[captureIdx] = u
    }

    fun openCamera() {
        try {
            val dir = File(ctx.cacheDir, "capture")
            dir.mkdirs()
            val f = File(dir, "answer-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            captureUri = uri
            captureIdx = idx
            camera.launch(uri)
        } catch (e: Exception) {
            Repo.toast("Could not open the camera")
        }
    }

    val camPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else Repo.toast("Camera permission is needed")
    }

    fun takePhoto() {
        val need = android.os.Build.VERSION.SDK_INT >= 23 &&
            ctx.checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED
        if (need) camPermission.launch(android.Manifest.permission.CAMERA) else openCamera()
    }

    var score = 0
    for ((i, q) in qs.withIndex()) if (!q.written && answers[i] == q.answer) score += q.marks
    val total = test.totalMarks

    LaunchedEffect(finished) {
        if (finished) {
            val extra = JSONObject()
            for ((i, uri) in photos.entries.map { Pair(it.key, it.value) }) {
                try {
                    val a = withContext(Dispatchers.IO) { Api.upload(ctx, uri, "test-answer-$i.jpg", "image/jpeg") }
                    extra.put("w$i", a.optString("url"))
                } catch (e: Exception) {
                    Repo.toast("A photo could not be uploaded: " + Repo.handleError(e))
                }
            }
            Repo.submitAttempt(test.slot + 1, score, total, HashMap(answers), extra)
            board = Repo.testLeaderboard(test.slot + 1)
        }
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!finished) {
            val q = qs[idx]
            NeonCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Kicker("TEST ${test.slot + 1} \u00B7 QUESTION ${idx + 1}/${qs.size}")
                    Text("   " + fmtClock((Repo.now - startedAt) / 1000), color = Muted, fontSize = 12.sp)
                }
                ProgressBar((idx + 1) / qs.size.toFloat())
                Text(
                    "${q.subject} \u00B7 ${q.chapter}",
                    color = Syllabus.colorOf(q.subject), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
                if (q.written) {
                    Text(
                        "WRITTEN \u00B7 HIGH-THINKING \u00B7 ${q.marks} marks",
                        color = Hot, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                    )
                } else {
                    MutedText("${q.difficulty} \u00B7 ${q.marks} mark${if (q.marks == 1) "" else "s"}")
                }
                Text(q.q, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)

                if (q.written) {
                    MutedText(if (q.photoRequired) "Write your full working on paper and upload a clear photo." else "Write your answer on paper; a photo is optional.")
                    val has = photos[idx] != null
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonButton("\uD83D\uDCF7 Take photo", { takePhoto() }, Modifier.weight(1f))
                        NeonButton("\uD83D\uDDBC Upload", { gallery.launch("image/*") }, Modifier.weight(1f), secondary = true)
                    }
                    if (has) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Body("\u2705 Photo attached", color = Good, size = 14)
                            Text("Remove", color = Bad, fontSize = 13.sp, modifier = Modifier.clickable { photos.remove(idx) })
                        }
                    }
                } else {
                    for ((oi, opt) in q.options.withIndex()) {
                        val picked = answers[idx] == oi
                        val shape = RoundedCornerShape(11.dp)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(shape)
                                .background(if (picked) Violet.copy(alpha = 0.25f) else Panel)
                                .border(1.dp, if (picked) Violet else Line, shape)
                                .clickable { answers[idx] = oi }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("${'A' + oi}", color = if (picked) Cyan else Muted, fontWeight = FontWeight.Bold)
                            Text(opt, color = Txt, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Back", { if (idx > 0) idx-- }, Modifier.weight(1f), enabled = idx > 0, secondary = true)
                    if (idx < qs.size - 1) {
                        NeonButton("Next", { idx++ }, Modifier.weight(1f))
                    } else {
                        NeonButton("Finish", { finished = true }, Modifier.weight(1f))
                    }
                }
                val unanswered = qs.count { !it.written } - answers.size
                Text(
                    "Submit now ($unanswered MCQs unanswered)",
                    color = Cyan, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clickable { finished = true }.padding(8.dp)
                )
                Text(
                    "Leave test",
                    color = Muted, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clickable { onExit() }.padding(8.dp)
                )
            }
        } else {
            val pct = if (total == 0) 0 else Math.round(score * 100f / total)
            val writtenDone = qs.indices.count { qs[it].written && photos[it] != null }
            NeonCard {
                Kicker("TEST ${test.slot + 1} RESULT")
                Text("$score / $total", color = Txt, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                Body(
                    when {
                        pct >= 85 -> "Outstanding! \uD83C\uDF1F ($pct%)"
                        pct >= 60 -> "Good work \u2014 keep revising. ($pct%)"
                        else -> "Needs more revision \u2014 review the answers below. ($pct%)"
                    },
                    size = 15
                )
                MutedText("Written questions: $writtenDone of ${test.writtenCount} answered with a photo. Check them against your textbook or ask your teacher \u2014 they are not auto-marked.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Retry", { answers.clear(); photos.clear(); idx = 0; finished = false }, Modifier.weight(1f))
                    NeonButton("All tests", { onExit() }, Modifier.weight(1f), secondary = true)
                }
            }
            NeonCard {
                Kicker("TEST ${test.slot + 1} LEADERBOARD")
                if (board.isEmpty()) MutedText("Loading\u2026")
                for ((i, r) in board.withIndex()) {
                    Row(Modifier.fillMaxWidth()) {
                        Text("${i + 1}. ${r.first}", color = Txt, modifier = Modifier.weight(1f))
                        MutedText("${r.second.toInt()}/${r.third.toInt()}", size = 13)
                    }
                }
            }
            NeonCard {
                Kicker("REVIEW")
                for ((i, q) in qs.withIndex()) {
                    if (q.written) {
                        Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${i + 1}. [Written] ${q.subject}: ${q.chapter}", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (photos[i] != null) "\u2713 Photo attached" else "No photo attached", color = if (photos[i] != null) Good else Muted, fontSize = 13.sp)
                        }
                    } else {
                        val mine = answers[i]
                        val ok = mine == q.answer
                        Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${i + 1}. ${q.q}", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            val yours = if (mine == null) "not answered" else q.options.getOrElse(mine) { "?" }
                            Text(
                                (if (ok) "\u2713 " else "\u2717 ") + "Your answer: $yours",
                                color = if (ok) Good else Bad, fontSize = 13.sp
                            )
                            if (!ok) Text("Correct: ${q.options.getOrElse(q.answer) { "?" }}", color = Good, fontSize = 13.sp)
                            if (q.explanation.isNotBlank()) MutedText(q.explanation)
                        }
                    }
                }
            }
        }
    }
}
