# ICSE Class 9 Study Tracker — build notes

Native Kotlin + Jetpack Compose project. The Gradle project is at the ZIP ROOT
(settings.gradle.kts, build.gradle.kts, gradlew, gradle/wrapper/gradle-wrapper.jar, app/).

    ./gradlew assembleDebug      ->  app/build/outputs/apk/debug/app-debug.apk

Gradle 8.11.1 (wrapper) | AGP 8.7.3 | Kotlin 2.0.21 | compile/target SDK 35 | min SDK 21 | JDK 17+
Application ID: com.icse.class9studytracker   Version: 1.1.0 (3)
