# ICSE Class 9 Study Tracker — Native Android v1.1.0

This is the native Android rebuild of the ICSE Class 9 Study Tracker. It is **not a WebView wrapper**.

## Included
- Neon/dark student dashboard focused on real progress
- Persistent study timer with online sync when available
- Manual study-time entry
- 5-question study verification after a saved session
- Subject/topic time tracking
- Bar chart of study time by subject
- Syllabus chapter/topic checklist and overall completion percentage
- Daily task checklist generated from the chosen target date
- Study streak calculation
- Exam planner and target date
- 3 Sunday tests with 35 questions each, mixed difficulty, marks, explanations, score and retry
- Test attempts and test leaderboard sync when backend is available
- Daily/weekly/monthly/all study leaderboard sync
- Community + private DMs with a more WhatsApp-style bubble layout
- Gallery/multiple images, camera photo, video, PDF/document, voice note and polls
- Delivery/read ticks and community seen-by sync hooks
- Long-press delete-for-myself
- Native notification channels/background workers
- Focus Mode with a user-selected distracting-app list
- Accessibility-based interception of **only selected apps**; unselected apps remain usable
- No advertisements
- Science and Commerce subject sets
- Android API compatibility target from API 21 upward, with runtime handling for newer permissions

## Backend
The app uses the published Floot backend:
`https://icse-study-tracker-neon.floot.app`

No database password or service-role key is embedded in the Android client.

## Focus Mode permission
Android requires the user to explicitly enable the app's Accessibility Service in Settings. The app never silently enables it. Focus Mode only intercepts packages that the student selected.

## Final verification checklist on a real phone
1. Register and sign in.
2. Start a timer, save it, close/reopen the app and confirm it remains in Progress.
3. Add manual time and confirm charts update.
4. Tick syllabus topics and confirm Home progress changes.
5. Create today's checklist from Planner and tick tasks.
6. Complete a Sunday test and confirm score/retry/leaderboard.
7. Send a Community message and DM with text/media/poll/voice.
8. Enable Accessibility, select one distracting app, start Focus and confirm only that app is intercepted.
9. Disable Focus and confirm the selected app is usable again.

## Build
`./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk` (see CLOUD-BUILD.md).
