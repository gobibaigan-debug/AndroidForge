package com.icse.studytracker.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

/** Local-first study data. It keeps the app useful when the network/backend is slow,
 * while the UI also attempts the online sync through ApiClient. */
class TrackerStore(context: Context) {
    private val p = context.getSharedPreferences("study_data", Context.MODE_PRIVATE)
    private fun arr(key:String): JSONArray = runCatching { JSONArray(p.getString(key,"[]")) }.getOrElse { JSONArray() }
    private fun save(key:String,a:JSONArray){ p.edit().putString(key,a.toString()).apply() }
    private fun today():String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun sessions(): JSONArray = arr("sessions")
    fun addSession(subject:String, topic:String, seconds:Int, verified:Boolean){
        val a=arr("sessions"); a.put(JSONObject().put("date",today()).put("subject",subject).put("topic",topic).put("seconds",seconds).put("verified",verified)); save("sessions",a)
    }
    fun manualSession(subject:String, topic:String, minutes:Int){ addSession(subject,topic,minutes*60,false) }
    fun markLastVerified(){ val a=arr("sessions"); if(a.length()>0){a.getJSONObject(a.length()-1).put("verified",true);save("sessions",a)} }

    fun completed(): MutableSet<String> = p.getStringSet("completed",emptySet())?.toMutableSet() ?: mutableSetOf()
    fun setCompleted(key:String,value:Boolean){ val s=completed(); if(value)s.add(key) else s.remove(key); p.edit().putStringSet("completed",s).apply() }

    fun tasks(): JSONArray = arr("tasks")
    fun setTasks(a:JSONArray){save("tasks",a)}
    fun taskDone(id:String):Boolean{ val a=tasks(); for(i in 0 until a.length()) if(a.getJSONObject(i).optString("id")==id) return a.getJSONObject(i).optBoolean("done"); return false }
    fun toggleTask(id:String){ val a=tasks(); for(i in 0 until a.length()){val o=a.getJSONObject(i);if(o.optString("id")==id){o.put("done",!o.optBoolean("done"));break}};save("tasks",a)}

    fun streak():Int{
        val dates=mutableSetOf<String>(); val a=sessions(); for(i in 0 until a.length()) if(a.getJSONObject(i).optInt("seconds")>0) dates.add(a.getJSONObject(i).optString("date"))
        var d=Calendar.getInstance(); var count=0; val f=SimpleDateFormat("yyyy-MM-dd",Locale.US)
        while(dates.contains(f.format(d.time))){count++;d.add(Calendar.DATE,-1)}
        return count
    }

    fun totalSeconds():Int { val a=sessions(); var n=0; for(i in 0 until a.length()) n+=a.getJSONObject(i).optInt("seconds"); return n }
    fun subjectSeconds():Map<String,Int>{
        val m=mutableMapOf<String,Int>(); val a=sessions()
        for(i in 0 until a.length()) { val o=a.getJSONObject(i); val s=o.optString("subject","Other"); m[s]=(m[s]?:0)+o.optInt("seconds") }
        return m
    }
    fun topicSeconds():Map<String,Int>{
        val m=mutableMapOf<String,Int>(); val a=sessions()
        for(i in 0 until a.length()) { val o=a.getJSONObject(i); val s=o.optString("topic").ifBlank { "Unspecified" }; m[s]=(m[s]?:0)+o.optInt("seconds") }
        return m
    }

    fun planner():JSONArray = arr("planner")
    fun setPlanner(a:JSONArray){save("planner",a)}

    fun testAttempts():JSONArray=arr("testAttempts")
    fun saveAttempt(test:Int,score:Int,total:Int){val a=testAttempts();a.put(JSONObject().put("test",test).put("score",score).put("total",total).put("date",today()));save("testAttempts",a)}
}

object Syllabus {
    val science=mapOf(
        "Physics" to listOf("Laws of Motion","Pressure in Fluids and Atmospheric Pressure","Upthrust, Archimedes' Principle and Floatation","Reflection of Light","Propagation of Sound Waves"),
        "Chemistry" to listOf("Periodic Table","Hydrogen","Gas Laws","Periodic Table / Periodic Properties","Chemical Bonding"),
        "Biology" to listOf("Economic Importance of Bacteria and Fungi","Nutrition","Skeleton, Movement and Locomotion","Skin","Respiratory System","Health and Hygiene","Aids to Health","Water Generation and Management"),
        "Mathematics" to listOf("Compound Interest","Simultaneous Linear Equations","Problems on Simultaneous Linear Equations","Indices","Midpoint Theorem","Rectilinear Figures","Theorems on Area","Mensuration","Coordinate Geometry","Statistics"),
        "History & Civics" to listOf("South India and Cholas","Delhi Sultanate","Mughal Empire","Composite Culture","Renaissance","Reformation","Industrial Revolution, Capitalism and Socialism","Constitution","Elections and Election Commission","State Legislatures"),
        "Geography" to listOf("Hydrosphere","Atmosphere","Insolation","Atmospheric Pressure and Winds","Humidity","Types of Pollution","Sources of Pollution","Effects and Preventive Measures of Pollution","Major Natural Regions"),
        "Computer" to listOf("OOP Concepts and Java","Objects and Classes","Values and Data Types","Operators","Input","Math Library","Conditional Statements","Iterative Statements","Nested Loops"),
        "English" to listOf("Composition","Letters, Notice and Email","Comprehension and Grammar","Julius Caesar Act II","Treasure Chest Poems","Prose"),
    )
    val commerce=mapOf(
        "Commercial Studies" to listOf("Finance and Accounts","Human Resources","Production","Communication in Commercial Organisation","Methods of Communication","Meaning, Objectives and Terminology of Accounting","Basic Accounting Principles and Concepts","Banking","Trade","Social Responsibility toward Environment","Partnership","Joint Stock Company","Accounting Books and Statements"),
        "Physical Education" to listOf("Respiratory System","Games and Sports","Circulatory System","Cricket","Badminton"),
    )
    fun forStream(stream:String):Map<String,List<String>> = if(stream.lowercase().contains("commerce")) (science.filterKeys{it in listOf("Mathematics","History & Civics","Geography","English")}+commerce) else science
}
