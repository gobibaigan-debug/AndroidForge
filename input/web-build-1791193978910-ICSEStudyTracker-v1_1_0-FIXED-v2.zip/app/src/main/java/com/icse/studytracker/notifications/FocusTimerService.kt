package com.icse.studytracker.notifications

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*

class FocusTimerService: Service(){
 companion object { const val CHANNEL="focus_timer"; const val ACTION_START="START"; const val ACTION_STOP="STOP"; const val EXTRA_END="END" }
 private val handler=Handler(Looper.getMainLooper()); private var endAt=0L
 private val tick=object:Runnable{override fun run(){val left=endAt-System.currentTimeMillis();if(left<=0){getSharedPreferences("focus",MODE_PRIVATE).edit().putBoolean("enabled",false).apply();stopCompat();stopSelf();return};val mins=(left/60000).toInt();val secs=((left%60000)/1000).toInt();val nm=getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager;nm.notify(7,notification("Focus Mode active","${mins}:${String.format("%02d",secs)} remaining"));handler.postDelayed(this,1000)}}
 override fun onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){(getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CHANNEL,"Focus Timer",NotificationManager.IMPORTANCE_LOW))}}
 private fun notification(title:String,text:String)=NotificationCompat.Builder(this, if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) CHANNEL else "").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(text).setOngoing(true).setOnlyAlertOnce(true).build()
 private fun stopCompat(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N)stopForeground(STOP_FOREGROUND_REMOVE)else stopForeground(true)}
 override fun onStartCommand(i:Intent?,flags:Int,id:Int):Int{if(i?.action==ACTION_STOP){getSharedPreferences("focus",MODE_PRIVATE).edit().putBoolean("enabled",false).apply();handler.removeCallbacks(tick);stopCompat();stopSelf();return START_NOT_STICKY};endAt=i?.getLongExtra(EXTRA_END,System.currentTimeMillis()+3000000L)?:System.currentTimeMillis()+3000000L;startForeground(7,notification("Focus Mode active","Until ${SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(endAt))}"));handler.removeCallbacks(tick);handler.post(tick);return START_STICKY}
 override fun onDestroy(){handler.removeCallbacks(tick);super.onDestroy()}
 override fun onBind(i:Intent?):IBinder?=null
}
