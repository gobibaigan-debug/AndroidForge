package com.icse.studytracker.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.icse.studytracker.MainActivity

object NotificationHelper {
    const val CHAT_CHANNEL = "chat"
    const val STUDY_CHANNEL = "study_reminders"
    const val FOCUS_CHANNEL = "focus_timer"
    private const val GROUP = "icse_study_tracker"

    fun channels(context: Context) {
        // Notification channels exist only on Android 8.0 (API 26)+.
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHAT_CHANNEL, "Community & DMs", NotificationManager.IMPORTANCE_HIGH).apply { description = "New community and private chat messages" })
        nm.createNotificationChannel(NotificationChannel(STUDY_CHANNEL, "Study reminders", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "Study and test reminders" })
        nm.createNotificationChannel(NotificationChannel(FOCUS_CHANNEL, "Focus timer", NotificationManager.IMPORTANCE_LOW).apply { description = "Ongoing focus session timer" })
    }

    fun canNotify(context: Context): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun chat(context: Context, id: Int, title: String, body: String) {
        if (!canNotify(context)) return
        channels(context)
        val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra("openTab", "Chat") }
        val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val pi = android.app.PendingIntent.getActivity(context, id, open, flags)
        val n = NotificationCompat.Builder(context, if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) CHAT_CHANNEL else "")
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(body.ifBlank { "New message or attachment" })
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }

    fun studyReminder(context: Context) {
        if (!canNotify(context)) return
        channels(context)
        val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra("openTab", "Timer") }
        val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val pi = android.app.PendingIntent.getActivity(context, 901, open, flags)
        val n = NotificationCompat.Builder(context, if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) STUDY_CHANNEL else "")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ICSE Study Tracker")
            .setContentText("A little focused study today keeps your streak moving.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setGroup(GROUP)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(901, n)
    }
}
