package com.icse.studytracker.focus

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class FocusAccessibilityService: AccessibilityService(){
 override fun onAccessibilityEvent(event:AccessibilityEvent){
  if(event.eventType!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return
  val pkg=event.packageName?.toString() ?: return
  if(pkg==packageName)return
  val prefs=FocusPrefs(this)
  if(prefs.enabled() && prefs.packages().contains(pkg)){
   performGlobalAction(GLOBAL_ACTION_HOME)
   Toast.makeText(this,"Focus Mode: this app is blocked until your focus session ends.",Toast.LENGTH_SHORT).show()
  }
 }
 override fun onInterrupt(){}
}
