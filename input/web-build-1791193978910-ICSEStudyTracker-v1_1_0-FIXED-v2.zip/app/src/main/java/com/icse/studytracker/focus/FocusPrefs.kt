package com.icse.studytracker.focus

import android.content.Context
class FocusPrefs(c:Context){
 private val p=c.getSharedPreferences("focus",Context.MODE_PRIVATE)
 fun enabled()=p.getBoolean("enabled",false)
 fun setEnabled(v:Boolean)=p.edit().putBoolean("enabled",v).apply()
 fun packages()=p.getStringSet("packages",emptySet()) ?: emptySet()
 fun setPackages(v:Set<String>)=p.edit().putStringSet("packages",v).apply()
}
