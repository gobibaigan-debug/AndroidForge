# ICSE Study Tracker — Native Android Source

This is the native Android implementation of the ICSE Class 9 Study Tracker. It is a Kotlin + Jetpack Compose project and is **not a WebView wrapper**.

## App features implemented
- Email/password accounts with separate online user data
- Science / Commerce stream selection
- Neon/dark Study Tracker UI
- Study timer with subject + topic/chapter and online session saving
- 5-question manual study verification with 2/5 pass requirement
- Stats: day/week/month study totals and leaderboards
- 3 Sunday tests supplied by the online syllabus/test endpoint
- Difficulty + marks, answer checking, explanations, scoring, retry, previous attempts
- Per-test leaderboard
- Exam planner
- Community chat and private DMs
- Multiple image/video/PDF/audio attachments
- Camera photo and video capture
- Voice notes
- Poll creation and voting
- Delivery/read ticks and community Seen By data
- Local “delete for myself” message hiding
- Native notifications for chat and study reminders
- User-selected Focus Mode apps only
- Android Accessibility-based app interception for Focus Mode
- 50-minute foreground Focus timer
- No advertising SDK or ad code
- Android API compatibility guards down to minSdk 21

## Backend
The app connects to the existing online Floot backend:
`https://icse-study-tracker-neon.floot.app`

No database password, service-role key, or Supabase secret is embedded in the Android client.

## Android compatibility
`minSdk = 21` (Android 5.0), `targetSdk = 35`.

Newer Android releases require newer runtime permission handling. For example, Android 13+ has the `POST_NOTIFICATIONS` runtime permission, while older Android releases use their earlier notification model. The code checks the API level before using newer APIs.

Focus Mode requires the user to explicitly enable the app's Accessibility Service. The app only intercepts package IDs the user selected; it does not silently block every installed app.

## Build
Open this directory in Android Studio with an Android SDK installed. The project uses Gradle Kotlin DSL. The container used during development did not have an Android SDK/Gradle distribution, so a device/APK build could not be executed here.

Recommended final verification on a real Android device/emulator:
1. Install debug APK.
2. Register and log in with two accounts.
3. Test community + DM text, image, video, PDF, audio, camera, voice note and polls.
4. Run all three Sunday tests and verify scores/explanations/retry/leaderboards.
5. Run timer, manual verification, stats and planner.
6. Select two distracting apps, enable Accessibility, start Focus, and verify only those apps are intercepted.
7. Verify notifications on Android 5–12 and Android 13+ (grant notification permission on Android 13+).

## Important limitation of this source-only delivery
The source is complete enough for Android Studio integration, but the development container did not include the Android SDK, emulator, Gradle distribution, or a physical device. Therefore no claim is made that an APK was device-tested inside this environment.

## AndroidForge build identity

- Application name: **ICSE Class 9 Study Tracker**
- Application ID: `com.icse.studytracker`
- Native stack: Kotlin + Jetpack Compose
- Recommended first AndroidForge build: **debug**
