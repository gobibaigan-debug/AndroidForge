# AndroidForge build instructions

This archive is a native Kotlin + Jetpack Compose Android project.

Recommended AndroidForge settings:
- `zip_source`: `input-directory`
- `build_variant`: `debug`
- `enable_ndk`: `false`

Important: this project intentionally does **not** include a partial Gradle wrapper. AndroidForge's documented fallback selects a compatible system Gradle from the detected AGP version when the wrapper is absent. This avoids wrapper-regeneration ambiguity.

Expected identity:
- App name: ICSE Class 9 Study Tracker
- Application ID: com.icse.studytracker
- Launcher activity: com.icse.studytracker.MainActivity
