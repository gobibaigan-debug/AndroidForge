#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
command -v kotlinc >/dev/null || { echo "FAIL: kotlinc missing"; exit 1; }
python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('PASS: XML parsing')
PY
rm -f /tmp/icse-native-kotlin.err /tmp/icse-native-kotlin.jar
kotlinc $(find app/src/main/java -name '*.kt' | sort) -d /tmp/icse-native-kotlin.jar 2>/tmp/icse-native-kotlin.err || true
if grep -Eq 'expecting|unexpected tokens|unclosed' /tmp/icse-native-kotlin.err; then
  echo 'FAIL: Kotlin parser errors'
  grep -E 'expecting|unexpected tokens|unclosed' /tmp/icse-native-kotlin.err | head -50
  exit 1
fi
echo 'PASS: Kotlin parser syntax (Android/Compose symbols are unresolved without Android SDK)'
python3 - <<'PY'
from pathlib import Path
m=Path('app/src/main/AndroidManifest.xml').read_text()
checks=['android.permission.INTERNET','android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.POST_NOTIFICATIONS','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_SPECIAL_USE','FocusAccessibilityService','FocusTimerService','android:foregroundServiceType="specialUse"']
for x in checks:
    assert x in m, x
s=Path('app/src/main/java/com/icse/studytracker/MainActivity.kt').read_text()
for x in ['ActivityResultContracts.OpenMultipleDocuments','ActivityResultContracts.TakePicture','ActivityResultContracts.CaptureVideo','MediaRecorder','poll_vote','community_read','seen_by','dm_read','test_leaderboard','manual_questions','manual_grade']:
    assert x in s, x
print('PASS: native feature contract audit')
PY
if grep -RInE 'TODO|FIXME|IMPLEMENT_ME|PLACEHOLDER' app/src/main/java app/src/main/res >/tmp/icse-placeholders 2>/dev/null; then
  echo 'FAIL: placeholder markers found'; cat /tmp/icse-placeholders; exit 1
fi
echo 'PASS: no placeholder markers'
echo 'All source-level checks passed.'
