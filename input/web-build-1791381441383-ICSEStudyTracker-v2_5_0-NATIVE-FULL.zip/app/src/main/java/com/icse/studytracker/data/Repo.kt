package com.icse.studytracker.data

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.icse.studytracker.focus.FocusPrefs
import com.icse.studytracker.notifications.FocusTimerService
import com.icse.studytracker.notifications.LiveNotifyService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Single source of truth for everything the UI shows. All fields are Compose state. */
object Repo {
    private val FIELDS = listOf("read", "notes", "practice", "revised")

    lateinit var state: AppState
    private lateinit var app: Context
    private var ready = false
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ---- session ----
    var loggedIn by mutableStateOf(false)
    var userId by mutableStateOf("")
    var userName by mutableStateOf("")
    var stream by mutableStateOf("Science")
    var sessionExpired by mutableStateOf(false)
    var tab by mutableStateOf("Home")
    var chatFullScreen by mutableStateOf(false)

    // ---- study data ----
    var progress by mutableStateOf<Map<String, Set<String>>>(emptyMap())
    var plan by mutableStateOf<JSONObject?>(null)
    var rows by mutableStateOf<List<StudyRow>>(emptyList())
    private var serverRows: List<StudyRow> = emptyList()
    var serverStreak by mutableIntStateOf(0)
    var pendingCount by mutableIntStateOf(0)
    var board by mutableStateOf<List<LeaderRow>>(emptyList())
    var boardPeriod by mutableStateOf("all")
    var boardLoading by mutableStateOf(false)
    var tests by mutableStateOf<List<TestDef>>(emptyList())          // server question bank
    var sundayTests by mutableStateOf<List<TestDef>>(emptyList())    // this week's 3 generated tests
    var testsLoading by mutableStateOf(false)
    var testsError by mutableStateOf("")
    var attempts by mutableStateOf<List<Attempt>>(emptyList())
    var members by mutableStateOf<List<Member>>(emptyList())
    var studySubject by mutableStateOf("")

    // ---- timer ----
    var now by mutableLongStateOf(System.currentTimeMillis())
    var timerRunning by mutableStateOf(false)
    var timerAccum by mutableLongStateOf(0L)
    var timerStartedAt by mutableLongStateOf(0L)
    var timerSubject by mutableStateOf("Physics")
    var timerTopic by mutableStateOf("")

    // ---- focus ----
    var focusEnd by mutableLongStateOf(0L)
    var focusPackages by mutableStateOf<Set<String>>(emptySet())
    private var focusLabelMap = JSONObject()
    var serverFocusLabels by mutableStateOf<List<String>>(emptyList())

    var focusSubject by mutableStateOf("")
    var focusTopic by mutableStateOf("")

    val focusActive: Boolean get() = focusEnd > now

    fun init(context: Context) {
        if (ready) return
        ready = true
        app = context.applicationContext
        state = AppState(app)
        Api.init(app)
        userId = state.userId
        userName = state.userName
        stream = state.str("stream", "Science")
        loggedIn = state.cookie != null
        loadLocalProgress()
        loadHidden()
        rebuildSundayTests()
        try {
            val cached = state.str("testsCache")
            if (cached.isNotBlank()) {
                tests = parseTests(JSONObject(cached))
                rebuildSundayTests()
            }
        } catch (e: Exception) {
            tests = emptyList()
        }
        loadFocusLocal()
        focusSubject = state.str("focusSubject")
        focusTopic = state.str("focusTopic")
        restoreTimer()
        rebuildRows()
        scope.launch {
            while (true) {
                delay(1000)
                now = System.currentTimeMillis()
                val fe = FocusPrefs(app).endAt()
                if (fe != focusEnd) focusEnd = fe
                checkFocusRecord()
            }
        }
        if (loggedIn) refreshAll()
    }

    fun toast(msg: String) {
        if (msg.isNotBlank()) Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
    }

    /** Returns a user-facing message. Signs the user out when the session has expired. */
    fun handleError(e: Exception): String {
        if (e is Api.ApiException && e.status == 401) {
            sessionExpired = true
            loggedIn = false
            state.cookie = null
            return "Your session expired. Please sign in again."
        }
        return e.message ?: "Something went wrong"
    }

    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }

    // ------------------------------------------------------------------ auth

    fun lastEmail(): String = state.str("lastEmail")

    fun signIn(email: String, password: String, onDone: (String?) -> Unit) {
        scope.launch {
            try {
                val u = io { Api.login(email, password) }
                afterAuth(u, email, null)
                onDone(null)
            } catch (e: Exception) {
                onDone(handleError(e))
            }
        }
    }

    fun signUp(name: String, email: String, password: String, chosenStream: String, onDone: (String?) -> Unit) {
        scope.launch {
            try {
                val u = io { Api.register(name, email, password) }
                afterAuth(u, email, chosenStream)
                onDone(null)
            } catch (e: Exception) {
                onDone(handleError(e))
            }
        }
    }

    private fun afterAuth(u: JSONObject, email: String, chosenStream: String?) {
        userId = u.optString("id", "")
        userName = u.optString("displayName", email.substringBefore('@'))
        state.userId = userId
        state.userName = userName
        state.email = email
        state.put("lastEmail", email)
        if (chosenStream != null) {
            stream = chosenStream
            state.put("stream", chosenStream)
            state.putBool("progressDirty", true)
        }
        sessionExpired = false
        loggedIn = true
        tab = "Home"
        refreshAll()
        applyNotificationSetting()
    }

    fun applyNotificationSetting() {
        if (loggedIn && state.notificationsEnabled) LiveNotifyService.start(app) else LiveNotifyService.stop(app)
    }

    fun signOut() {
        LiveNotifyService.stop(app)
        state.logout()
        loggedIn = false
        userId = ""
        userName = ""
        progress = emptyMap()
        plan = null
        rows = emptyList()
        serverRows = emptyList()
        tests = emptyList()
        attempts = emptyList()
        board = emptyList()
        members = emptyList()
        timerReset()
    }

    // ------------------------------------------------------------------ loading

    fun refreshAll() {
        scope.launch {
            try {
                val p = io { Api.trackerObj("profile") }
                applyProfile(p)
            } catch (e: Exception) {
                handleError(e)
                if (!loggedIn) return@launch
            }
            flushPending()
            loadRows()
            loadBoard(boardPeriod)
            loadTests()
            loadAttempts()
            loadMembers()
        }
    }

    private fun applyProfile(p: JSONObject) {
        val st = p.optString("stream", "Science")
        if (!state.bool("progressDirty")) {
            stream = if (st.contains("commerce", true)) "Commerce" else "Science"
            state.put("stream", stream)
            applyProgress(p.optJSONObject("progressJson"))
            state.put("progressJson", progressJson().toString())
        } else {
            pushProfile()
        }
        serverStreak = p.optInt("streak", 0)
        val da = p.optJSONArray("distractingApps")
        serverFocusLabels = da?.strings() ?: emptyList()
    }

    private fun loadLocalProgress() {
        try {
            val raw = state.str("progressJson")
            if (raw.isNotBlank()) applyProgress(JSONObject(raw))
        } catch (e: Exception) {
            progress = emptyMap()
        }
    }

    private fun applyProgress(j: JSONObject?) {
        val m = HashMap<String, Set<String>>()
        var pl: JSONObject? = null
        if (j != null) {
            val keys = j.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = j.optJSONObject(k) ?: continue
                if (k == "__daily") {
                    pl = v
                    continue
                }
                val s = HashSet<String>()
                for (f in FIELDS) if (v.optBoolean(f, false)) s.add(f)
                if (s.isNotEmpty()) m[k] = s
            }
        }
        progress = m
        // The plan lives in its own local slot so it can never be lost when the server copy is replaced.
        val local = loadPlanLocal()
        if (local != null) {
            plan = local
        } else {
            plan = pl
            if (pl != null) savePlanLocal(pl)
        }
    }

    private fun planKey(): String = "keep_plan_" + userId

    private fun loadPlanLocal(): JSONObject? {
        return try {
            val raw = state.str(planKey())
            if (raw.isBlank()) null else JSONObject(raw)
        } catch (e: Exception) {
            null
        }
    }

    private fun savePlanLocal(pl: JSONObject?) {
        if (pl == null) state.remove(planKey()) else state.put(planKey(), pl.toString())
    }

    private fun progressJson(): JSONObject {
        val o = JSONObject()
        for ((k, s) in progress) {
            val c = JSONObject()
            for (f in FIELDS) c.put(f, s.contains(f))
            o.put(k, c)
        }
        val pl = plan
        if (pl != null) o.put("__daily", pl)
        return o
    }

    private fun focusLabelList(): List<String> {
        val out = ArrayList<String>()
        for (p in focusPackages) {
            val l = focusLabelMap.optString(p, "")
            if (l.isNotBlank()) out.add(l)
        }
        return out
    }

    private fun pushProfile() {
        val payload = JSONObject()
            .put("stream", stream)
            .put("distractingApps", JSONArray(focusLabelList().take(30)))
            .put("progressJson", progressJson())
        scope.launch {
            try {
                io { Api.tracker("profile_update", payload) }
                state.putBool("progressDirty", false)
            } catch (e: Exception) {
                val msg = handleError(e)
                if (loggedIn) toast("Saved on this phone; sync will retry ($msg)")
            }
        }
    }

    private fun saveProgress() {
        state.put("progressJson", progressJson().toString())
        state.putBool("progressDirty", true)
        pushProfile()
    }

    // ------------------------------------------------------------------ chapters

    fun has(subject: String, chapter: String, field: String): Boolean =
        progress[Syllabus.key(subject, chapter)]?.contains(field) == true

    fun toggleField(subject: String, chapter: String, field: String) {
        val key = Syllabus.key(subject, chapter)
        val cur = HashSet(progress[key] ?: emptySet())
        if (cur.contains(field)) cur.remove(field) else cur.add(field)
        val m = HashMap(progress)
        if (cur.isEmpty()) m.remove(key) else m[key] = cur
        progress = m
        saveProgress()
    }

    fun isFinished(key: String): Boolean {
        val s = progress[key] ?: return false
        return s.contains("read") && s.contains("notes") && s.contains("practice")
    }

    fun setFinished(key: String, done: Boolean) {
        val cur = HashSet(progress[key] ?: emptySet())
        if (done) {
            cur.add("read"); cur.add("notes"); cur.add("practice")
        } else {
            cur.remove("read"); cur.remove("notes"); cur.remove("practice")
        }
        val m = HashMap(progress)
        if (cur.isEmpty()) m.remove(key) else m[key] = cur
        progress = m
        saveProgress()
    }

    fun totalChapters(): Int = Syllabus.allKeys(stream).size

    fun finishedChapters(): Int = Syllabus.allKeys(stream).count { isFinished(it) }

    fun overallPercent(): Int {
        val t = totalChapters()
        return if (t == 0) 0 else Math.round(finishedChapters() * 100f / t)
    }

    fun subjectFinished(subject: String): Int =
        Syllabus.chaptersOf(subject).count { isFinished(Syllabus.key(subject, it)) }

    fun changeStream(newStream: String) {
        if (newStream == stream) return
        stream = newStream
        state.put("stream", newStream)
        rebuildSundayTests()
        if (!Syllabus.subjectsFor(newStream).contains(timerSubject)) timerSubject = Syllabus.subjectsFor(newStream).first()
        saveProgress()
    }

    // ------------------------------------------------------------------ planner / daily tasks

    fun examDate(): String = plan?.optString("exam", "") ?: ""

    fun finishBy(): String = plan?.optString("finishBy", "") ?: ""

    /** Spreads every unfinished chapter over the days between today and the finish date. */
    fun buildPlan(examDate: String, finishBy: String) {
        val today = todayKey()
        val pending = Syllabus.subjectsFor(stream).map { s ->
            Syllabus.chaptersOf(s).map { Syllabus.key(s, it) }.filter { !isFinished(it) }
        }
        val ordered = ArrayList<String>()
        var i = 0
        while (pending.any { i < it.size }) {
            for (list in pending) if (i < list.size) ordered.add(list[i])
            i++
        }
        val days = Math.max(1, daysBetween(today, finishBy) + 1)
        val perDay = Math.max(1, (ordered.size + days - 1) / days)
        val schedule = JSONObject()
        var idx = 0
        var d = 0
        while (idx < ordered.size) {
            val dateKey = addDays(today, Math.min(d, days - 1))
            val arr = schedule.optJSONArray(dateKey) ?: JSONArray()
            val end = Math.min(ordered.size, idx + perDay)
            while (idx < end) {
                arr.put(ordered[idx])
                idx++
            }
            schedule.put(dateKey, arr)
            d++
        }
        plan = JSONObject()
            .put("exam", examDate)
            .put("finishBy", finishBy)
            .put("created", today)
            .put("schedule", schedule)
        savePlanLocal(plan)
        saveProgress()

        // Also store the revision calendar (same layout as the website: revision starts 2 months before the exam).
        val start = addMonths(examDate, -2)
        val plans = JSONArray()
        var n = 0
        for (s in Syllabus.subjectsFor(stream)) {
            for (c in Syllabus.chaptersOf(s)) {
                val due = addDays(start, n / 3)
                plans.put(
                    JSONObject().put("subject", s).put("chapter", c)
                        .put("examDate", due + "T00:00:00.000Z").put("revisionSlot", n % 3 + 1)
                        .put("completed", isFinished(Syllabus.key(s, c)))
                )
                n++
            }
        }
        scope.launch {
            try {
                io { Api.tracker("exam", JSONObject().put("plans", plans)) }
            } catch (e: Exception) {
                handleError(e)
            }
        }
    }

    fun clearPlan() {
        plan = null
        savePlanLocal(null)
        saveProgress()
    }

    /** Chapter keys that should be studied today (today's list plus anything overdue). */
    fun todaysTasks(): List<String> {
        val sch = plan?.optJSONObject("schedule") ?: return emptyList()
        val today = todayKey()
        val keys = ArrayList<String>()
        val dateKeys = sch.keys()
        while (dateKeys.hasNext()) keys.add(dateKeys.next())
        keys.sort()
        val out = ArrayList<String>()
        for (d in keys) {
            if (d > today) continue
            val arr = sch.optJSONArray(d) ?: continue
            for (k in arr.strings()) {
                if (d == today || !isFinished(k)) out.add(k)
            }
        }
        return out.distinct().filter { Syllabus.allKeys(stream).contains(it) }
    }

    fun upcoming(days: Int): List<Pair<String, List<String>>> {
        val sch = plan?.optJSONObject("schedule") ?: return emptyList()
        val today = todayKey()
        val out = ArrayList<Pair<String, List<String>>>()
        for (i in 1..days) {
            val d = addDays(today, i)
            val arr = sch.optJSONArray(d)
            if (arr != null && arr.length() > 0) out.add(Pair(d, arr.strings()))
        }
        return out
    }

    // ------------------------------------------------------------------ study sessions

    private fun pendingList(): JSONArray =
        try { JSONArray(state.str("pending", "[]")) } catch (e: Exception) { JSONArray() }

    fun recordSession(subject: String, chapter: String, seconds: Int, verified: Boolean) {
        val arr = pendingList()
        arr.put(
            JSONObject().put("subject", subject).put("chapter", chapter)
                .put("seconds", seconds).put("verified", verified).put("ts", System.currentTimeMillis())
        )
        state.put("pending", arr.toString())
        pendingCount = arr.length()
        rebuildRows()
        scope.launch {
            flushPending()
            loadRows()
        }
    }

    private suspend fun flushPending() {
        val arr = pendingList()
        pendingCount = arr.length()
        if (arr.length() == 0) return
        val remaining = JSONArray()
        var failed = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (failed) {
                remaining.put(o)
                continue
            }
            try {
                val ch = o.optString("chapter")
                val payload = JSONObject()
                    .put("subject", o.optString("subject"))
                    .put("chapter", if (ch.isBlank()) JSONObject.NULL else ch)
                    .put("durationSeconds", o.optInt("seconds"))
                    .put("verified", o.optBoolean("verified"))
                io { Api.tracker("study", payload) }
            } catch (e: Exception) {
                failed = true
                remaining.put(o)
                handleError(e)
            }
        }
        state.put("pending", remaining.toString())
        pendingCount = remaining.length()
        rebuildRows()
    }

    suspend fun loadRows() {
        try {
            val arr = io { Api.trackerArr("study_stats") }
            serverRows = arr.objects().map {
                StudyRow(
                    subject = it.optString("subject", "General"),
                    chapter = it.optString("chapter", "").let { c -> if (c == "null") "" else c },
                    seconds = it.optInt("durationSeconds", 0),
                    at = parseIso(it.optString("startedAt")),
                    verified = it.optBoolean("verified", false)
                )
            }
            rebuildRows()
        } catch (e: Exception) {
            handleError(e)
        }
    }

    private fun rebuildRows() {
        val pend = pendingList().objects().map {
            StudyRow(
                it.optString("subject", "General"), it.optString("chapter", ""),
                it.optInt("seconds", 0), it.optLong("ts", System.currentTimeMillis()),
                it.optBoolean("verified", false), true
            )
        }
        rows = pend + serverRows
    }

    fun secondsToday(): Long {
        val t = todayKey()
        return rows.filter { dayKey(it.at) == t }.sumOf { it.seconds.toLong() }
    }

    fun secondsTotal(): Long = rows.sumOf { it.seconds.toLong() }

    fun streakDays(): Int {
        if (rows.isEmpty()) return serverStreak
        val days = rows.map { dayKey(it.at) }.toSet()
        var day = todayKey()
        if (!days.contains(day)) day = addDays(day, -1)
        var n = 0
        while (days.contains(day) && n < 3650) {
            n++
            day = addDays(day, -1)
        }
        return n
    }

    // ------------------------------------------------------------------ timer

    private fun restoreTimer() {
        timerRunning = state.bool("timerRunning")
        timerAccum = state.long("timerAccum")
        timerStartedAt = state.long("timerStartedAt")
        val savedSubject = state.str("timerSubject")
        timerSubject = if (savedSubject.isBlank()) Syllabus.subjectsFor(stream).first() else savedSubject
        timerTopic = state.str("timerTopic")
    }

    private fun persistTimer() {
        state.putBool("timerRunning", timerRunning)
        state.putLong("timerAccum", timerAccum)
        state.putLong("timerStartedAt", timerStartedAt)
        state.put("timerSubject", timerSubject)
        state.put("timerTopic", timerTopic)
    }

    fun timerSeconds(): Long {
        val extra = if (timerRunning) (now - timerStartedAt) / 1000 else 0L
        return timerAccum + Math.max(0L, extra)
    }

    fun timerToggle() {
        val t = System.currentTimeMillis()
        if (timerRunning) {
            timerAccum += Math.max(0L, (t - timerStartedAt) / 1000)
            timerRunning = false
        } else {
            timerStartedAt = t
            now = t
            timerRunning = true
        }
        persistTimer()
    }

    fun timerSetSubject(s: String) {
        timerSubject = s
        persistTimer()
    }

    fun timerSetTopic(t: String) {
        timerTopic = t
        persistTimer()
    }

    fun timerReset() {
        timerRunning = false
        timerAccum = 0L
        timerStartedAt = 0L
        persistTimer()
    }

    /** Saves the running timer as a study session. Returns false when it is too short. */
    fun timerSave(): Boolean {
        val secs = timerSeconds()
        if (secs < 5) return false
        recordSession(timerSubject, timerTopic.trim(), secs.toInt(), false)
        toast("Saved ${fmtDur(secs)} of ${timerSubject}")
        timerReset()
        return true
    }

    // ------------------------------------------------------------------ leaderboard / members

    private fun mySecondsIn(period: String): Long {
        val nowMs = System.currentTimeMillis()
        return when (period) {
            "day" -> rows.filter { dayKey(it.at) == todayKey() }.sumOf { it.seconds.toLong() }
            "week" -> rows.filter { it.at >= nowMs - 7 * 86400000L }.sumOf { it.seconds.toLong() }
            "month" -> rows.filter { it.at >= nowMs - 30 * 86400000L }.sumOf { it.seconds.toLong() }
            else -> rows.sumOf { it.seconds.toLong() }
        }
    }

    fun loadBoard(period: String) {
        boardPeriod = period
        scope.launch {
            boardLoading = true
            try {
                val tzMinutes = java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
                val arr = io {
                    Api.trackerArr("leaderboard", JSONObject().put("period", period).put("tzOffsetMinutes", tzMinutes))
                }
                val list = ArrayList<LeaderRow>()
                for (o in arr.objects()) {
                    list.add(
                        LeaderRow(
                            o.optString("displayName", "Student"),
                            Math.round(o.optDouble("totalMinutes", 0.0) * 60.0),
                            o.optInt("streak", 0)
                        )
                    )
                }
                // The server rounds the day/week/month boards to whole minutes, so short sessions show as 0.
                // Use the exact time recorded on this phone for the signed-in student's own row.
                val mine = mySecondsIn(period)
                val idx = list.indexOfFirst { it.name == userName }
                if (idx >= 0) {
                    val cur = list[idx]
                    // the phone's own records are exact; "all time" keeps the larger of the two
                    val secs = if (period == "all") Math.max(cur.seconds, mine) else if (rows.isNotEmpty()) mine else cur.seconds
                    list[idx] = LeaderRow(cur.name, secs, Math.max(cur.streak, streakDays()))
                } else if (mine > 0) {
                    list.add(LeaderRow(userName, mine, streakDays()))
                }
                list.sortByDescending { it.seconds }
                board = list
            } catch (e: Exception) {
                handleError(e)
            }
            boardLoading = false
        }
    }

    fun loadMembers() {
        scope.launch {
            try {
                val arr = io { Api.trackerArr("members") }
                members = arr.objects()
                    .filter { it.optString("id") != userId }
                    .map {
                        Member(
                            it.optString("id"), it.optString("displayName", "Student"),
                            it.optInt("streak", 0), Math.round(it.optDouble("totalMinutes", 0.0)).toInt(),
                            parseIso(it.optString("lastSeenAt"))
                        )
                    }
            } catch (e: Exception) {
                handleError(e)
            }
        }
    }

    // ------------------------------------------------------------------ tests

    private fun parseTests(data: JSONObject): List<TestDef> {
        val arr = data.optJSONArray("tests") ?: return emptyList()
        return arr.objects().map { t ->
            val qs = (t.optJSONArray("questions") ?: JSONArray()).objects().map { q ->
                Question(
                    q = q.optString("q"),
                    options = (q.optJSONArray("options") ?: JSONArray()).strings(),
                    answer = q.optInt("answer", 0),
                    explanation = q.optString("explanation", ""),
                    marks = q.optInt("marks", 1),
                    difficulty = q.optString("difficulty", ""),
                    subject = q.optString("subject", ""),
                    chapter = q.optString("chapter", "")
                )
            }
            TestDef(t.optInt("slot", 0), qs)
        }
    }

    fun loadTests() {
        scope.launch {
            testsLoading = true
            testsError = ""
            try {
                val data = io { Api.trackerObj("tests") }
                val parsed = parseTests(data)
                if (parsed.isNotEmpty()) {
                    tests = parsed
                    rebuildSundayTests()
                    state.put("testsCache", data.toString())
                } else {
                    testsError = "No tests were returned by the server."
                }
            } catch (e: Exception) {
                testsError = handleError(e)
                try {
                    val cached = state.str("testsCache")
                    if (cached.isNotBlank() && tests.isEmpty()) {
                        tests = parseTests(JSONObject(cached))
                        rebuildSundayTests()
                    }
                } catch (e2: Exception) {
                    // ignore broken cache
                }
            }
            testsLoading = false
        }
    }

    fun rebuildSundayTests() {
        sundayTests = TestBuilder.buildChapterTests(stream, tests.flatMap { it.questions })
    }

    fun loadAttempts() {
        scope.launch {
            try {
                val arr = io { Api.trackerArr("attempts") }
                attempts = arr.objects().map {
                    Attempt(
                        it.optInt("testNumber", 0), it.optString("score", "0").toDoubleOrNull() ?: 0.0,
                        it.optString("totalMarks", "0").toDoubleOrNull() ?: 0.0, parseIso(it.optString("completedAt"))
                    )
                }
            } catch (e: Exception) {
                handleError(e)
            }
        }
    }

    fun submitAttempt(testNumber: Int, score: Int, total: Int, answers: Map<Int, Int>, extra: JSONObject) {
        val ans = JSONObject()
        for ((k, v) in answers) ans.put(k.toString(), v)
        val keys = extra.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            ans.put(k, extra.opt(k))
        }
        val payload = JSONObject().put("testNumber", testNumber).put("score", score).put("totalMarks", total).put("answers", ans)
        scope.launch {
            try {
                io { Api.tracker("attempt", payload) }
                loadAttempts()
            } catch (e: Exception) {
                toast(handleError(e))
            }
        }
    }

    suspend fun testLeaderboard(testNumber: Int): List<Triple<String, Double, Double>> {
        return try {
            val arr = io { Api.trackerArr("test_leaderboard", JSONObject().put("testNumber", testNumber)) }
            arr.objects().map {
                Triple(
                    it.optString("displayName", "Student"),
                    it.optString("score", "0").toDoubleOrNull() ?: 0.0,
                    it.optString("totalMarks", "0").toDoubleOrNull() ?: 0.0
                )
            }
        } catch (e: Exception) {
            handleError(e)
            emptyList()
        }
    }

    // ------------------------------------------------------------------ chat: "delete for me"

    var hiddenKeys by mutableStateOf<Set<String>>(emptySet())

    private fun hiddenStorageKey(): String = "keep_hidden_" + userId

    private fun loadHidden() {
        try {
            val arr = JSONArray(state.str(hiddenStorageKey(), "[]"))
            hiddenKeys = arr.strings().toSet()
        } catch (e: Exception) {
            hiddenKeys = emptySet()
        }
    }

    fun hideMessage(key: String) {
        val cur = HashSet(hiddenKeys)
        cur.add(key)
        hiddenKeys = cur
        state.put(hiddenStorageKey(), JSONArray(cur.toList()).toString())
    }

    fun isHidden(key: String): Boolean = hiddenKeys.contains(key)

    // ------------------------------------------------------------------ manual-time verification

    /** Five multiple-choice questions for the manual-time check, taken from the question bank for this subject. */
    fun verificationQuestions(subject: String, topic: String): List<Question> {
        val pool = tests.flatMap { it.questions }.filter { !it.written && it.options.size >= 2 }
        val words = (topic + " " + subject).lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 4 }.toSet()
        fun relevance(q: Question): Int {
            val text = (q.chapter + " " + q.q).lowercase()
            return words.count { text.contains(it) }
        }
        val sameSubject = pool.filter { it.subject == subject }.sortedByDescending { relevance(it) }
        val picked = ArrayList<Question>()
        picked.addAll(sameSubject.take(10).shuffled().take(5))
        if (picked.size < 5) {
            val rest = pool.filter { !picked.contains(it) }.shuffled()
            for (q in rest) {
                if (picked.size >= 5) break
                picked.add(q)
            }
        }
        return picked
    }

    // ------------------------------------------------------------------ focus mode

    private fun loadFocusLocal() {
        val fp = FocusPrefs(app)
        focusPackages = fp.packages()
        focusEnd = fp.endAt()
        try {
            focusLabelMap = JSONObject(fp.labels())
        } catch (e: Exception) {
            focusLabelMap = JSONObject()
        }
    }

    fun toggleFocusApp(a: AppInfo) {
        val cur = HashSet(focusPackages)
        if (cur.contains(a.pkg)) {
            cur.remove(a.pkg)
        } else {
            cur.add(a.pkg)
            focusLabelMap.put(a.pkg, a.label)
        }
        focusPackages = cur
        val fp = FocusPrefs(app)
        fp.setPackages(cur)
        fp.setLabels(focusLabelMap.toString())
        syncFocusApps()
    }

    /** Pre-selects installed apps whose names match the list saved on the server (e.g. from the website). */
    fun hydrateFocus(installed: List<AppInfo>) {
        if (focusPackages.isNotEmpty() || serverFocusLabels.isEmpty()) return
        val wanted = serverFocusLabels.map { it.trim().lowercase() }
        val matches = installed.filter { wanted.contains(it.label.trim().lowercase()) }
        if (matches.isEmpty()) return
        val cur = HashSet<String>()
        for (m in matches) {
            cur.add(m.pkg)
            focusLabelMap.put(m.pkg, m.label)
        }
        focusPackages = cur
        val fp = FocusPrefs(app)
        fp.setPackages(cur)
        fp.setLabels(focusLabelMap.toString())
    }

    private fun syncFocusApps() {
        val labels = JSONArray(focusLabelList().take(30))
        scope.launch {
            try {
                io { Api.tracker("focus_apps", JSONObject().put("apps", labels)) }
            } catch (e: Exception) {
                handleError(e)
            }
        }
    }

    fun chooseFocusSubject(v: String) {
        focusSubject = v
        state.put("focusSubject", v)
    }

    fun chooseFocusTopic(v: String) {
        focusTopic = v
        state.put("focusTopic", v)
    }

    fun startFocus(minutes: Int) {
        val start = System.currentTimeMillis()
        val end = start + minutes * 60_000L
        val subject = if (focusSubject.isBlank()) Syllabus.subjectsFor(stream).first() else focusSubject
        FocusPrefs(app).start(end)
        focusEnd = end
        state.put(
            "focus_rec",
            JSONObject().put("start", start).put("end", end).put("subject", subject).put("topic", focusTopic.trim()).toString()
        )
        FocusTimerService.start(app)
    }

    fun endFocus() {
        FocusPrefs(app).stop()
        focusEnd = 0L
        FocusTimerService.stop(app)
        finalizeFocus(System.currentTimeMillis())
    }

    /** Adds the focus session (full length, or until the user ended it) to the student's study time. */
    private fun finalizeFocus(at: Long) {
        val raw = state.str("focus_rec")
        if (raw.isBlank()) return
        state.remove("focus_rec")
        try {
            val o = JSONObject(raw)
            val start = o.optLong("start")
            val stop = Math.min(at, o.optLong("end"))
            val secs = (stop - start) / 1000
            if (secs >= 5) {
                recordSession(o.optString("subject", "General"), o.optString("topic", ""), secs.toInt(), false)
                toast("Focus time saved: ${fmtDur(secs)}")
            }
        } catch (e: Exception) {
            // ignore a broken record
        }
    }

    /** Called every second: a session that ran to the end (even with the app closed) is recorded here. */
    private fun checkFocusRecord() {
        val raw = state.str("focus_rec")
        if (raw.isBlank()) return
        try {
            val end = JSONObject(raw).optLong("end")
            if (end > 0L && System.currentTimeMillis() >= end) finalizeFocus(end)
        } catch (e: Exception) {
            state.remove("focus_rec")
        }
    }
}
