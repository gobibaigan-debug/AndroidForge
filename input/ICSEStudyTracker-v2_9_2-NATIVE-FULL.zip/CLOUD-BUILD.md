# ICSE Class 9 Study Tracker (native Android)

Kotlin + Jetpack Compose app that talks to the Floot backend (`/_api/tracker`, `/_api/auth/*`, `/_api/upload`).
Application ID `com.icse.class9studytracker`, version 2.9.2, compile/target SDK 35, min SDK 21.

Build: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
(Gradle 8.11.1 wrapper, AGP 8.7.3, Kotlin 2.0.21, JDK 17+).

Note: the Floot server uses SuperJSON, so every request body is wrapped as {"json": ...} and every response is
unwrapped in `data/Api.kt`.

## Google Play Protect ("blocked" / "unsafe app" warning)
Play Protect warns about any app installed from outside the Play Store, especially one that uses an
Accessibility service (Focus Mode). The warning cannot be removed from the code alone. To reduce it:
1. Build a RELEASE APK and sign it with your own keystore (keep the same keystore for every update).
   Debug-signed APKs are flagged far more often.
2. On the phone, tap "More details" -> "Install anyway", or turn off Play Protect > "Scan apps with Play Protect" while installing.
3. To remove the warning for everyone, publish the app on Google Play (or register the developer at Play Console).
