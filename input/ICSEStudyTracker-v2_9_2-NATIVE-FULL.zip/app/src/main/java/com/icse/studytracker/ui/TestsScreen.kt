package com.icse.studytracker.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.icse.studytracker.data.Api
import com.icse.studytracker.data.Repo
import com.icse.studytracker.data.Syllabus
import com.icse.studytracker.data.TestDef
import com.icse.studytracker.data.fmtClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

@Composable
fun TestsScreen() {
    var activeSlot by remember { mutableStateOf(-1) }
    val active = Repo.sundayTests.firstOrNull { it.slot == activeSlot }
    if (active != null) {
        TestRunner(active) { activeSlot = -1 }
        return
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeonCard {
            Kicker("SUNDAY TESTS \u00B7 AI \u00B7 APP v2.9.2")
            H1("3 new tests every week")
            MutedText("Each test is ONE random chapter of ONE random subject, with 30\u201335 questions written fresh by AI from that chapter only: multiple-choice (marked automatically) plus high-thinking written questions. For the written ones, write on paper and upload a photo \u2014 the AI reads your handwriting and marks it.")
        }
        for ((slot, subject, chapter) in Repo.sundayTargets) {
            val t = Repo.sundayTests.firstOrNull { it.slot == slot }
            val mine = Repo.attempts.filter { it.test == slot + 1 }
            val best = mine.maxByOrNull { it.score }
            NeonCard {
                Kicker("TEST ${slot + 1}")
                Text(subject, color = Syllabus.colorOf(subject), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                H2(chapter)
                if (t == null) {
                    if (Repo.sundayLoading.contains(slot)) {
                        MutedText("\u23F3 The AI is writing this test from the chapter\u2026 this can take up to a minute the first time.")
                    } else {
                        Body(Repo.sundayErrors[slot] ?: "This test has not been made yet.", color = Bad, size = 13)
                        NeonButton("Make this test", { Repo.loadSundayTests() }, Modifier.fillMaxWidth())
                    }
                } else {
                    MutedText("${t.questions.size} questions \u00B7 ${t.totalMarks} marks")
                    MutedText("${t.mcqCount} multiple-choice + ${t.writtenCount} written high-thinking")
                    if (best != null) {
                        MutedText("Best: ${best.score.toInt()}/${best.total.toInt()} \u00B7 ${mine.size} attempt${if (mine.size == 1) "" else "s"}")
                    } else {
                        MutedText("Not attempted yet")
                    }
                    NeonButton(if (best == null) "Start test" else "Try again", { activeSlot = slot }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun TestRunner(test: TestDef, onExit: () -> Unit) {
    val ctx = LocalContext.current
    var idx by remember { mutableStateOf(0) }
    val answers = remember { mutableStateMapOf<Int, Int>() }
    val photos = remember { mutableStateMapOf<Int, Uri>() }
    var phase by remember { mutableStateOf(0) }   // 0 answering, 1 self-marking, 2 result
    val selfMarks = remember { mutableStateMapOf<Int, Int>() }
    val photoUrls = remember { mutableStateMapOf<Int, String>() }
    val feedback = remember { mutableStateMapOf<Int, String>() }
    val failed = remember { mutableStateMapOf<Int, Boolean>() }
    var grading by remember { mutableStateOf(false) }
    val startedAt = remember { System.currentTimeMillis() }
    var board by remember { mutableStateOf<List<Triple<String, Double, Double>>>(emptyList()) }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    var captureIdx by remember { mutableStateOf(0) }
    val qs = test.questions
    BackHandler(enabled = true) { onExit() }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) photos[idx] = uri
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = captureUri
        if (ok && u != null) photos[captureIdx] = u
    }

    fun openCamera() {
        try {
            val dir = File(ctx.cacheDir, "capture")
            dir.mkdirs()
            val f = File(dir, "answer-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            captureUri = uri
            captureIdx = idx
            camera.launch(uri)
        } catch (e: Exception) {
            Repo.toast("Could not open the camera")
        }
    }

    val camPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else Repo.toast("Camera permission is needed")
    }

    fun takePhoto() {
        val need = android.os.Build.VERSION.SDK_INT >= 23 &&
            ctx.checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED
        if (need) camPermission.launch(android.Manifest.permission.CAMERA) else openCamera()
    }

    var score = 0
    for ((i, q) in qs.withIndex()) {
        if (q.written) score += selfMarks[i] ?: 0 else if (answers[i] == q.answer) score += q.marks
    }
    val total = test.totalMarks

    LaunchedEffect(phase) {
        if (phase == 1) {
            grading = true
            for ((i, q) in qs.withIndex()) {
                if (!q.written || selfMarks.containsKey(i)) continue
                val uri = photos[i]
                if (uri == null) {
                    selfMarks[i] = 0
                    feedback[i] = "No photo was attached, so this answer scores 0."
                    continue
                }
                try {
                    var url = photoUrls[i]
                    if (url == null) {
                        val small = withContext(Dispatchers.IO) { shrinkPhoto(ctx, uri) }
                        val a = withContext(Dispatchers.IO) { Api.upload(ctx, small, "test-answer-$i.jpg", "image/jpeg") }
                        url = a.optString("url")
                        photoUrls[i] = url
                    }
                    val res = withContext(Dispatchers.IO) {
                        Api.trackerObjLong(
                            "grade_photo",
                            JSONObject().put("imageUrl", url).put("question", q.q).put("guide", q.guide)
                                .put("subject", q.subject).put("chapter", q.chapter)
                        )
                    }
                    selfMarks[i] = res.optInt("marks", 0).coerceIn(0, 2)
                    feedback[i] = res.optString("feedback", "")
                    failed.remove(i)
                } catch (e: Exception) {
                    failed[i] = true
                    feedback[i] = "The AI could not check this photo (" + Repo.handleError(e) + "). Mark it yourself below."
                }
            }
            grading = false
        }
        if (phase == 2) {
            val extra = JSONObject()
            for ((i, u) in photoUrls.entries.map { Pair(it.key, it.value) }) extra.put("w$i", u)
            val everything = HashMap<Int, Int>()
            everything.putAll(answers)
            everything.putAll(selfMarks)
            Repo.submitAttempt(test.slot + 1, score, total, everything, extra)
            board = Repo.testLeaderboard(test.slot + 1)
        }
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (phase == 0) {
            val q = qs[idx]
            NeonCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Kicker("TEST ${test.slot + 1} \u00B7 QUESTION ${idx + 1}/${qs.size}")
                    Text("   " + fmtClock((Repo.now - startedAt) / 1000), color = Muted, fontSize = 12.sp)
                }
                ProgressBar((idx + 1) / qs.size.toFloat())
                Text(
                    "${q.subject} \u00B7 ${q.chapter}",
                    color = Syllabus.colorOf(q.subject), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
                if (q.written) {
                    Text(
                        "WRITTEN \u00B7 HIGH-THINKING \u00B7 ${q.marks} marks",
                        color = Hot, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
                    )
                } else {
                    MutedText("${q.difficulty} \u00B7 ${q.marks} mark${if (q.marks == 1) "" else "s"}")
                }
                Text(q.q, color = Txt, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)

                if (q.written) {
                    MutedText(if (q.photoRequired) "Write your full working on paper and upload a clear photo." else "Write your answer on paper; a photo is optional.")
                    val has = photos[idx] != null
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonButton("\uD83D\uDCF7 Take photo", { takePhoto() }, Modifier.weight(1f))
                        NeonButton("\uD83D\uDDBC Upload", { gallery.launch("image/*") }, Modifier.weight(1f), secondary = true)
                    }
                    if (has) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Body("\u2705 Photo attached", color = Good, size = 14)
                            Text("Remove", color = Bad, fontSize = 13.sp, modifier = Modifier.clickable { photos.remove(idx) })
                        }
                    }
                } else {
                    for ((oi, opt) in q.options.withIndex()) {
                        val picked = answers[idx] == oi
                        val shape = RoundedCornerShape(11.dp)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(shape)
                                .background(if (picked) Violet.copy(alpha = 0.25f) else Panel)
                                .border(1.dp, if (picked) Violet else Line, shape)
                                .clickable { answers[idx] = oi }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("${'A' + oi}", color = if (picked) Cyan else Muted, fontWeight = FontWeight.Bold)
                            Text(opt, color = Txt, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Back", { if (idx > 0) idx-- }, Modifier.weight(1f), enabled = idx > 0, secondary = true)
                    if (idx < qs.size - 1) {
                        NeonButton("Next", { idx++ }, Modifier.weight(1f))
                    } else {
                        NeonButton("Finish", { phase = if (test.writtenCount > 0) 1 else 2 }, Modifier.weight(1f))
                    }
                }
                Text(
                    "Finish now (${answers.size}/${test.mcqCount} MCQs answered, ${photos.size} photo${if (photos.size == 1) "" else "s"} attached)",
                    color = Cyan, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clickable { phase = if (test.writtenCount > 0) 1 else 2 }.padding(8.dp)
                )
                Text(
                    "Leave test",
                    color = Muted, fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth().clickable { onExit() }.padding(8.dp)
                )
            }
        } else if (phase == 1) {
            NeonCard {
                Kicker("AI IS MARKING YOUR WRITTEN ANSWERS")
                H2("${test.subject}: ${test.chapter}")
                MutedText("The AI reads each photo of your handwriting and marks it against the question: 2 = correct and complete, 1 = partly, 0 = wrong or unreadable.")
                Body(if (grading) "\u23F3 Checking\u2026 please wait" else "Done \u00B7 score so far $score/$total", color = Cyan, size = 13)
                NeonButton("See my result", { phase = 2 }, Modifier.fillMaxWidth(), enabled = !grading)
            }
            for ((i, q) in qs.withIndex().filter { it.value.written }) {
                NeonCard {
                    Text("${i + 1}. ${q.q}", color = Txt, fontSize = 14.sp)
                    val m = selfMarks[i]
                    if (m != null) {
                        Text("$m / 2", color = if (m == 2) Good else if (m == 1) Violet else Bad, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    } else if (!grading || failed[i] == true) {
                        MutedText("Not marked yet")
                    } else {
                        MutedText("\u23F3 waiting\u2026")
                    }
                    val fb = feedback[i]
                    if (!fb.isNullOrBlank()) MutedText(fb)
                    if (failed[i] == true && !grading) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("Right", selfMarks[i] == 2, { selfMarks[i] = 2 }, Good)
                            Chip("Partly", selfMarks[i] == 1, { selfMarks[i] = 1 }, Violet)
                            Chip("Wrong", selfMarks[i] == 0, { selfMarks[i] = 0 }, Bad)
                        }
                    }
                }
            }
        } else {
            val pct = if (total == 0) 0 else Math.round(score * 100f / total)
            NeonCard {
                Kicker("TEST ${test.slot + 1} RESULT")
                Text("$score / $total", color = Txt, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                Body(
                    when {
                        pct >= 85 -> "Outstanding \u2014 you have mastered this chapter! \uD83C\uDF1F ($pct%)"
                        pct >= 60 -> "Good work \u2014 revise the weak questions. ($pct%)"
                        else -> "Needs more revision \u2014 go back to the chapter and try again. ($pct%)"
                    },
                    size = 15
                )
                MutedText("Multiple-choice answers are marked automatically; written answers were read and marked by the AI from your photos.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Retry", { answers.clear(); selfMarks.clear(); photos.clear(); photoUrls.clear(); feedback.clear(); failed.clear(); idx = 0; phase = 0 }, Modifier.weight(1f))
                    NeonButton("All tests", { onExit() }, Modifier.weight(1f), secondary = true)
                }
            }
            NeonCard {
                Kicker("TEST ${test.slot + 1} LEADERBOARD")
                if (board.isEmpty()) MutedText("Loading\u2026")
                for ((i, r) in board.withIndex()) {
                    Row(Modifier.fillMaxWidth()) {
                        Text("${i + 1}. ${r.first}", color = Txt, modifier = Modifier.weight(1f))
                        MutedText("${r.second.toInt()}/${r.third.toInt()}", size = 13)
                    }
                }
            }
        }
        if (phase == 2 && test.writtenCount > 0) {
            NeonCard {
                Kicker("WRITTEN ANSWERS \u00B7 AI FEEDBACK")
                for ((i, q) in qs.withIndex().filter { it.value.written }) {
                    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${i + 1}. ${q.q}", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("Marks: ${selfMarks[i] ?: 0}/2", color = Cyan, fontSize = 13.sp)
                        val fb = feedback[i]
                        if (!fb.isNullOrBlank()) MutedText(fb)
                    }
                }
            }
        }
        if (phase == 2) {
            NeonCard {
                Kicker("MULTIPLE-CHOICE REVIEW")
                for ((i, q) in qs.withIndex().filter { !it.value.written }) {
                    val mine = answers[i]
                    val ok = mine == q.answer
                    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${i + 1}. ${q.q}", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        val yours = if (mine == null) "not answered" else q.options.getOrElse(mine) { "?" }
                        Text((if (ok) "\u2713 " else "\u2717 ") + "Your answer: $yours", color = if (ok) Good else Bad, fontSize = 13.sp)
                        if (!ok) Text("Correct: ${q.options.getOrElse(q.answer) { "?" }}", color = Good, fontSize = 13.sp)
                        if (q.explanation.isNotBlank()) MutedText(q.explanation)
                    }
                }
            }
        }
    }
}


/** Scales a photo down (max 1600 px, upright, JPEG) so the AI can read it and the upload stays small. */
private fun shrinkPhoto(ctx: android.content.Context, uri: Uri): Uri {
    val resolver = ctx.contentResolver
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 3200 || bounds.outHeight / sample > 3200) sample *= 2
    val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
    var bmp = resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) } ?: return uri
    var rotate = 0
    if (android.os.Build.VERSION.SDK_INT >= 24) {
        try {
            resolver.openInputStream(uri)?.use { ins ->
                val ex = android.media.ExifInterface(ins)
                rotate = when (ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            }
        } catch (e: Exception) {
            rotate = 0
        }
    }
    val longest = Math.max(bmp.width, bmp.height)
    val scale = if (longest > 1600) 1600f / longest else 1f
    if (scale < 1f || rotate != 0) {
        val m = android.graphics.Matrix()
        m.postScale(scale, scale)
        if (rotate != 0) m.postRotate(rotate.toFloat())
        bmp = android.graphics.Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
    val dir = File(ctx.cacheDir, "capture")
    dir.mkdirs()
    val f = File(dir, "answer-small-" + System.currentTimeMillis() + ".jpg")
    f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, it) }
    return FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
}
