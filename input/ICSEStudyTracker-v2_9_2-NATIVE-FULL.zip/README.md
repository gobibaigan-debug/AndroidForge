# ICSE Class 9 Study Tracker (native Android)

Kotlin + Jetpack Compose app that talks to the Floot backend (`/_api/tracker`, `/_api/auth/*`, `/_api/upload`).
Application ID `com.icse.class9studytracker`, version 2.9.2, compile/target SDK 35, min SDK 21.

Build: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
(Gradle 8.11.1 wrapper, AGP 8.7.3, Kotlin 2.0.21, JDK 17+).

Note: the Floot server uses SuperJSON, so every request body is wrapped as {"json": ...} and every response is
unwrapped in `data/Api.kt`.
