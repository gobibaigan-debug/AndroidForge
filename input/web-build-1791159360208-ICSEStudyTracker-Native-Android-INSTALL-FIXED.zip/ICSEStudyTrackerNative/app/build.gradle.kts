plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace = "com.icse.studytracker"; compileSdk = 35
 defaultConfig { applicationId = "com.icse.studytracker"; minSdk = 21; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
 buildFeatures { compose = true; buildConfig = true }
 buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("debug") } }
}
dependencies {
 implementation(platform("androidx.compose:compose-bom:2024.12.01")); implementation("androidx.activity:activity-compose:1.10.0"); implementation("androidx.compose.ui:ui"); implementation("androidx.compose.ui:ui-tooling-preview"); implementation("androidx.compose.material3:material3"); implementation("androidx.compose.material:material-icons-extended"); implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7"); implementation("androidx.lifecycle:lifecycle-service:2.8.7"); implementation("androidx.work:work-runtime-ktx:2.10.0"); implementation("androidx.core:core-ktx:1.15.0"); debugImplementation("androidx.compose.ui:ui-tooling")
}
