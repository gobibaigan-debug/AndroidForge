package com.icse.class9studytracker.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class AppState(context: Context) {
    private val p=context.getSharedPreferences("tracker",Context.MODE_PRIVATE)
    var cookie: String?
        get() = p.getString("cookie",null)
        set(v) { p.edit().putString("cookie",v).apply() }
    var userId: String
        get() = p.getString("userId","") ?: ""
        set(v) { p.edit().putString("userId",v).apply() }
    var userName: String
        get() = p.getString("name","") ?: ""
        set(v) { p.edit().putString("name",v).apply() }
    var email: String
        get() = p.getString("email","") ?: ""
        set(v) { p.edit().putString("email",v).apply() }
    var stream: String
        get() = p.getString("stream","science") ?: "science"
        set(v) { p.edit().putString("stream",v).apply() }
    var focus: Boolean
        get() = p.getBoolean("focus",false)
        set(v) { p.edit().putBoolean("focus",v).apply() }
    var focusPackages: Set<String>
        get() = p.getStringSet("focusPackages",emptySet()) ?: emptySet()
        set(v) { p.edit().putStringSet("focusPackages",v).apply() }
    var focusLabels: Set<String>
        get() = p.getStringSet("focusLabels",emptySet()) ?: emptySet()
        set(v) { p.edit().putStringSet("focusLabels",v).apply() }
    var lastNotificationAt: String
        get() = p.getString("lastNotificationAt","") ?: ""
        set(v) { p.edit().putString("lastNotificationAt",v).apply() }
    var notificationsEnabled: Boolean
        get() = p.getBoolean("notificationsEnabled",true)
        set(v) { p.edit().putBoolean("notificationsEnabled",v).apply() }
    var hiddenMessageIds: Set<String>
        get() = p.getStringSet("hiddenMessageIds",emptySet()) ?: emptySet()
        set(v) { p.edit().putStringSet("hiddenMessageIds",v).apply() }
    fun hideMessage(id:String){ if(id.isBlank()) return; hiddenMessageIds=hiddenMessageIds+id }
    fun logout(){p.edit().clear().apply()}
}

object ApiClient {
    const val BASE="https://icse-study-tracker-neon.floot.app"
    private fun request(path:String,method:String,body:String?=null,cookie:String?=null,contentType:String="application/json"): Pair<Int,String>{
        val c=java.net.URL(BASE+path).openConnection() as java.net.HttpURLConnection
        c.requestMethod=method; c.connectTimeout=15000; c.readTimeout=20000; c.doInput=true
        c.setRequestProperty("Content-Type",contentType); if(cookie!=null)c.setRequestProperty("Cookie",cookie)
        if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toByteArray())}}
        val status=c.responseCode; val stream=if(status in 200..399)c.inputStream else c.errorStream
        val text=stream?.bufferedReader()?.readText().orEmpty()
        val set=c.headerFields.entries.filter{it.key!=null&&it.key.equals("Set-Cookie",true)}.flatMap{it.value}.joinToString("; "){it.substringBefore(';')}
        return Pair(status,text+"\n__SET_COOKIE__="+set)
    }
    private fun errMsg(raw:String,key:String,fallback:String,status:Int):String{
        val m=runCatching{JSONObject(raw.substringBefore("\n__SET_COOKIE__=")).optString(key)}.getOrDefault("")
        return if(m.isBlank()) "$fallback (HTTP $status)" else m
    }
    fun login(email:String,password:String): JSONObject {
        val (s,t)=request("/_api/auth/login_with_password","POST",JSONObject(mapOf("email" to email,"password" to password)).toString())
        if(s !in 200..299) throw Exception(errMsg(t,"message","Login failed",s))
        val ck=t.substringAfter("__SET_COOKIE__=","")
        if(ck.isBlank()) throw Exception("Server did not return a session cookie")
        return JSONObject(t.substringBefore("\n__SET_COOKIE__=")).put("__cookie",ck)
    }
    fun register(name:String,email:String,password:String,stream:String): JSONObject {
        val body=JSONObject(mapOf("email" to email,"password" to password,"displayName" to name))
        val (s,t)=request("/_api/auth/register_with_password","POST",body.toString())
        if(s !in 200..299) throw Exception(errMsg(t,"message","Registration failed",s))
        return login(email,password)
    }
    fun tracker(action:String,payload:JSONObject=JSONObject(),cookie:String): JSONObject {
        val body=JSONObject().put("action",action).put("payload",payload)
        val (s,t)=request("/_api/tracker","POST",body.toString(),cookie)
        val clean=t.substringBefore("\n__SET_COOKIE__=")
        if(s !in 200..299) throw Exception(errMsg(t,"error","Request failed",s))
        return JSONObject(clean).optJSONObject("data") ?: JSONObject(clean)
    }
    fun trackerArray(action:String,payload:JSONObject=JSONObject(),cookie:String): JSONArray {
        val body=JSONObject().put("action",action).put("payload",payload)
        val (s,t)=request("/_api/tracker","POST",body.toString(),cookie)
        val clean=t.substringBefore("\n__SET_COOKIE__=")
        if(s !in 200..299) throw Exception(errMsg(t,"error","Request failed",s))
        val root=JSONObject(clean); return root.optJSONArray("data") ?: JSONArray()
    }
    fun upload(bytes:ByteArray,name:String,mime:String,cookie:String): String {
        val prep=tracker("profile",JSONObject(),cookie) // verifies session before upload
        val body=JSONObject(mapOf("filename" to name,"contentType" to mime,"sizeBytes" to bytes.size,"visibility" to "private"))
        val (s,t)=request("/_api/upload","POST",body.toString(),cookie)
        if(s !in 200..299) throw Exception("Upload preparation failed")
        val o=JSONObject(t.substringBefore("\n__SET_COOKIE__=")); val d=o.getJSONObject("data"); val u=d.getString("presignedUrl"); val headers=d.optJSONObject("headers")
        val c=java.net.URL(u).openConnection() as java.net.HttpURLConnection; c.requestMethod="PUT"; c.doOutput=true; c.connectTimeout=20000;c.readTimeout=30000
        headers?.keys()?.forEach{c.setRequestProperty(it,headers.getString(it))}; c.outputStream.use{it.write(bytes)}
        if(c.responseCode !in 200..299) throw Exception("Media upload failed")
        return d.getString("url")
    }
}
