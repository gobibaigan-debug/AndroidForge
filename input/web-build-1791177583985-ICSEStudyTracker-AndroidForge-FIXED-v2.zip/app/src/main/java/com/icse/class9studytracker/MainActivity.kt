package com.icse.class9studytracker

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.Toast
import android.media.MediaPlayer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.icse.class9studytracker.data.*
import com.icse.class9studytracker.focus.FocusPrefs
import com.icse.class9studytracker.notifications.FocusTimerService
import kotlinx.coroutines.*
import androidx.work.*
import com.icse.class9studytracker.notifications.StudyReminderWorker
import com.icse.class9studytracker.notifications.ChatNotificationWorker
import com.icse.class9studytracker.notifications.NotificationHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private val Bg=Color(0xFF080812); private val Surface=Color(0xFF101022); private val Cyan=Color(0xFF00E5FF); private val Violet=Color(0xFF8B5CF6); private val Muted=Color(0xFF9297AD)
private val scienceSubjects=listOf("Physics","Chemistry","Biology","Mathematics","History & Civics","Geography","Computer","English")
private val commerceSubjects=listOf("Mathematics","History & Civics","Geography","English","Commercial Studies","Physical Education")
private val subjects=scienceSubjects+listOf("Commercial Studies","Physical Education")

private fun voiceFile(context: Context): File { val dir=File(context.cacheDir,"camera").apply{mkdirs()}; return File(dir,"voice-${System.currentTimeMillis()}.m4a") }

private fun createVoiceRecorder(context: Context,file: File): MediaRecorder? {
 return runCatching {
  val r=if(Build.VERSION.SDK_INT>=31) MediaRecorder(context) else MediaRecorder()
  r.setAudioSource(MediaRecorder.AudioSource.MIC);r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);r.setOutputFile(file.absolutePath);r.prepare();r.start();r
 }.getOrNull()
}

class MainActivity:ComponentActivity(){
 override fun onCreate(s:Bundle?){
  super.onCreate(s)
  NotificationHelper.channels(this)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED &&
     getSharedPreferences("notification_setup", MODE_PRIVATE).getBoolean("asked", false).not()){
    getSharedPreferences("notification_setup", MODE_PRIVATE).edit().putBoolean("asked", true).apply()
    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),700)
  }
  val request=PeriodicWorkRequestBuilder<StudyReminderWorker>(24,java.util.concurrent.TimeUnit.HOURS).setInitialDelay(StudyReminderWorker.initialDelayMs(),java.util.concurrent.TimeUnit.MILLISECONDS).build()
  WorkManager.getInstance(this).enqueueUniquePeriodicWork("daily-study-reminder",ExistingPeriodicWorkPolicy.UPDATE,request)
  val chatRequest=PeriodicWorkRequestBuilder<ChatNotificationWorker>(15,java.util.concurrent.TimeUnit.MINUTES).build()
  WorkManager.getInstance(this).enqueueUniquePeriodicWork("community-background-check",ExistingPeriodicWorkPolicy.UPDATE,chatRequest)
  setContent{TrackerApp()}
 }
}

@Composable fun TrackerApp(){
 val c=LocalContext.current; val state=remember{AppState(c)}; var logged by remember{mutableStateOf(state.cookie!=null)}
 MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Surface,primary=Cyan,secondary=Violet,onBackground=Color.White,onSurface=Color.White)){if(!logged) AuthScreen{logged=true}else MainShell(state){logged=false}}}

@Composable fun AuthScreen(onLogin:()->Unit){
 val c=LocalContext.current
 var register by remember{mutableStateOf(false)}; var name by remember{mutableStateOf("")};var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var stream by remember{mutableStateOf("science")};var err by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
 Box(Modifier.fillMaxSize().background(Bg).padding(22.dp),Alignment.Center){Card(colors=CardDefaults.cardColors(containerColor=Surface),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("ICSE STUDY TRACKER",color=Cyan,fontSize=24.sp,fontWeight=FontWeight.Black);Text("Class 9 • 2026–27",color=Muted)
  if(register) OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true,modifier=Modifier.fillMaxWidth())
  OutlinedTextField(email,{email=it},label={Text("Email")},singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedTextField(pass,{pass=it},label={Text("Password")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
  if(register){Text("Choose stream",color=Muted);Row{FilterChip(stream=="science",{stream="science"},label={Text("Science")});Spacer(Modifier.width(8.dp));FilterChip(stream=="commerce",{stream="commerce"},label={Text("Commerce")})}}
  if(err.isNotBlank())Text(err,color=Color(0xFFFF6B8A))
  Button(enabled=!busy,onClick={busy=true;CoroutineScope(Dispatchers.IO).launch{try{val r=if(register)ApiClient.register(name,email,pass,stream)else ApiClient.login(email,pass);val cookie=r.optString("__cookie"); val u=r.optJSONObject("user"); if(cookie.isNotBlank()){val app=AppState(c);app.cookie=cookie;app.email=u?.optString("email",email)?:email;app.userName=u?.optString("displayName",name)?:name;app.userId=u?.optString("id","")?:"";app.stream=stream;runCatching{ApiClient.tracker("profile_update",JSONObject().put("stream",stream).put("distractingApps",JSONArray(app.focusPackages.toList())),cookie)}};withContext(Dispatchers.Main){busy=false;onLogin()}}catch(e:Exception){withContext(Dispatchers.Main){busy=false;err=e.message?:("Could not connect")}}}},modifier=Modifier.fillMaxWidth()){Text(if(busy)"Connecting…" else if(register)"Create account" else "Sign in")}
  TextButton(onClick={register=!register;err=""}){Text(if(register)"Already have an account? Sign in" else "New user? Create account")}
 }}}
}

@Composable fun MainShell(state:AppState,onLogout:()->Unit){
 val c=LocalContext.current; var tab by remember{mutableStateOf("Home")}; LaunchedEffect(Unit){(c as? Activity)?.intent?.getStringExtra("openTab")?.let{tab=it}}; val tabs=listOf("Home","Timer","Stats","Tests","Planner","Chat","Focus")
 Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Surface){tabs.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(if(t=="Home")Icons.Default.Home else if(t=="Timer")Icons.Default.Timer else if(t=="Stats")Icons.Default.BarChart else if(t=="Tests")Icons.Default.Quiz else if(t=="Chat")Icons.Default.Chat else Icons.Default.Shield,"",tint=if(tab==t)Cyan else Muted)},label={Text(t)})}}}){pad->Box(Modifier.fillMaxSize().padding(pad)){when(tab){"Home"->HomeScreen(state){state.logout();onLogout()};"Timer"->TimerScreen(state);"Stats"->StatsScreen(state);"Tests"->TestsScreen(state);"Planner"->PlannerScreen(state);"Chat"->ChatScreen(state);"Focus"->FocusScreen(state)}}}}

@Composable fun Header(title:String,subtitle:String?=null){Column{Text(title,color=Cyan,fontSize=28.sp,fontWeight=FontWeight.Black);subtitle?.let{Text(it,color=Muted)}}}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Surface),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)){Column(Modifier.padding(16.dp),content=content)}}

@Composable fun HomeScreen(state:AppState,onLogout:()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){Header("Stay focused. Build the streak.","${state.userName.ifBlank{"Student"}} • ${state.stream.replaceFirstChar{it.uppercase()}} • Class IX")
 CardBox{Text("TODAY",color=Muted);Text("00:00:00",fontSize=38.sp,fontWeight=FontWeight.Bold);Text("Start a study session from Timer",color=Muted)}
 Row{StatCard("Study time","Syncs online");StatCard("Rank","Weekly leaderboard")};CardBox{Text("Sunday Tests",color=Cyan,fontWeight=FontWeight.Bold);Text("3 distinct syllabus tests • 35 MCQs each",fontSize=18.sp,fontWeight=FontWeight.Bold);Text("Mixed difficulty • reasoning • explanations • retry",color=Muted)}
 CardBox{Text("Focus Mode",color=Cyan,fontWeight=FontWeight.Bold);Text("Only the apps you choose are blocked while a focus session is active.");Text("Unselected apps remain usable.",color=Muted)};CardBox{Text("ACCOUNT",color=Cyan,fontWeight=FontWeight.Bold);Text(state.email.ifBlank{"Signed in"},color=Muted);OutlinedButton(onClick=onLogout){Text("Sign out")}} }}
@Composable fun RowScope.StatCard(a:String,b:String){Card(colors=CardDefaults.cardColors(containerColor=Surface),modifier=Modifier.weight(1f).padding(5.dp)){Column(Modifier.padding(14.dp)){Text(a,color=Cyan,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=12.sp)}}}

@Composable fun TimerScreen(state:AppState){
 val availableSubjects=if(state.stream.lowercase().contains("commerce")) commerceSubjects else scienceSubjects
 var sec by remember{mutableLongStateOf(0)};var topic by remember{mutableStateOf("")};var running by remember{mutableStateOf(false)};var subject by remember{mutableStateOf(availableSubjects.first())};var saved by remember{mutableStateOf(false)};var verify by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
 LaunchedEffect(running){while(running){delay(1000);sec++}}
 if(verify){ManualVerificationScreen(state,subject,topic.ifBlank{"this study session"}){verify=false};return}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Header("Study Timer","Track real study time and verify your understanding");CardBox{Text("Subject",color=Muted);var open by remember{mutableStateOf(false)};Box{Button(onClick={open=true}){Text(subject)};DropdownMenu(open,{open=false}){availableSubjects.forEach{s->DropdownMenuItem({Text(s)},onClick={subject=s;open=false})}}}}
  OutlinedTextField(value=topic,onValueChange={topic=it},label={Text("Topic / chapter (optional)")},modifier=Modifier.fillMaxWidth(),singleLine=true);CardBox{Text(String.format("%02d:%02d:%02d",sec/3600,(sec/60)%60,sec%60),fontSize=52.sp,fontWeight=FontWeight.Black,color=Cyan);Row{Button(onClick={running=!running}){Text(if(running)"Pause" else "Start")};Spacer(Modifier.width(8.dp));OutlinedButton(enabled=sec>0,onClick={running=false;val seconds=sec.toInt();CoroutineScope(Dispatchers.IO).launch{runCatching{ApiClient.tracker("study",JSONObject().put("subject",subject).put("chapter",topic).put("durationSeconds",seconds).put("verified",false),state.cookie!!);withContext(Dispatchers.Main){saved=true}}};sec=0}){Text("Finish & Save")}}}
  if(saved){CardBox{Text("Session saved",color=Color(0xFF5DFFB0),fontWeight=FontWeight.Bold);Text("Run the 5-question verification to test understanding. Passing requires at least 2/5.",color=Muted);Button(onClick={verify=true}){Text("Start 5-question verification")}}}
  if(error.isNotBlank())Text(error,color=Color(0xFFFF6B8A))
 }
}

@Composable fun ManualVerificationScreen(state:AppState,subject:String,topic:String,onDone:()->Unit){
 var questions by remember{mutableStateOf(listOf<String>())};var index by remember{mutableIntStateOf(0)};var answers by remember{mutableStateOf(mapOf<Int,String>())};var answer by remember{mutableStateOf("")};var result by remember{mutableStateOf<JSONObject?>(null)};var loading by remember{mutableStateOf(true)};var error by remember{mutableStateOf("")}
 LaunchedEffect(Unit){withContext(Dispatchers.IO){runCatching{val d=ApiClient.tracker("manual_questions",JSONObject().put("subject",subject).put("topic",topic),state.cookie!!);val a=d.optJSONArray("questions")?:JSONArray();withContext(Dispatchers.Main){questions=(0 until a.length()).map{a.getString(it)};loading=false}}.onFailure{withContext(Dispatchers.Main){error=it.message?:"Could not load verification";loading=false}}}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
  Header("Study Verification","5 questions • Pass mark 2/5")
  when{loading->Text("Generating questions…",color=Muted);result!=null->{val r=result!!;CardBox{Text(if(r.optBoolean("passed"))"Verification passed" else "Verification not passed",color=if(r.optBoolean("passed"))Color(0xFF5DFFB0) else Color(0xFFFF6B8A),fontSize=24.sp,fontWeight=FontWeight.Black);Text("Correct: ${r.optInt("correct")}/5");if(!r.optBoolean("passed"))Text(r.optString("failurePhrase","ehha immandari chalata babu 😂😂lol"),color=Violet);Button(onClick=onDone){Text("Done")}}};error.isNotBlank()->{Text(error,color=Color(0xFFFF6B8A));Button(onClick=onDone){Text("Back")}};questions.isNotEmpty()->{CardBox{Text("Question ${index+1} / ${questions.size}",color=Violet,fontWeight=FontWeight.Bold);Text(questions[index],fontSize=18.sp,fontWeight=FontWeight.Bold);OutlinedTextField(answer,{answer=it},label={Text("Your answer")},modifier=Modifier.fillMaxWidth(),minLines=3);Button(enabled=answer.isNotBlank(),onClick={answers=answers+(index to answer);answer="";if(index+1<questions.size)index++ else{loading=true;CoroutineScope(Dispatchers.IO).launch{runCatching{val qa=JSONArray();questions.indices.forEach{k->qa.put(JSONObject().put("q",questions[k]).put("a",(answers+(index to answer))[k]?:""))};val d=ApiClient.tracker("manual_grade",JSONObject().put("subject",subject).put("topic",topic).put("qa",qa),state.cookie!!);withContext(Dispatchers.Main){result=d;loading=false}}.onFailure{withContext(Dispatchers.Main){error=it.message?:"Could not grade verification";loading=false}}}}}){Text(if(index+1<questions.size)"Next" else "Submit verification")}}}}
 }
}

@Composable fun StatsScreen(state:AppState){
 var period by remember{mutableStateOf("week")}
 var records by remember{mutableStateOf(JSONArray())}
 var board by remember{mutableStateOf(listOf<String>())}
 var loading by remember{mutableStateOf(false)}
 LaunchedEffect(Unit){withContext(Dispatchers.IO){runCatching{val r=ApiClient.trackerArray("study_stats",JSONObject(),state.cookie!!);withContext(Dispatchers.Main){records=r}}}}
 LaunchedEffect(period){loading=true;withContext(Dispatchers.IO){runCatching{val b=ApiClient.trackerArray("leaderboard",JSONObject().put("period",period),state.cookie!!);val l=(0 until b.length()).map{idx->val x=b.getJSONObject(idx);"${idx+1}. ${x.optString("displayName","Student")} — ${x.optInt("totalMinutes",0)} min"};withContext(Dispatchers.Main){board=l;loading=false}}.onFailure{withContext(Dispatchers.Main){loading=false}}}}
 val total=(0 until records.length()).sumOf{records.getJSONObject(it).optInt("durationSeconds",0)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
  Header("Stats & Leaderboard","Daily • weekly • monthly progress")
  Row{listOf("day","week","month").forEach{p->FilterChip(selected=period==p,onClick={period=p},label={Text(p.replaceFirstChar{it.uppercase()})});Spacer(Modifier.width(6.dp))}}
  CardBox{Text("Total recorded study time",color=Cyan,fontWeight=FontWeight.Bold);Text("${total/3600}h ${(total/60)%60}m",fontSize=32.sp,fontWeight=FontWeight.Black)}
  CardBox{Text("${period.replaceFirstChar{it.uppercase()}} leaderboard",color=Cyan,fontWeight=FontWeight.Bold);if(loading)Text("Loading…",color=Muted) else if(board.isEmpty())Text("No study scores yet.",color=Muted) else board.take(20).forEach{Text(it,Modifier.padding(vertical=3.dp))}}
  CardBox{Text("Recent sessions",color=Cyan,fontWeight=FontWeight.Bold);if(records.length()==0)Text("No study sessions yet.",color=Muted);for(i in 0 until minOf(records.length(),15)){val x=records.getJSONObject(i);Text("${x.optString("subject","Study")} • ${x.optInt("durationSeconds",0)/60} min",Modifier.padding(vertical=3.dp))}}
 }
}

@Composable fun TestsScreen(state:AppState){
 var tests by remember{mutableStateOf<List<JSONObject>>(emptyList())}
 var selected by remember{mutableStateOf<JSONObject?>(null)}
 var boards by remember{mutableStateOf<Map<Int,List<String>>>(emptyMap())}
 var boardBusy by remember{mutableStateOf(false)}
 LaunchedEffect(Unit){
  withContext(Dispatchers.IO){
   runCatching{
    val d=ApiClient.tracker("tests",JSONObject(),state.cookie!!)
    val a=d.optJSONArray("tests")?:JSONArray()
    val l=(0 until a.length()).map{a.getJSONObject(it)}
    withContext(Dispatchers.Main){tests=l}
   }
  }
 }
 LaunchedEffect(tests.size){
  if(tests.isNotEmpty()){
   boardBusy=true
   val out=mutableMapOf<Int,List<String>>()
   withContext(Dispatchers.IO){
    tests.forEach{t->
     val slot=t.optInt("slot",0)
     runCatching{
      val a=ApiClient.trackerArray("test_leaderboard",JSONObject().put("testNumber",slot),state.cookie!!)
      out[slot]=(0 until a.length()).map{idx->
       val x=a.getJSONObject(idx)
       "${idx+1}. ${x.optString("displayName","Student")} — ${x.optInt("score",0)} / ${x.optInt("totalMarks",0)}"
      }
     }
    }
   }
   boards=out
   boardBusy=false
  }
 }
 if(selected!=null){TestRunner(state,selected!!){selected=null};return}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
  Header("Sunday Tests","Class IX 2026–27 syllabus • 35 MCQs • mixed difficulty")
  if(tests.isEmpty())Text("Loading tests…",color=Muted)
  tests.forEachIndexed{i,t->
   val count=t.optJSONArray("questions")?.length()?:0
   CardBox{
    Text("Sunday Test ${i+1}",color=Cyan,fontSize=20.sp,fontWeight=FontWeight.Bold)
    Text("$count questions • timed • difficulty marks • explanations • retry")
    Button(onClick={selected=t}){Text("Start / Retry")}
    Text("Test leaderboard",color=Violet,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
    if(boardBusy)Text("Loading leaderboard…",color=Muted)
    else boards[t.optInt("slot",0)].orEmpty().take(5).ifEmpty{listOf("No scores yet.")}.forEach{Text(it,Modifier.padding(vertical=2.dp),fontSize=13.sp)}
   }
  }
 }
}

@Composable fun TestRunner(state:AppState,test:JSONObject,onDone:()->Unit){
 val q=test.optJSONArray("questions")?:JSONArray();val total=q.length();var i by remember{mutableIntStateOf(0)};var score by remember{mutableIntStateOf(0)};var answered by remember{mutableStateOf(false)};var choice by remember{mutableIntStateOf(-1)};var submitted by remember{mutableStateOf(false)};var elapsed by remember{mutableIntStateOf(0)};var answers by remember{mutableStateOf(mapOf<Int,Int>())};var attempts by remember{mutableStateOf<List<JSONObject>>(emptyList())}
 LaunchedEffect(submitted){if(!submitted){while(true){delay(1000);elapsed++}}}
 LaunchedEffect(Unit){withContext(Dispatchers.IO){runCatching{val a=ApiClient.trackerArray("attempts",JSONObject(),state.cookie!!);val l=(0 until a.length()).map{a.getJSONObject(it)}.filter{it.optInt("testNumber",-1)==test.optInt("slot",-2)};withContext(Dispatchers.Main){attempts=l}}}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
  Header("Sunday Test","${if(submitted) "Complete" else "Question ${i+1} / $total"} • ${elapsed/60}:${String.format("%02d",elapsed%60)}")
  if(submitted){
   CardBox{Text("Test complete",color=Cyan,fontSize=26.sp,fontWeight=FontWeight.Black);Text("Score: $score / ${qMarks(q)}");Text("Time: ${elapsed/60} min ${elapsed%60} sec",color=Muted);Text("Attempt saved online.");Button(onClick={onDone}){Text("Back to tests")}}
   CardBox{Text("Previous attempts",color=Cyan,fontWeight=FontWeight.Bold);if(attempts.isEmpty())Text("No previous attempts found.",color=Muted);attempts.take(10).forEachIndexed{k,a->Text("${k+1}. ${a.optString("score","0")} / ${a.optString("totalMarks","0")}",Modifier.padding(vertical=3.dp))}}
  }else if(total==0){Text("This test is unavailable.",color=Color(0xFFFF6B8A));Button(onClick=onDone){Text("Back")}}
  else{
   val x=q.getJSONObject(i);val opts=x.optJSONArray("options")?:JSONArray();val correct=choice==x.optInt("answer")
   CardBox{Text("${x.optString("difficulty")} • ${x.optInt("marks",1)} mark(s)",color=Violet,fontWeight=FontWeight.Bold);Text(x.optString("q"),fontSize=19.sp,fontWeight=FontWeight.Bold)
    for(j in 0 until opts.length()){Row(Modifier.fillMaxWidth().clickable{if(!answered)choice=j}.padding(7.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=choice==j,onClick={if(!answered)choice=j});Text(opts.getString(j))}}
    Button(enabled=choice>=0,onClick={if(!answered){answered=true;answers=answers+(i to choice);if(correct)score+=x.optInt("marks",1)}}){Text(if(answered)"Answer checked" else "Check answer")}
    if(answered){Text(if(correct)"Correct" else "Incorrect",color=if(correct)Color(0xFF5DFFB0) else Color(0xFFFF6B8A));Text(x.optString("explanation"),color=Muted,modifier=Modifier.padding(top=5.dp))}
   }
   if(answered){Button(onClick={if(i+1>=total){submitted=true;val answerJson=JSONObject();answers.forEach{(k,v)->answerJson.put(k.toString(),v)};CoroutineScope(Dispatchers.IO).launch{runCatching{ApiClient.tracker("attempt",JSONObject().put("testNumber",test.optInt("slot",0)).put("score",score).put("totalMarks",qMarks(q)).put("answers",answerJson),state.cookie!!)}}}else{i++;choice=-1;answered=false}}){Text(if(i+1>=total)"Finish test" else "Next question")}}
  }
 }
}
fun qMarks(q:JSONArray):Int{var total=0;for(i in 0 until q.length())total+=q.getJSONObject(i).optInt("marks",1);return total}

@Composable fun PlannerScreen(state:AppState){
 var date by remember{mutableStateOf("")};var saved by remember{mutableStateOf(listOf<String>())};val c=LocalContext.current
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){Header("Exam Planner","Build and save a revision plan online")
  CardBox{Text("Exam date",color=Muted);Button(onClick={val cal=Calendar.getInstance();android.app.DatePickerDialog(c,{_,y,m,d->date=String.format("%04d-%02d-%02d",y,m+1,d)},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()}){Text(if(date.isBlank())"Choose date" else date)}
   Button(enabled=date.isNotBlank(),onClick={val plans=subjects.mapIndexed{i,s->JSONObject().put("subject",s).put("chapter","Revision plan").put("examDate",date).put("revisionSlot",i%3).put("completed",false)};CoroutineScope(Dispatchers.IO).launch{runCatching{val d=ApiClient.tracker("exam",JSONObject().put("plans",JSONArray(plans)),state.cookie!!);withContext(Dispatchers.Main){saved=subjects}}}}){Text("Generate & Save Plan")}}
  if(saved.isNotEmpty())CardBox{Text("Saved revision subjects",color=Cyan,fontWeight=FontWeight.Bold);saved.forEachIndexed{i,s->Text("${i+1}. $s",Modifier.padding(vertical=3.dp))}}
 }
}

@Composable fun ChatScreen(state:AppState){
 val c=LocalContext.current;val scope=rememberCoroutineScope();var mode by remember{mutableStateOf("Community")};var msgs by remember{mutableStateOf(listOf<JSONObject>())};var text by remember{mutableStateOf("")};var selectedPeer by remember{mutableStateOf<String?>(null)};var members by remember{mutableStateOf(listOf<Pair<String,String>>())};var selectedFiles by remember{mutableStateOf<List<Uri>>(emptyList())};var cameraUri by remember{mutableStateOf<Uri?>(null)};var recording by remember{mutableStateOf(false)};var recorder by remember{mutableStateOf<MediaRecorder?>(null)};var cameraAction by remember{mutableStateOf("photo")};var pollOpen by remember{mutableStateOf(false)};var pollQuestion by remember{mutableStateOf("")};var pollA by remember{mutableStateOf("")};var pollB by remember{mutableStateOf("")};var refreshBusy by remember{mutableStateOf(false)}
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){u->selectedFiles=u?:emptyList()};val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()){ok->if(ok)cameraUri?.let{selectedFiles=selectedFiles+it}};val video=rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()){ok->if(ok)cameraUri?.let{selectedFiles=selectedFiles+it}}
 fun tempUri(prefix:String,suffix:String):Uri{val dir=File(c.cacheDir,"camera").apply{mkdirs()};val f=File.createTempFile(prefix,suffix,dir);return FileProvider.getUriForFile(c,"com.icse.class9studytracker.fileprovider",f)}
 val cameraPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->if(granted){val u=if(cameraAction=="video")tempUri("video",".mp4")else tempUri("photo",".jpg");cameraUri=u;if(cameraAction=="video")video.launch(u)else camera.launch(u)}}
 val micPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->if(granted){val f=voiceFile(c);val r=createVoiceRecorder(c,f);r?.let{recorder=it;cameraUri=FileProvider.getUriForFile(c,"com.icse.class9studytracker.fileprovider",f);recording=true}}}
 suspend fun send(kind:String="text",poll:JSONObject?=null){if(text.isBlank()&&selectedFiles.isEmpty()&&poll==null)return;val attachments=JSONArray();for(uri in selectedFiles){val cr=c.contentResolver;val bytes=cr.openInputStream(uri)?.use{it.readBytes()}?:continue;val rawName=uri.lastPathSegment?.substringAfterLast('/')?:"attachment";val name=rawName.substringAfterLast('=',rawName);val mime=cr.getType(uri)?:when(name.lowercase().substringAfterLast('.',"")){"jpg","jpeg"->"image/jpeg";"png"->"image/png";"mp4"->"video/mp4";"m4a"->"audio/mp4";"webm"->"audio/webm";"pdf"->"application/pdf";else->"application/octet-stream"};val url=ApiClient.upload(bytes,name,mime,state.cookie!!);attachments.put(JSONObject().put("url",url).put("name",name).put("type",mime).put("size",bytes.size))};val payload=JSONObject().put("kind",kind).put("body",text).put("attachments",attachments);if(poll!=null)payload.put("poll",poll);if(mode=="Community")ApiClient.tracker("community_post",payload,state.cookie!!) else ApiClient.tracker("dm_send",payload.put("peerId",selectedPeer?:return),state.cookie!!);selectedFiles=emptyList();cameraUri=null;text=""}
 suspend fun refresh(){refreshBusy=true;try{if(mode=="Community"){val a=ApiClient.trackerArray("community_list",JSONObject(),state.cookie!!);val loaded=(0 until a.length()).map{a.getJSONObject(it)};loaded.filter{it.optString("userId")!=state.userId}.take(100).forEach{m->val id=m.optString("id");if(id.isNotBlank())runCatching{ApiClient.tracker("community_read",JSONObject().put("messageId",id),state.cookie!!)}};loaded.filter{it.optString("userId")==state.userId}.take(30).forEach{m->val id=m.optString("id");if(id.isNotBlank())runCatching{val seen=ApiClient.trackerArray("seen_by",JSONObject().put("messageId",id),state.cookie!!);m.put("seenCount",seen.length());m.put("seenNames",(0 until minOf(seen.length(),8)).joinToString(", "){seen.getJSONObject(it).optString("displayName","Student")})}};msgs=loaded.filter{!state.hiddenMessageIds.contains(it.optString("id"))}}else if(selectedPeer!=null){val a=ApiClient.trackerArray("dm_list",JSONObject().put("peerId",selectedPeer),state.cookie!!);msgs=(0 until a.length()).map{a.getJSONObject(it)}.filter{!state.hiddenMessageIds.contains(it.optString("id"))};msgs.filter{it.optString("senderId")!=state.userId}.forEach{m->val id=m.optString("id");if(id.isNotBlank())runCatching{ApiClient.tracker("dm_read",JSONObject().put("messageId",id),state.cookie!!)}}}}finally{refreshBusy=false}}
 LaunchedEffect(mode,selectedPeer){withContext(Dispatchers.IO){runCatching{if(mode=="DMs"&&members.isEmpty()){val a=ApiClient.trackerArray("members",JSONObject(),state.cookie!!);members=(0 until a.length()).map{a.getJSONObject(it).optString("id") to a.getJSONObject(it).optString("displayName","User")}.filter{it.first.isNotBlank()&&it.first!=state.userId}};refresh()}}}
 LaunchedEffect(mode,selectedPeer){while(true){delay(5000);withContext(Dispatchers.IO){runCatching{refresh()}}}}
 Column(Modifier.fillMaxSize().padding(14.dp)){Header("Chat","Community + private DMs • images • video • PDF • voice • polls");Row{FilterChip(mode=="Community",{mode="Community"},label={Text("Community")});Spacer(Modifier.width(8.dp));FilterChip(mode=="DMs",{mode="DMs"},label={Text("DMs")});Spacer(Modifier.weight(1f));IconButton(onClick={scope.launch{withContext(Dispatchers.IO){runCatching{refresh()}}}}){Icon(Icons.Default.Refresh,"Refresh",tint=Cyan)}}
  if(mode=="DMs")Row(Modifier.horizontalScroll(rememberScrollState())){members.forEach{(id,name)->FilterChip(selectedPeer==id,{selectedPeer=id},label={Text(name)})}}
  if(refreshBusy&&msgs.isEmpty())Text("Loading messages…",color=Muted)
  LazyColumn(Modifier.weight(1f),reverseLayout=false){items(msgs.size){idx->MessageBubble(msgs[idx],state,mode,c)}}
  if(selectedFiles.isNotEmpty())CardBox{Text("${selectedFiles.size} attachment(s) ready",color=Cyan,fontWeight=FontWeight.Bold);selectedFiles.forEachIndexed{idx,u->Text("${idx+1}. ${u.lastPathSegment?:"file"}",fontSize=12.sp,color=Muted)}}
  Row(verticalAlignment=Alignment.Bottom){IconButton(onClick={picker.launch(arrayOf("image/*","video/*","application/pdf","audio/*"))}){Icon(Icons.Default.AttachFile,"Attach")};IconButton(onClick={if(Build.VERSION.SDK_INT<23){val u=tempUri("photo",".jpg");cameraUri=u;camera.launch(u)}else{cameraAction="photo";cameraPermission.launch(Manifest.permission.CAMERA)}}){Icon(Icons.Default.PhotoCamera,"Camera")};IconButton(onClick={if(Build.VERSION.SDK_INT<23){val u=tempUri("video",".mp4");cameraUri=u;video.launch(u)}else{cameraAction="video";cameraPermission.launch(Manifest.permission.CAMERA)}}){Icon(Icons.Default.Videocam,"Video")};IconButton(onClick={if(!recording){if(Build.VERSION.SDK_INT<23){val f=voiceFile(c);createVoiceRecorder(c,f)?.let{recorder=it;cameraUri=FileProvider.getUriForFile(c,"com.icse.class9studytracker.fileprovider",f);recording=true}}else micPermission.launch(Manifest.permission.RECORD_AUDIO)}else{runCatching{recorder?.stop()};runCatching{recorder?.release()};recorder=null;cameraUri?.let{selectedFiles=selectedFiles+it};recording=false}}){Icon(if(recording)Icons.Default.Stop else Icons.Default.Mic,if(recording)"Stop voice" else "Voice",tint=if(recording)Color(0xFFFF6B8A)else Cyan)};IconButton(onClick={pollOpen=true}){Icon(Icons.Default.Poll,"Poll")};OutlinedTextField(text,{text=it},modifier=Modifier.weight(1f),placeholder={Text("Message")});IconButton(enabled=mode=="Community"||selectedPeer!=null,onClick={scope.launch{withContext(Dispatchers.IO){runCatching{send();refresh()}}.onFailure{e->Toast.makeText(c,e.message?:"Could not send",Toast.LENGTH_SHORT).show()}}}){Icon(Icons.Default.Send,"Send",tint=Cyan)}}
 }
 if(pollOpen)AlertDialog(onDismissRequest={pollOpen=false},title={Text("Create poll")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(pollQuestion,{pollQuestion=it},label={Text("Question")});OutlinedTextField(pollA,{pollA=it},label={Text("Option 1")});OutlinedTextField(pollB,{pollB=it},label={Text("Option 2")})}},confirmButton={Button(enabled=pollQuestion.isNotBlank()&&pollA.isNotBlank()&&pollB.isNotBlank(),onClick={pollOpen=false;scope.launch{val p=JSONObject().put("question",pollQuestion).put("options",JSONArray().put(pollA).put(pollB)).put("counts",JSONArray().put(0).put(0)).put("voters",JSONObject());withContext(Dispatchers.IO){runCatching{send("poll",p);refresh()}}.onFailure{e->Toast.makeText(c,e.message?:"Could not post poll",Toast.LENGTH_SHORT).show()};pollQuestion="";pollA="";pollB=""}}){Text("Post poll")}},dismissButton={TextButton(onClick={pollOpen=false}){Text("Cancel")}})
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun MessageBubble(m:JSONObject,state:AppState,mode:String,c:Context){val mine=if(mode=="Community")m.optString("userId")==state.userId else m.optString("senderId")==state.userId;Card(colors=CardDefaults.cardColors(containerColor=if(mine)Color(0xFF171737)else Surface),shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().padding(vertical=4.dp).combinedClickable(onClick={},onLongClick={val id=m.optString("id");if(id.isNotBlank())state.hideMessage(id)})){Column(Modifier.padding(12.dp)){Text(if(mode=="Community")m.optString("displayName","User") else if(mine)"You" else "User",color=Cyan,fontWeight=FontWeight.Bold);m.optString("body").takeIf{it.isNotBlank()}?.let{Text(it,fontSize=16.sp)};val at=m.optJSONArray("attachments");if(at!=null)for(i in 0 until at.length()){val a=at.getJSONObject(i);AttachmentPreview(a,c)};m.optJSONObject("poll")?.let{PollPreview(m,it,state,mode)};if(mode=="DMs"&&mine){Text(if(m.optString("readAt").isNotBlank())"✓✓ Read" else if(m.optString("deliveredAt").isNotBlank())"✓ Delivered" else "✓ Sent",color=Muted,fontSize=11.sp)};if(mode=="Community"&&mine&&m.optInt("seenCount",0)>0){Text("Seen by ${m.optInt("seenCount")} ${m.optString("seenNames")}",color=Muted,fontSize=11.sp)}}}}

@Composable fun AttachmentPreview(a:JSONObject,c:Context){val url=a.optString("url");val name=a.optString("name","attachment");val type=a.optString("type");Row(Modifier.fillMaxWidth().clickable{runCatching{c.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}.padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(type.startsWith("image/"))Icons.Default.Image else if(type.startsWith("video/"))Icons.Default.Videocam else if(type.startsWith("audio/"))Icons.Default.Mic else Icons.Default.Description,"Attachment",tint=Cyan);Column(Modifier.padding(start=8.dp)){Text(name,fontWeight=FontWeight.Bold);Text(type.ifBlank{"File"},color=Muted,fontSize=11.sp)}}}

@Composable fun PollPreview(m:JSONObject,p:JSONObject,state:AppState,mode:String){val c=LocalContext.current;val opts=p.optJSONArray("options")?:JSONArray();val counts=p.optJSONArray("counts")?:JSONArray();Column(Modifier.padding(top=8.dp)){Text(p.optString("question","Poll"),fontWeight=FontWeight.Bold);for(i in 0 until opts.length()){val n=counts.optInt(i,0);Button(onClick={CoroutineScope(Dispatchers.IO).launch{runCatching{ApiClient.tracker("poll_vote",JSONObject().put("messageId",m.optString("id")).put("choice",i).put("isDm",mode=="DMs"),state.cookie!!)}}},modifier=Modifier.fillMaxWidth().padding(vertical=2.dp)){Text("${opts.getString(i)}  •  $n")}}}}

@Composable fun FocusScreen(state:AppState){val c=LocalContext.current;val pm=c.packageManager;var apps by remember{mutableStateOf(listOf<Pair<String,String>>())};var selected by remember{mutableStateOf(state.focusPackages)};var enabled by remember{mutableStateOf(FocusPrefs(c).enabled())};var notif by remember{mutableStateOf(state.notificationsEnabled)};LaunchedEffect(Unit){apps=pm.getInstalledApplications(PackageManager.GET_META_DATA).filter{it.packageName!=c.packageName && pm.getLaunchIntentForPackage(it.packageName)!=null && ((it.flags and ApplicationInfo.FLAG_SYSTEM)==0 || (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)!=0)}.map{(pm.getApplicationLabel(it).toString() to it.packageName)}.sortedBy{it.first.lowercase()}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){Header("Focus Mode","Select exactly which installed apps should be blocked")
 CardBox{Text("NOTIFICATIONS",color=Cyan,fontWeight=FontWeight.Bold);Text("Background chat checks and the daily study reminder can notify you even when the app is not open.",color=Muted);Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=notif,onCheckedChange={notif=it;state.notificationsEnabled=it});Text(if(notif)" Notifications ON" else " Notifications OFF",color=Color.White)} }
 CardBox{Text(if(enabled)"ACTIVE" else "OFF",color=if(enabled)Color(0xFF5DFFB0) else Muted,fontWeight=FontWeight.Bold);Text("Selected apps only are intercepted. Unselected apps remain available.",color=Muted);Row{Button(onClick={if(enabled){enabled=false;FocusPrefs(c).setEnabled(false);state.focus=false;c.startService(Intent(c,FocusTimerService::class.java).setAction(FocusTimerService.ACTION_STOP))}else{val accessibilityEnabled=Settings.Secure.getString(c.contentResolver,Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty().contains(c.packageName);if(!accessibilityEnabled){c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));Toast.makeText(c,"Enable ICSE Study Tracker in Accessibility, then start Focus again.",Toast.LENGTH_LONG).show()}else{enabled=true;FocusPrefs(c).setEnabled(true);state.focus=true;val i=Intent(c,FocusTimerService::class.java).setAction(FocusTimerService.ACTION_START).putExtra(FocusTimerService.EXTRA_END,System.currentTimeMillis()+50*60*1000);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i) else c.startService(i)}}}){Text(if(enabled)"End Focus" else "Start 50-min Focus")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick={c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}){Text("Accessibility")}}}
 apps.forEach{(label,pkg)->val update: (Boolean) -> Unit = { checked ->val s=selected.toMutableSet();if(checked)s.add(pkg)else s.remove(pkg);selected=s;FocusPrefs(c).setPackages(s);state.focusPackages=s;CoroutineScope(Dispatchers.IO).launch{state.cookie?.let{runCatching{ApiClient.tracker("focus_apps",JSONObject().put("apps",JSONArray(s.toList())),it)}}}};Row(Modifier.fillMaxWidth().clickable{update(!selected.contains(pkg))}.padding(vertical=7.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(selected.contains(pkg),{update(it)});Text(label);Spacer(Modifier.weight(1f));Text(pkg,color=Muted,fontSize=10.sp)}}}
}
