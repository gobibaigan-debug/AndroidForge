# AndroidForge build contract

Native Kotlin + Jetpack Compose project. Module `:app`, variant `debug`.

A Gradle wrapper (8.11.1) is now included, so AndroidForge uses the project's own wrapper instead of regenerating one.
Requires JDK 17+ and Android SDK platform 35 (AndroidForge installs these).
Output: `app/build/outputs/apk/debug/app-debug.apk`
