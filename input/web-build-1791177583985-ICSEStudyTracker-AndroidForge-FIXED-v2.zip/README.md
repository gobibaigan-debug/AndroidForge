# ICSE Class 9 Study Tracker

Native Kotlin/Jetpack Compose app. Application ID `com.icse.class9studytracker`, compile/target SDK 35, min SDK 21.

Build: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`
